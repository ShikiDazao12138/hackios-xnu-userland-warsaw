/*
 * The kernel's own UFS driver (annibale_ufshc.c), as annibale_ufs.c uses it.
 */
#ifndef _ANNIBALE_UFSHC_H_
#define _ANNIBALE_UFSHC_H_

#include <stdbool.h>
#include <stdint.h>
#include <sys/buf.h>

/* what the loader's page says about it (struct loader_block's native sections) */
struct ufshc_loader {
	uint64_t hc_pa;                         /* the controller's registers; 0: not offered */
	uint64_t area_pa;                       /* the loader's memory for this kernel's list and command descriptors */
	uint32_t area_size, ucd_offset, ucd_size, slots;
	uint32_t uefi_lo, uefi_hi;              /* UEFI's list */
	volatile uint32_t *take_back;           /* the loader's: it takes the controller back, send nothing more */
	volatile uint32_t *list_in;             /* this kernel's: its list is in */
	uint32_t *switched_in, *switched_out;
	volatile uint32_t *cnr_at_switch;       /* this kernel's: UTRLCNR when its list went in */
};

bool ufshc_probe(const struct ufshc_loader *loader, bool only);
bool ufshc_available(void);
void ufshc_set_luns(uint32_t mask);
int ufshc_switch_in(bool prove);
int ufshc_switch_out(const char *why);
bool ufshc_list_in(void);
int ufshc_read(uint8_t lun, uint64_t offset, uint8_t *dst, uint64_t len);
void ufshc_set_write_range(uint8_t lun, uint64_t start_lba, uint64_t end_lba);
int ufshc_write(uint8_t lun, uint64_t offset, const uint8_t *src, uint64_t len);
int ufshc_strategy_async(buf_t bp, uint8_t lun, uint64_t lun_offset, bool is_write);
int ufshc_sync_cache(uint8_t lun);
int ufshc_unmap(uint8_t lun, uint64_t lba, uint32_t blocks);
void ufshc_report(const char *when);
void annibale_ufs_quiesce(void);

#endif

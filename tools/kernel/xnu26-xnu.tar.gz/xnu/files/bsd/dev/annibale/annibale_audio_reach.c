/*
 * ADSP AudioReach driver for REDMI K90 (annibale):
 * Implements the AudioReach APM playback & shared-memory transport on SM8750 LPASS:
 *   - Apps SMMU (0x15000000) stream 0x1001, 0x1081, 0x1061 bypass mapping
 *   - 64 KiB contiguous shared DMA buffer at [0xcf66f000, 0xcf67f000) in lowdma
 *     with DSP address = buffer_pa | (1ULL << 32)
 *   - Subgraph SG_SPEAKER (0x4005): MOD_I2S_SINK (0x0700100a) on secondary MI2S (GPIO121-124)
 *   - Subgraph SG_PLAY (0x4001): MOD_WR_SHMEM (0x07001000) -> MOD_PCM_DEC (0x07001005) ->
 *     MOD_PCM_CNV (0x07001003) -> MOD_I2S_SINK
 *   - Speaker protection via annibale_guard (200 Hz HPF + RMS/fast/slow thermal & excursion limiter)
 */

#include <kern/clock.h>
#include <kern/kalloc.h>
#include <kern/locks.h>
#include <kern/sched_prim.h>
#include <kern/thread.h>
#include <libkern/libkern.h>
#include <mach/mach_types.h>
#include <pexpert/pexpert.h>
#include <sys/conf.h>
#include <sys/kernel.h>
#include <sys/param.h>
#include <sys/annibale_audio.h>
#include <sys/systm.h>
#include <sys/uio.h>

extern kern_return_t thread_terminate(thread_t thread);
extern vm_offset_t ml_io_map(vm_offset_t phys_addr, vm_size_t size);
extern vm_offset_t ml_io_map_wcomb(vm_offset_t phys_addr, vm_size_t size);

typedef bool (*annibale_gpr_event_fn)(uint32_t src_port, uint32_t dst_port, uint32_t opcode,
    uint32_t token, const void *payload, uint32_t len);

extern void annibale_adsp_init(void);
extern bool annibale_adsp_gpr_ready(void);
extern bool annibale_adsp_gpr_send(const void *pkt, uint32_t len, uint32_t wait_ms,
    uint32_t *rsp_opcode, uint32_t *rsp_words, uint32_t max_words);
extern void annibale_adsp_set_gpr_event(annibale_gpr_event_fn handler);
extern bool annibale_audio_amp_probe(void);
extern bool annibale_audio_amp_power(bool on);
extern void annibale_audio_amp_set_volume(uint32_t below_eighths_db, bool muted);
extern void annibale_audio_amp_status(const char *when);

#define say(...) printf("daudio: " __VA_ARGS__)

/* Apps SMMU definitions */
#define APPS_SMMU_PHYS          0x15000000UL
#define APPS_SMMU_SIZE          0x00100000UL
#define SMMU_IDR0               0x020u
#define SMMU_IDR1               0x024u
#define SMMU_SMR(n)             (0x800u + 4u * (n))
#define SMMU_S2CR(n)            (0xc00u + 4u * (n))
#define SMMU_CBAR(n)            (0x1000u + 4u * (n))
#define SMMU_CBA2R(n)           (0x1800u + 4u * (n))
#define SMMU_SMR_VALID          (1u << 31)
#define AUDIO_STREAM            0x1001u
#define AUDIO_STREAM_ALT1       0x1081u
#define AUDIO_STREAM_ALT2       0x1061u

#define TLMM_PHYS               0x0f100000UL
#define TLMM_SIZE               0x00150000UL

/* Preferred lowdma physical window [0xcf66f000, 0xcf67f000) */
#define LOWDMA_AUDIO_PA         0xcf66f000ULL

/* AudioReach APM Definitions */
#define GPR_DOMAIN_ADSP         2u
#define GPR_DOMAIN_APPS         3u
#define OUR_PORT                0x2001u
#define APM_IID                 1u
#define APM_CMD_GET_SPF_STATE   0x01001021u
#define APM_CMD_RSP_GET_SPF_STATE 0x02001007u
#define GPR_BASIC_RSP_RESULT    0x02001005u
#define AR_ENOTEXIST            19u
#define APM_SPF_STATE_NOT_READY 0u
#define APM_SPF_STATE_READY     1u
#define OP_GRAPH_OPEN           0x01001000u
#define OP_GRAPH_PREPARE        0x01001001u
#define OP_GRAPH_START          0x01001002u
#define OP_SET_CFG              0x01001006u
#define OP_MEM_MAP              0x0100100cu
#define OP_MEM_MAP_DONE         0x02001001u
#define OP_WRITE                0x0400100au
#define OP_WRITE_DONE           0x05001004u

/* Modules and Subgraphs */
#define MOD_WR_SHMEM            0x07001000u
#define MOD_PCM_CNV             0x07001003u
#define MOD_PCM_DEC             0x07001005u
#define MOD_I2S_SINK            0x0700100au

#define SG_PLAY                 0x4001u
#define SG_SPEAKER              0x4005u

#define IID_PLAY_SHMEM          0x6001u
#define IID_PLAY_DEC            0x6002u
#define IID_PLAY_CNV            0x6003u
#define IID_SPEAKER_I2S         0x6051u

bool annibale_audio_reach_send_cmd(const void *raw_pkt, uint32_t raw_len, const char *descr,
    uint32_t *rsp_opcode, uint32_t *rsp_words, uint32_t max_words);
bool annibale_audio_reach_dma_info(volatile uint8_t **va_out, uint64_t *pa_out,
    uint64_t *dsp_addr_out, uint32_t *map_handle_out);
bool annibale_audio_reach_is_active(void);
void annibale_audio_reach_init(void);

#define RATE                    48000u
#define CHANNELS                2u
#define PERIOD_FRAMES           960u            /* 20 ms @ 48 kHz */
#define PERIOD_BYTES            (PERIOD_FRAMES * CHANNELS * 2u) /* 3840 bytes */
#define SLOTS                   8u              /* 0x0000 .. 0x7800 (30 KiB) */
#define MIC_OFFSET              0x8000u         /* 0x8000 .. 0xbfff (16 KiB for capture) */
#define CMD_OFFSET              0xc000u         /* 0xc000 .. 0xffff (16 KiB for OOB GPR) */
#define BUFFER_BYTES            0x10000u        /* 64 KiB total */
#define IN_FLIGHT               4u
#define RING_FRAMES             32768u          /* 32768 frames (~0.68 s) */
#define RING_MASK               (RING_FRAMES - 1u)
#define QUIET_PERIODS           (5u * RATE / PERIOD_FRAMES) /* 5 s silence threshold */

static vm_offset_t smmu_vbase;
static uint64_t buffer_pa;
static uint64_t dsp_address;
static volatile uint8_t *reach_buffer;
static uint32_t map_handle;
static uint32_t gpr_token = 100;

static volatile uint32_t reach_sent_count;
static volatile uint32_t reach_done_count;
static volatile uint32_t in_flight_mask;
static volatile bool reach_write_failed;
static volatile bool reach_stream_active;
static uint32_t reach_sync_mode;

static int16_t *ring_storage;
static uint32_t ring_head;
static uint32_t ring_tail;
static lck_grp_t *audio_lock_grp;
static lck_spin_t *audio_spin_lock;
static lck_mtx_t *cmd_oob_lock;

static inline uint32_t
smmu_rd(vm_offset_t off)
{
	return *(volatile uint32_t *)(smmu_vbase + off);
}

static inline void
smmu_wr(vm_offset_t off, uint32_t val)
{
	*(volatile uint32_t *)(smmu_vbase + off) = val;
	__builtin_arm_dsb(0xf);
}

/* SMMU stage-1 bypass configuration for LPASS audio stream IDs */
static bool
smmu_configure_bypass(uint16_t stream)
{
	if (smmu_vbase == 0) {
		smmu_vbase = ml_io_map(APPS_SMMU_PHYS, APPS_SMMU_SIZE);
		if (smmu_vbase == 0) {
			say("failed to map apps SMMU\n");
			return false;
		}
	}
	uint32_t idr0 = smmu_rd(SMMU_IDR0);
	uint32_t idr1 = smmu_rd(SMMU_IDR1);
	uint32_t count = MIN(idr0 & 0xffu, 128u);
	uint32_t banks = idr1 & 0xffu;
	uint32_t pages = 1u << (((idr1 >> 28) & 7u) + 1u);
	uint32_t bank = banks > 0 ? banks - 1u : 0u;
	uint32_t pg_size = (idr1 & (1u << 31)) ? 0x10000u : 0x1000u;
	uint32_t cb = (pages + bank) * pg_size;
	uint32_t slot = ~0u;
	bool already_matched = false;

	for (uint32_t i = 0; i < count; i++) {
		uint32_t smr = smmu_rd(SMMU_SMR(i));
		uint32_t s2cr = smmu_rd(SMMU_S2CR(i));
		uint32_t mask = (smr >> 16) & 0x7fffu;

		if (!(smr & SMMU_SMR_VALID)) {
			if (slot == ~0u) {
				slot = i;
			}
			continue;
		}
		if (((smr ^ stream) & 0xffffu & ~mask) == 0) {
			if (((s2cr >> 16) & 3u) == 0 && (s2cr & 0xffu) == bank) {
				already_matched = true;
				slot = i;
				break;
			}
			return true;
		}
	}
	if (slot == ~0u) {
		say("no free SMMU stream match slot for stream %#x\n", stream);
		return false;
	}
	smmu_wr(cb, 0);                 /* SCTLR = 0 */
	smmu_wr(SMMU_CBA2R(bank), 1);   /* VA64 = 1 */
	smmu_wr(SMMU_CBAR(bank), 0x10000u);

	if (!already_matched) {
		smmu_wr(SMMU_S2CR(slot), bank);
		smmu_wr(SMMU_SMR(slot), SMMU_SMR_VALID | stream);
	}
	say("stream %#x configured for SMMU bypass: slot %u, context bank %u\n", stream, slot, bank);
	return true;
}

/* ---- GPR packet builder & command dispatcher ------------------------------------------------- */

struct gpr_pkt {
	uint8_t  buf[1024];
	uint32_t len;
};

static void
gpr_put32(struct gpr_pkt *p, uint32_t val)
{
	if (p->len + 4 <= sizeof(p->buf)) {
		memcpy(p->buf + p->len, &val, 4);
		p->len += 4;
	}
}

static void
gpr_put16(struct gpr_pkt *p, uint16_t val)
{
	if (p->len + 2 <= sizeof(p->buf)) {
		memcpy(p->buf + p->len, &val, 2);
		p->len += 2;
	}
}

static void
gpr_put8(struct gpr_pkt *p, uint8_t val)
{
	if (p->len < sizeof(p->buf)) {
		p->buf[p->len++] = val;
	}
}

static void
gpr_set32(struct gpr_pkt *p, uint32_t offset, uint32_t val)
{
	if (offset + 4 <= sizeof(p->buf)) {
		memcpy(p->buf + offset, &val, 4);
	}
}

static void
gpr_pad_to(struct gpr_pkt *p, uint32_t target)
{
	while (p->len < target && p->len < sizeof(p->buf)) {
		p->buf[p->len++] = 0;
	}
}

static void
gpr_begin(struct gpr_pkt *p, uint32_t src, uint32_t dst, uint32_t opcode)
{
	uint32_t tok = __atomic_add_fetch(&gpr_token, 1u, __ATOMIC_RELAXED);
	p->len = 0;
	gpr_put32(p, 0);
	gpr_put32(p, GPR_DOMAIN_ADSP | (GPR_DOMAIN_APPS << 8));
	gpr_put32(p, src);
	gpr_put32(p, dst);
	gpr_put32(p, tok);
	gpr_put32(p, opcode);
}

static uint32_t
gpr_finish(struct gpr_pkt *p)
{
	gpr_set32(p, 0, (6u << 4) | (p->len << 8));
	return p->len;
}

static uint32_t
gpr_cmd_begin(struct gpr_pkt *p)
{
	uint32_t at = p->len;
	gpr_put32(p, 0);
	gpr_put32(p, 0);
	gpr_put32(p, 0);
	gpr_put32(p, 0);
	return at;
}

static void
gpr_cmd_end(struct gpr_pkt *p, uint32_t at)
{
	gpr_set32(p, at + 12, p->len - at - 16);
}

static uint32_t
gpr_param_begin(struct gpr_pkt *p, uint32_t iid, uint32_t id)
{
	uint32_t at = p->len;
	gpr_put32(p, iid);
	gpr_put32(p, id);
	gpr_put32(p, 0);
	gpr_put32(p, 0);
	return at;
}

static void
gpr_param_end(struct gpr_pkt *p, uint32_t at)
{
	gpr_pad_to(p, at + ((p->len - at + 7u) & ~7u));
	gpr_set32(p, at + 8, p->len - at - 16);
}

struct reach_module {
	uint32_t module;
	uint32_t iid;
	uint32_t inputs;
	uint32_t outputs;
};

struct reach_link {
	uint32_t from;
	uint32_t to;
};

static void
gpr_graph_open(struct gpr_pkt *p, uint32_t sg, uint32_t dir, const struct reach_module *m,
    unsigned num_mods, const struct reach_link *links, unsigned num_links)
{
	gpr_begin(p, OUR_PORT, APM_IID, OP_GRAPH_OPEN);
	uint32_t cmd = gpr_cmd_begin(p);

	uint32_t at = gpr_param_begin(p, APM_IID, 0x08001001);
	gpr_put32(p, 1);
	gpr_put32(p, sg);
	gpr_put32(p, 3);
	gpr_put32(p, 0x0800100e); gpr_put32(p, 4); gpr_put32(p, 2);
	gpr_put32(p, 0x0800100f); gpr_put32(p, 4); gpr_put32(p, dir);
	gpr_put32(p, 0x08001010); gpr_put32(p, 4); gpr_put32(p, 1);
	gpr_param_end(p, at);

	at = gpr_param_begin(p, APM_IID, 0x08001000);
	gpr_put32(p, 1);
	gpr_put32(p, sg);
	gpr_put32(p, 4);
	gpr_put32(p, 0x08001011); gpr_put32(p, 8); gpr_put32(p, 1); gpr_put32(p, 0x0b001001);
	gpr_put32(p, 0x08001012); gpr_put32(p, 4); gpr_put32(p, 1);
	gpr_put32(p, 0x08001013); gpr_put32(p, 4); gpr_put32(p, 8192);
	gpr_put32(p, 0x08001014); gpr_put32(p, 4); gpr_put32(p, 2);
	gpr_param_end(p, at);

	at = gpr_param_begin(p, APM_IID, 0x08001002);
	gpr_put32(p, 1);
	gpr_put32(p, sg);
	gpr_put32(p, sg);
	gpr_put32(p, num_mods);
	for (unsigned i = 0; i < num_mods; i++) {
		gpr_put32(p, m[i].module);
		gpr_put32(p, m[i].iid);
	}
	gpr_param_end(p, at);

	at = gpr_param_begin(p, APM_IID, 0x08001003);
	gpr_put32(p, num_mods);
	for (unsigned i = 0; i < num_mods; i++) {
		gpr_put32(p, m[i].iid);
		gpr_put32(p, 1);
		gpr_put32(p, 0x08001015);
		gpr_put32(p, 8);
		gpr_put32(p, m[i].inputs);
		gpr_put32(p, m[i].outputs);
	}
	gpr_param_end(p, at);

	at = gpr_param_begin(p, APM_IID, 0x08001004);
	gpr_put32(p, num_links);
	for (unsigned i = 0; i < num_links; i++) {
		gpr_put32(p, links[i].from);
		gpr_put32(p, 1);
		gpr_put32(p, links[i].to);
		gpr_put32(p, 2);
	}
	gpr_param_end(p, at);

	gpr_cmd_end(p, cmd);
	gpr_finish(p);
}

bool
annibale_audio_reach_send_cmd(const void *raw_pkt, uint32_t raw_len, const char *descr,
    uint32_t *rsp_opcode, uint32_t *rsp_words, uint32_t max_words)
{
	if (reach_buffer == NULL || raw_pkt == NULL || raw_len < 24 || raw_len > sizeof(struct gpr_pkt)) {
		return false;
	}
	struct gpr_pkt p;
	memcpy(p.buf, raw_pkt, raw_len);
	p.len = raw_len;

	lck_mtx_lock(cmd_oob_lock);
	if (p.len > 512) {
		uint32_t payload_len = p.len - 40;
		if (map_handle != 0 && payload_len <= BUFFER_BYTES - CMD_OFFSET) {
			for (uint32_t i = 0; i < payload_len; i++) {
				reach_buffer[CMD_OFFSET + i] = p.buf[40 + i];
			}
			__builtin_arm_dsb(0xf);
			uint64_t at_addr = dsp_address + CMD_OFFSET;
			uint32_t hdr[4] = {
				(uint32_t)at_addr,
				(uint32_t)(at_addr >> 32),
				map_handle,
				payload_len
			};
			memcpy(p.buf + 24, hdr, sizeof(hdr));
			p.len = 40;
			gpr_finish(&p);
		}
	} else if (p.len <= BUFFER_BYTES - CMD_OFFSET) {
		for (uint32_t i = 0; i < p.len; i++) {
			reach_buffer[CMD_OFFSET + i] = p.buf[i];
		}
		__builtin_arm_dsb(0xf);
	}

	uint32_t request_opcode = 0;
	memcpy(&request_opcode, p.buf + 20, sizeof(request_opcode));
	/* AudioReach control requests use a five-second deadline in upstream Linux. */
	uint32_t wait_ms = request_opcode == APM_CMD_GET_SPF_STATE ? 5000u : 250u;
	uint32_t rop = 0;
	uint32_t rwords[16] = { 0 };
	bool ok = annibale_adsp_gpr_send(p.buf, p.len, wait_ms, &rop, rwords, 16);
	lck_mtx_unlock(cmd_oob_lock);

	if (rsp_opcode != NULL) {
		*rsp_opcode = rop;
	}
	if (rsp_words != NULL && max_words > 0) {
		memcpy(rsp_words, rwords, MIN(max_words, 16u) * 4u);
	}
	if (descr != NULL && strcmp(descr, "WRITE (AUDIO_PERIOD)") != 0) {
		uint32_t tok = 0;
		memcpy(&tok, p.buf + 16, 4);
		say("APM command '%s' (len %u, token %u) -> ok %u rsp %#x first %#x second %#x\n",
		    descr, p.len, tok, ok, rop, rwords[0], rwords[1]);
	}
	return ok;
}

static bool
gpr_send_command(struct gpr_pkt *p, const char *descr)
{
	uint32_t opcode = 0;
	return annibale_audio_reach_send_cmd(p->buf, p->len, descr, &opcode, NULL, 0) &&
	    opcode == GPR_BASIC_RSP_RESULT;
}

static bool
gpr_graph_cmd(uint32_t opcode, uint32_t sg, const char *descr)
{
	struct gpr_pkt p;
	gpr_begin(&p, OUR_PORT, APM_IID, opcode);
	uint32_t cmd = gpr_cmd_begin(&p);
	uint32_t at = gpr_param_begin(&p, APM_IID, 0x08001005);
	gpr_put32(&p, 1);
	gpr_put32(&p, sg);
	gpr_param_end(&p, at);
	gpr_cmd_end(&p, cmd);
	gpr_finish(&p);
	return gpr_send_command(&p, descr);
}

bool
annibale_audio_reach_dma_info(volatile uint8_t **va_out, uint64_t *pa_out,
    uint64_t *dsp_addr_out, uint32_t *map_handle_out)
{
	if (reach_buffer == NULL) {
		return false;
	}
	if (va_out != NULL) {
		*va_out = reach_buffer;
	}
	if (pa_out != NULL) {
		*pa_out = buffer_pa;
	}
	if (dsp_addr_out != NULL) {
		*dsp_addr_out = dsp_address;
	}
	if (map_handle_out != NULL) {
		*map_handle_out = map_handle;
	}
	return true;
}

/* GPR channel publication can precede APM port registration. Graph setup requires SPF Ready. */
static bool
wait_for_spf_ready(struct gpr_pkt *p)
{
	uint64_t deadline = 0;
	clock_interval_to_deadline(8000u, NSEC_PER_MSEC, &deadline);
	for (;;) {
		uint64_t now = 0, remaining_ns = 0;
		clock_get_uptime(&now);
		if (now >= deadline) return false;
		absolutetime_to_nanoseconds(deadline - now, &remaining_ns);
		uint32_t wait_ms = (uint32_t)(remaining_ns / NSEC_PER_MSEC);
		if (wait_ms == 0) return false;
		/* Cap each in-band query so a packet dropped before APM registers its port retries promptly. */
		uint32_t attempt_ms = wait_ms > 200u ? 200u : wait_ms;

		gpr_begin(p, OUR_PORT, APM_IID, APM_CMD_GET_SPF_STATE);
		gpr_finish(p);
		uint32_t rop = 0, rwords[2] = { ~0u, ~0u };
		/* The 24-byte query is in-band and does not refer to the shared OOB buffer. */
		bool ok = annibale_adsp_gpr_send(p->buf, p->len, attempt_ms, &rop, rwords, 2);
		uint32_t tok = 0;
		memcpy(&tok, p->buf + 16, sizeof(tok));
		say("APM command '%s' (len %u, token %u) -> ok %u rsp %#x first %#x second %#x\n",
		    "GET_SPF_STATE", p->len, tok, ok, rop, rwords[0], rwords[1]);
		clock_get_uptime(&now);
		if (now >= deadline) return false;

		if (ok && rop == APM_CMD_RSP_GET_SPF_STATE) {
			if (rwords[0] == APM_SPF_STATE_READY) return true;
			if (rwords[0] != APM_SPF_STATE_NOT_READY) return false;
		} else if (!ok && rop == 0) {
			/* No reply arrived within attempt_ms; resend after the retry interval. */
		} else if (rop != GPR_BASIC_RSP_RESULT || rwords[0] != APM_CMD_GET_SPF_STATE ||
		    rwords[1] != AR_ENOTEXIST) {
			return false;
		}

		uint64_t retry_deadline = 0;
		clock_interval_to_deadline(50u, NSEC_PER_MSEC, &retry_deadline);
		if (retry_deadline > deadline) retry_deadline = deadline;
		assert_wait_deadline((event_t)&gpr_token, THREAD_UNINT, retry_deadline);
		thread_block(THREAD_CONTINUE_NULL);
	}
}

/* Build AudioReach APM Playback Graphs */
static bool send_audio_period(uint32_t slot);
static bool queue_audio_period_async(uint32_t slot);

static bool
build_audioreach_graphs(void)
{
	static const struct reach_module speaker_mods[] = {
		{ MOD_I2S_SINK, IID_SPEAKER_I2S, 1, 0 }
	};
	static const struct reach_module play_mods[] = {
		{ MOD_WR_SHMEM, IID_PLAY_SHMEM, 0, 1 },
		{ MOD_PCM_DEC, IID_PLAY_DEC, 1, 1 },
		{ MOD_PCM_CNV, IID_PLAY_CNV, 1, 1 }
	};
	static const struct reach_link play_links[] = {
		{ IID_PLAY_SHMEM, IID_PLAY_DEC },
		{ IID_PLAY_DEC, IID_PLAY_CNV },
		{ IID_PLAY_CNV, IID_SPEAKER_I2S }
	};

	struct gpr_pkt p;
	uint32_t rop = 0;
	uint32_t rwords[4] = { 0 };

	/* 0. Query SPF state */
	if (!wait_for_spf_ready(&p)) return false;

	/* 1. Map contiguous 64 KiB buffer [0xcf66f000, 0xcf67f000) to ADSP */
	gpr_begin(&p, OUR_PORT, APM_IID, OP_MEM_MAP);
	gpr_put16(&p, 3);
	gpr_put16(&p, 1);
	gpr_put32(&p, 0);
	gpr_put32(&p, (uint32_t)dsp_address);
	gpr_put32(&p, (uint32_t)(dsp_address >> 32));
	gpr_put32(&p, BUFFER_BYTES);
	gpr_finish(&p);
	rop = 0;
	rwords[0] = 0;
	if (!annibale_audio_reach_send_cmd(p.buf, p.len, "MEM_MAP", &rop, rwords, 4) ||
	    rop != OP_MEM_MAP_DONE || rwords[0] == 0) return false;
	map_handle = rwords[0];
	say("OP_MEM_MAP_DONE: dsp_address=%#llx size=%#x map_handle=%#x\n",
	    dsp_address, BUFFER_BYTES, map_handle);

	/* 2. Open SG_SPEAKER */
	gpr_graph_open(&p, SG_SPEAKER, 1, speaker_mods, 1, NULL, 0);
	if (!gpr_send_command(&p, "OPEN SG_SPEAKER (0x4005)")) return false;

	/* 3. Configure I2S sink (secondary MI2S, 48 kHz 32-bit stereo) */
	gpr_begin(&p, OUR_PORT, APM_IID, OP_SET_CFG);
	uint32_t cmd = gpr_cmd_begin(&p);
	uint32_t at = gpr_param_begin(&p, IID_SPEAKER_I2S, 0x08001019);
	gpr_put32(&p, 0); gpr_put32(&p, 1); gpr_put16(&p, 2); gpr_put16(&p, 1);
	gpr_param_end(&p, at);
	at = gpr_param_begin(&p, IID_SPEAKER_I2S, 0x08001018);
	gpr_put32(&p, 1);
	gpr_param_end(&p, at);
	at = gpr_param_begin(&p, IID_SPEAKER_I2S, 0x08001017);
	gpr_put32(&p, RATE); gpr_put16(&p, 32); gpr_put16(&p, CHANNELS); gpr_put32(&p, 1);
	gpr_param_end(&p, at);
	gpr_cmd_end(&p, cmd);
	gpr_finish(&p);
	if (!gpr_send_command(&p, "SET_CFG I2S SINK")) return false;

	/* 4. Open SG_PLAY */
	gpr_graph_open(&p, SG_PLAY, 2, play_mods, 3, play_links, 3);
	if (!gpr_send_command(&p, "OPEN SG_PLAY (0x4001)")) return false;

	/* The shared-memory endpoint needs its input format before PREPARE. */
	gpr_begin(&p, OUR_PORT, IID_PLAY_SHMEM, OP_SET_CFG);
	cmd = gpr_cmd_begin(&p);
	at = gpr_param_begin(&p, IID_PLAY_SHMEM, 0x0800100c);
	gpr_put32(&p, 1); gpr_put32(&p, 0x09001000); gpr_put32(&p, 18);
	gpr_put32(&p, RATE);
	gpr_put16(&p, 16); gpr_put16(&p, 1); gpr_put16(&p, 16); gpr_put16(&p, 15);
	gpr_put16(&p, 1); gpr_put16(&p, CHANNELS);
	gpr_put8(&p, 1); gpr_put8(&p, 2);
	gpr_param_end(&p, at);
	gpr_cmd_end(&p, cmd);
	gpr_finish(&p);
	if (!gpr_send_command(&p, "SET_CFG WR_SHMEM PCM input")) return false;

	/* CNV expands Q15 input to Q31 for the 32-bit I2S slots. Payload sizes exclude padding. */
	gpr_begin(&p, OUR_PORT, APM_IID, OP_SET_CFG);
	cmd = gpr_cmd_begin(&p);
	const uint32_t pcm_iids[] = { IID_PLAY_DEC, IID_PLAY_CNV };
	for (unsigned i = 0; i < 2; i++) {
		const uint16_t width = pcm_iids[i] == IID_PLAY_CNV ? 32u : 16u;
		const uint16_t interleaved = pcm_iids[i] == IID_PLAY_CNV ? 3u : 1u;
		at = gpr_param_begin(&p, pcm_iids[i], 0x08001008);
		gpr_put32(&p, 1); gpr_put32(&p, 0x09001000); gpr_put32(&p, 18);
		gpr_put16(&p, width); gpr_put16(&p, 1); gpr_put16(&p, width); gpr_put16(&p, width - 1u);
		gpr_put16(&p, 1); gpr_put16(&p, interleaved); gpr_put16(&p, 0); gpr_put16(&p, CHANNELS);
		gpr_put8(&p, 1); gpr_put8(&p, 2);
		gpr_param_end(&p, at);
	}
	gpr_cmd_end(&p, cmd);
	gpr_finish(&p);
	if (!gpr_send_command(&p, "SET_CFG PCM_DEC & CNV")) return false;

	/* 6. Start Subgraphs */
	if (!gpr_graph_cmd(OP_GRAPH_PREPARE, SG_SPEAKER, "PREPARE SG_SPEAKER")) return false;
	if (!gpr_graph_cmd(OP_GRAPH_START, SG_SPEAKER, "START SG_SPEAKER")) return false;
	if (!gpr_graph_cmd(OP_GRAPH_PREPARE, SG_PLAY, "PREPARE SG_PLAY")) return false;
	if (!gpr_graph_cmd(OP_GRAPH_START, SG_PLAY, "START SG_PLAY")) return false;

	/* Prime smart amplifiers with cold calibration while BCLK is active, then hold in low-power standby */
#if defined(KERNEL)
	for (uint32_t s = 0; s < IN_FLIGHT; s++) {
		if (reach_buffer != NULL) {
			bzero(__DEVOLATILE(void *, reach_buffer + s * PERIOD_BYTES), PERIOD_BYTES);
		}
		(void)queue_audio_period_async(s);
	}
#elif defined(AUDIOREACH_ROUTING_TEST)
	for (uint32_t s = 0; s < 4; s++) {
		if (reach_buffer != NULL) {
			bzero(__DEVOLATILE(void *, reach_buffer + s * PERIOD_BYTES), PERIOD_BYTES);
		}
		(void)send_audio_period(s);
	}
#endif
	(void)annibale_audio_amp_power(true);
	(void)annibale_audio_amp_power(false);
#if defined(KERNEL)
	uint32_t wait_iters = 0;
	while (__atomic_load_n(&in_flight_mask, __ATOMIC_ACQUIRE) != 0) {
		if (++wait_iters > 30) {
			say("audioreach: waiting for warmup inflight timed out after 300 ms, clearing\n");
			__atomic_store_n(&in_flight_mask, 0, __ATOMIC_RELEASE);
			break;
		}
		assert_wait_timeout((event_t)__DEVOLATILE(void *, &in_flight_mask), THREAD_UNINT, 10, NSEC_PER_MSEC);
		thread_block(THREAD_CONTINUE_NULL);
	}
#endif

	say("AudioReach graphs SG_PLAY (0x4001) & SG_SPEAKER (0x4005) initialized and started\n");
	return true;
}

/* Transmit 20 ms PCM period to ADSP */
static bool
send_audio_period(uint32_t slot)
{
	struct gpr_pkt p;
	uint64_t period_addr = dsp_address + (uint64_t)slot * PERIOD_BYTES;

	__builtin_arm_dsb(0xf);
	gpr_begin(&p, OUR_PORT, IID_PLAY_SHMEM, OP_WRITE);
	gpr_put32(&p, (uint32_t)period_addr);
	gpr_put32(&p, (uint32_t)(period_addr >> 32));
	gpr_put32(&p, map_handle);
	gpr_put32(&p, PERIOD_BYTES);
	gpr_put32(&p, 0); gpr_put32(&p, 0); gpr_put32(&p, 0);
	/* V2 includes the metadata address, map handle and size even without metadata. */
	for (unsigned i = 0; i < 4; i++) gpr_put32(&p, 0);
	gpr_finish(&p);
	uint32_t opcode = 0, words[8] = { 0 };
	if (!annibale_audio_reach_send_cmd(p.buf, p.len, "WRITE (AUDIO_PERIOD)", &opcode, words, 8) ||
	    opcode != OP_WRITE_DONE || words[0] != (uint32_t)period_addr ||
	    words[1] != (uint32_t)(period_addr >> 32) || words[2] != map_handle || words[3] != 0 || words[7] != 0) {
		return false;
	}
	reach_sent_count++;
	reach_done_count++;
	/* Confirm the first completed period, then sample progress once per second. */
	if (reach_done_count == 1 || reach_done_count % 50 == 0) {
		say("PCM periods: slot %u sent %u done %u\n", slot, reach_sent_count, reach_done_count);
	}
	return true;
}

bool
annibale_audio_reach_is_active(void)
{
	return __atomic_load_n(&reach_stream_active, __ATOMIC_RELAXED) ||
	    __atomic_load_n(&in_flight_mask, __ATOMIC_RELAXED) != 0;
}

static bool
reach_gpr_event(uint32_t src_port, uint32_t dst_port, uint32_t opcode,
    uint32_t token __unused, const void *payload, uint32_t len)
{
	if (src_port != IID_PLAY_SHMEM || dst_port != OUR_PORT || opcode != OP_WRITE_DONE) {
		return false;
	}
	if (payload == NULL || len < 32) {
		__atomic_store_n(&reach_write_failed, true, __ATOMIC_RELEASE);
		thread_wakeup((event_t)__DEVOLATILE(void *, &in_flight_mask));
		return true;
	}
	uint32_t words[8];
	memcpy(words, payload, sizeof(words));
	uint64_t done_addr = ((uint64_t)words[1] << 32) | words[0];
	if (words[2] != map_handle || words[3] != 0 || words[7] != 0 ||
	    done_addr < dsp_address || done_addr >= dsp_address + (uint64_t)SLOTS * PERIOD_BYTES ||
	    ((done_addr - dsp_address) % PERIOD_BYTES) != 0) {
		__atomic_store_n(&reach_write_failed, true, __ATOMIC_RELEASE);
		thread_wakeup((event_t)__DEVOLATILE(void *, &in_flight_mask));
		return true;
	}

	uint32_t slot = (uint32_t)((done_addr - dsp_address) / PERIOD_BYTES);
	uint32_t done = 0, sent = 0;
	lck_spin_lock(audio_spin_lock);
	in_flight_mask &= ~(1u << slot);
	done = ++reach_done_count;
	sent = reach_sent_count;
	lck_spin_unlock(audio_spin_lock);

	if (done == 1 || done % 50 == 0) {
		say("PCM periods: slot %u sent %u done %u\n", slot, sent, done);
	}
	thread_wakeup((event_t)__DEVOLATILE(void *, &in_flight_mask));
	return true;
}

static bool
queue_audio_period_async(uint32_t slot)
{
	struct gpr_pkt p;
	uint64_t period_addr = dsp_address + (uint64_t)slot * PERIOD_BYTES;

	__builtin_arm_dsb(0xf);
	gpr_begin(&p, OUR_PORT, IID_PLAY_SHMEM, OP_WRITE);
	gpr_put32(&p, (uint32_t)period_addr);
	gpr_put32(&p, (uint32_t)(period_addr >> 32));
	gpr_put32(&p, map_handle);
	gpr_put32(&p, PERIOD_BYTES);
	gpr_put32(&p, 0); gpr_put32(&p, 0); gpr_put32(&p, 0);
	for (unsigned i = 0; i < 4; i++) gpr_put32(&p, 0);
	gpr_finish(&p);

	lck_spin_lock(audio_spin_lock);
	in_flight_mask |= (1u << slot);
	lck_spin_unlock(audio_spin_lock);

	if (!annibale_adsp_gpr_send(p.buf, p.len, 0, NULL, NULL, 0)) {
		lck_spin_lock(audio_spin_lock);
		in_flight_mask &= ~(1u << slot);
		lck_spin_unlock(audio_spin_lock);
		return false;
	}
	lck_spin_lock(audio_spin_lock);
	reach_sent_count++;
	lck_spin_unlock(audio_spin_lock);
	return true;
}

/* Consume audio from ring buffer, run speaker guard, and fill DMA slot */
static bool
fill_period_slot(uint32_t slot, bool muted)
{
	int16_t local[PERIOD_FRAMES * CHANNELS];
	volatile int16_t *out = (volatile int16_t *)(volatile void *)(reach_buffer + slot * PERIOD_BYTES);
	bool has_audio = false;

	lck_spin_lock(audio_spin_lock);
	for (uint32_t i = 0; i < PERIOD_FRAMES; i++) {
		int16_t l = 0, r = 0;
		if (ring_tail != ring_head) {
			uint32_t at = ring_tail & RING_MASK;
			l = ring_storage[2 * at];
			r = ring_storage[2 * at + 1];
			ring_tail++;
		}
		if (muted) {
			l = 0;
			r = 0;
		}
		local[2 * i] = l;
		local[2 * i + 1] = r;
		if (l > 8 || l < -8 || r > 8 || r < -8) {
			has_audio = true;
		}
	}
	lck_spin_unlock(audio_spin_lock);

	/* Run speaker protection (200 Hz second-order HPF + thermal/excursion limiter) */
	annibale_guard_process(local, PERIOD_FRAMES);

	for (uint32_t s = 0; s < PERIOD_FRAMES * CHANNELS; s++) {
		out[s] = local[s];
	}
	if (annibale_audio_recording_fed()) {
		__builtin_arm_dsb(0xf);
		annibale_audio_record_fed(__DEVOLATILE(const int16_t *, out), PERIOD_FRAMES);
	}
	return has_audio;
}

/* Feeder background thread with 4-slot async GPR pipelining paced by ADSP I2S1 clock */
static void
reach_feeder_thread(void *arg __unused, wait_result_t w __unused)
{
	uint32_t next = 0;
	uint32_t quiet_count = QUIET_PERIODS;
	bool amp_powered = false;
	uint32_t amp_retry_cooldown = 0;
	uint32_t last_vol_gen = 0;
	uint32_t vol_below = 18 * 8;
	bool vol_muted = false;
	bool graphs_built_on_hw = false;
	bool report_drain = false;

	say("feeder thread running, waiting for LPASS ADSP GPR channel...\n");
	for (unsigned wait = 0; wait < 240 && !annibale_adsp_gpr_ready(); wait++) {
		delay_for_interval(50, NSEC_PER_MSEC);
	}
	if (annibale_adsp_gpr_ready()) {
		graphs_built_on_hw = build_audioreach_graphs();
	}
	if (!graphs_built_on_hw) {
		__atomic_store_n(&reach_write_failed, true, __ATOMIC_RELEASE);
		__atomic_store_n(&reach_stream_active, false, __ATOMIC_RELAXED);
		say("AudioReach graph setup failed; playback stopped\n");
		thread_terminate(current_thread());
		return;
	}
	for (;;) {
		if (__atomic_load_n(&reach_write_failed, __ATOMIC_ACQUIRE)) {
			__atomic_store_n(&reach_stream_active, false, __ATOMIC_RELAXED);
			(void)annibale_audio_amp_power(false);
			say("PCM completion failed; playback stopped\n");
			thread_terminate(current_thread());
			return;
		}

		uint32_t cur_below = 0, cur_gen = 0;
		bool cur_muted = false;
		if (annibale_audio_volume(&cur_below, &cur_muted, &cur_gen) && cur_gen != last_vol_gen) {
			last_vol_gen = cur_gen;
			vol_below = cur_below;
			vol_muted = cur_muted;
			annibale_guard_attenuation(vol_muted ? ANNIBALE_GUARD_SILENT : vol_below);
			annibale_audio_amp_set_volume(vol_below, vol_muted);
		}

		uint32_t backlog = 0, inflight = 0, sent = 0, done = 0;
		bool slot_busy = false;
		lck_spin_lock(audio_spin_lock);
		backlog = ring_head - ring_tail;
		inflight = (uint32_t)__builtin_popcount(in_flight_mask);
		slot_busy = (in_flight_mask & (1u << (next % SLOTS))) != 0;
		sent = reach_sent_count;
		done = reach_done_count;
		lck_spin_unlock(audio_spin_lock);

		bool active = (backlog > 0) || (inflight > 0) || (amp_powered && quiet_count < QUIET_PERIODS);
		__atomic_store_n(&reach_stream_active, active, __ATOMIC_RELAXED);
		if (!active && report_drain) {
			say("PCM drained: sent %u done %u backlog %u inflight %u completion_error %u\n",
			    sent, done, backlog, inflight, (unsigned)__atomic_load_n(&reach_write_failed, __ATOMIC_ACQUIRE));
			report_drain = false;
		}

		while (inflight < IN_FLIGHT && !slot_busy) {
			bool have_work = (backlog >= PERIOD_FRAMES) ||
			    (backlog > 0 && inflight == 0) ||
			    (backlog == 0 && amp_powered && quiet_count < QUIET_PERIODS && inflight < 2);
			if (!have_work) {
				break;
			}
			if (!amp_powered && !vol_muted && amp_retry_cooldown == 0) {
				bool non_silent = false;
				lck_spin_lock(audio_spin_lock);
				uint32_t check_frames = backlog < PERIOD_FRAMES ? backlog : PERIOD_FRAMES;
				if (ring_storage != NULL && check_frames > 0) {
					for (uint32_t i = 0; i < check_frames; i++) {
						uint32_t at = (ring_tail + i) & RING_MASK;
						int16_t l = ring_storage[2 * at];
						int16_t r = ring_storage[2 * at + 1];
						if (l > 8 || l < -8 || r > 8 || r < -8) {
							non_silent = true;
							break;
						}
					}
				}
				lck_spin_unlock(audio_spin_lock);

				if (non_silent) {
					for (uint32_t warm_idx = 0;
					    warm_idx < 4 && inflight < IN_FLIGHT && !(in_flight_mask & (1u << (next % SLOTS)));
					    warm_idx++) {
						uint32_t warm_slot = next % SLOTS;
						if (reach_buffer != NULL) {
							bzero(__DEVOLATILE(void *, reach_buffer + warm_slot * PERIOD_BYTES), PERIOD_BYTES);
						}
						bool warm_ok = reach_sync_mode != 0 ?
						    send_audio_period(warm_slot) : queue_audio_period_async(warm_slot);
						if (!warm_ok) {
							__atomic_store_n(&reach_write_failed, true, __ATOMIC_RELEASE);
							__atomic_store_n(&reach_stream_active, false, __ATOMIC_RELAXED);
							(void)annibale_audio_amp_power(false);
							say("PCM warmup submission failed; playback stopped\n");
							thread_terminate(current_thread());
							return;
						}
						next++;
						inflight++;
					}
					report_drain = true;

					if (annibale_audio_amp_power(true)) {
						amp_powered = true;
						quiet_count = 0;
						say("damp: smart amplifier powered on\n");
					} else {
						amp_retry_cooldown = 50;
						static uint32_t amp_startup_errors = 0;
						amp_startup_errors++;
						say("amplifier startup failed (err=%u); continuing\n", amp_startup_errors);
					}
					lck_spin_lock(audio_spin_lock);
					backlog = ring_head - ring_tail;
					lck_spin_unlock(audio_spin_lock);
					inflight = (uint32_t)__builtin_popcount(in_flight_mask);
					slot_busy = (in_flight_mask & (1u << (next % SLOTS))) != 0;
					continue;
				}
			}

			uint32_t slot = next % SLOTS;
			bool loud = fill_period_slot(slot, vol_muted);
			quiet_count = loud ? 0 : quiet_count + 1;
			if (amp_retry_cooldown > 0) {
				amp_retry_cooldown--;
			}
			if (loud && !amp_powered && amp_retry_cooldown == 0) {
				if (annibale_audio_amp_power(true)) {
					amp_powered = true;
					quiet_count = 0;
					say("damp: smart amplifier powered on\n");
				} else {
					amp_retry_cooldown = 50;
					static uint32_t amp_startup_errors = 0;
					amp_startup_errors++;
					say("amplifier startup failed (err=%u); continuing\n", amp_startup_errors);
				}
			}
			__atomic_store_n(&reach_stream_active, true, __ATOMIC_RELAXED);

			bool ok = reach_sync_mode != 0 ?
			    send_audio_period(slot) : queue_audio_period_async(slot);
			if (!ok) {
				__atomic_store_n(&reach_write_failed, true, __ATOMIC_RELEASE);
				__atomic_store_n(&reach_stream_active, false, __ATOMIC_RELAXED);
				(void)annibale_audio_amp_power(false);
				say("PCM submission failed; playback stopped\n");
				thread_terminate(current_thread());
				return;
			}
			report_drain = true;
			next++;

			lck_spin_lock(audio_spin_lock);
			backlog = ring_head - ring_tail;
			inflight = (uint32_t)__builtin_popcount(in_flight_mask);
			slot_busy = (in_flight_mask & (1u << (next % SLOTS))) != 0;
			lck_spin_unlock(audio_spin_lock);
			if (reach_sync_mode != 0 && backlog < PERIOD_FRAMES) {
				break;
			}
		}
		if (amp_powered && quiet_count >= QUIET_PERIODS && inflight == 0 && backlog == 0) {
			if (!annibale_audio_amp_power(false)) {
				say("amplifier powerdown failed; continuing\n");
			}
			amp_powered = false;
			__atomic_store_n(&reach_stream_active, false, __ATOMIC_RELAXED);
		}

		uint32_t wait_ms = active ? 5u : 25u;
		uint64_t deadline = 0;
		clock_interval_to_deadline(wait_ms, NSEC_PER_MSEC, &deadline);
		assert_wait_deadline((event_t)__DEVOLATILE(void *, &in_flight_mask), THREAD_UNINT, deadline);

		lck_spin_lock(audio_spin_lock);
		uint32_t cur_backlog = ring_head - ring_tail;
		uint32_t cur_inflight = (uint32_t)__builtin_popcount(in_flight_mask);
		bool can_feed = cur_inflight < IN_FLIGHT &&
		    (in_flight_mask & (1u << (next % SLOTS))) == 0 &&
		    (cur_backlog >= PERIOD_FRAMES || (cur_backlog > 0 && cur_inflight == 0));
		lck_spin_unlock(audio_spin_lock);

		if (can_feed || __atomic_load_n(&reach_write_failed, __ATOMIC_ACQUIRE)) {
			clear_wait(current_thread(), THREAD_AWAKENED);
		} else {
			thread_block(THREAD_CONTINUE_NULL);
		}
	}
}

/* Annibale Audio sink implementation */
static uint32_t
reach_audio_sink(const int16_t *frames, uint32_t count)
{
	uint32_t taken = 0;
	if (__atomic_load_n(&reach_write_failed, __ATOMIC_ACQUIRE)) {
		return 0;
	}
	if (ring_storage == NULL) {
		return count;
	}
	lck_spin_lock(audio_spin_lock);
	while (taken < count && (ring_head - ring_tail) < RING_FRAMES) {
		uint32_t at = ring_head & RING_MASK;
		ring_storage[2 * at] = frames[2 * taken];
		ring_storage[2 * at + 1] = frames[2 * taken + 1];
		ring_head++;
		taken++;
	}
	lck_spin_unlock(audio_spin_lock);
	if (taken > 0) {
		thread_wakeup((event_t)__DEVOLATILE(void *, &in_flight_mask));
	}
	return taken;
}

/* TLMM secondary MI2S Pin Configuration (i2s1: GPIO121 SCK, GPIO122 DATA0, GPIO123 WS, GPIO124 DATA1) */
static void
configure_i2s_pins(void)
{
	vm_offset_t tlmm = ml_io_map(TLMM_PHYS, TLMM_SIZE);
	if (tlmm == 0) {
		return;
	}
	static const struct {
		unsigned pin;
		uint32_t cfg;
	} i2s_pins[] = {
		{ 121, (1u << 2) | (3u << 6) | 0u }, /* SCK: func 1, 8 mA, no-pull */
		{ 122, (1u << 2) | (3u << 6) | 0u }, /* DATA0: func 1, 8 mA, no-pull */
		{ 123, (1u << 2) | (2u << 6) | 0u }, /* WS: func 1, 6 mA, no-pull */
		{ 124, (1u << 2) | (3u << 6) | 1u }, /* DATA1: func 1, 8 mA, pull-down */
	};
	for (unsigned i = 0; i < sizeof(i2s_pins) / sizeof(i2s_pins[0]); i++) {
		vm_offset_t reg = tlmm + 0x1000UL * i2s_pins[i].pin;
		uint32_t val = *(volatile uint32_t *)reg;
		val = (val & ~(0x3ffu)) | i2s_pins[i].cfg;
		if (val & (1u << 11)) {
			val |= (1u << 12); /* Hand to AP */
		}
		*(volatile uint32_t *)reg = val;
		__builtin_arm_dsb(0xf);
	}
	say("I2S1 TLMM pins GPIO121-124 configured for secondary MI2S (func 1)\n");
}

void
annibale_audio_reach_init(void)
{
	say("initializing ADSP AudioReach & LPASS subsystem...\n");

	if (audio_lock_grp == NULL) {
		audio_lock_grp = lck_grp_alloc_init("reach-audio", LCK_GRP_ATTR_NULL);
		audio_spin_lock = lck_spin_alloc_init(audio_lock_grp, LCK_ATTR_NULL);
		cmd_oob_lock = lck_mtx_alloc_init(audio_lock_grp, LCK_ATTR_NULL);
	}

	/* 1. Start or attach to SM8750 LPASS ADSP */
	annibale_adsp_init();

	/* 2. Configure LPASS SMMU streams 0x1001, 0x1081, 0x1061 for stage-1 bypass */
	(void)smmu_configure_bypass(AUDIO_STREAM);
	(void)smmu_configure_bypass(AUDIO_STREAM_ALT1);
	(void)smmu_configure_bypass(AUDIO_STREAM_ALT2);

	/* 3. Locate 64 KiB DMA buffer in lowdma [0xcf66f000, 0xcf67f000) */
	uint64_t low = 0, mb = 0;
	if (PE_parse_boot_argn("lowdma", &low, sizeof(low)) && low != 0) {
		if (!PE_parse_boot_argn("lowdma_mb", &mb, sizeof(mb)) || mb == 0) {
			mb = 128;
		}
		uint64_t low_end = low + (mb << 20);
		if (LOWDMA_AUDIO_PA >= low && LOWDMA_AUDIO_PA + BUFFER_BYTES <= low_end) {
			buffer_pa = LOWDMA_AUDIO_PA;
		} else if (low_end <= 0x100000000ULL) {
			buffer_pa = low + ((mb - 1) << 20);
		} else {
			buffer_pa = low + 0x766f000ULL;
		}
	} else {
		buffer_pa = LOWDMA_AUDIO_PA;
	}
	/* Low 4 bits of stream 0x1001 go into bits 35:32 of DSP address on SM8750 LPASS SMMU */
	dsp_address = buffer_pa | ((uint64_t)(AUDIO_STREAM & 0x0fu) << 32);
	reach_buffer = (volatile uint8_t *)ml_io_map_wcomb(buffer_pa, BUFFER_BYTES);
	if (reach_buffer == NULL) {
		say("failed to map low DMA buffer at %#llx\n", buffer_pa);
		return;
	}
	bzero(__DEVOLATILE(void *, reach_buffer), BUFFER_BYTES);
	say("64 KiB contiguous DMA buffer ready at PA %#llx (DSP %#llx)\n", buffer_pa, dsp_address);

	/* 4. Allocate local PCM ring and configure speaker protection */
	if (ring_storage == NULL) {
		ring_storage = kalloc_data(RING_FRAMES * CHANNELS * sizeof(int16_t), Z_WAITOK | Z_ZERO);
	}
	annibale_guard_configure(true, 18 * 8);
	annibale_guard_attenuation(18 * 8);

	/* 5. Configure secondary MI2S TLMM pins */
	configure_i2s_pins();

	/* 6. Probe Smart Amplifiers on I2C */
	(void)annibale_audio_amp_probe();

	/* 7. Register GPR completion handler and Annibale Audio sink */
	(void)PE_parse_boot_argn("reach_sync", &reach_sync_mode, sizeof(reach_sync_mode));
	annibale_adsp_set_gpr_event(reach_gpr_event);
	annibale_audio_set_sink("annibale-reach", reach_audio_sink);

	/* 8. Launch feeder thread */
	thread_t th;
	if (kernel_thread_start(reach_feeder_thread, NULL, &th) == KERN_SUCCESS) {
		thread_set_thread_name(th, "reach-audio-feeder");
		thread_deallocate(th);
	}
	say("ADSP AudioReach initialization completed\n");
}

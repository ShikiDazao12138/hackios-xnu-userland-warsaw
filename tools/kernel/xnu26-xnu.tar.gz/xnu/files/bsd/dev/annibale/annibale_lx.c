/*
 * Darwin-on-annibale: the kernel's side of the Wi-Fi driver's object.
 *
 * The driver of the phone's radio is Linux's ath12k, compiled unmodified outside this tree on a
 * layer that gives it the kernel interfaces it expects, and tied into one object that the
 * kernel links when it is there (tools/mk-ath12k.sh and wifi/lx in the repository; the kernel
 * is built with that object when build-macos.sh finds it). The object shows one name, lx_start(),
 * and asks for the calls of sys/annibale_lx.h, which are here: memory, time, threads, one lock
 * to sleep under, the kernel's options. What it asks of the radio itself -- its firmware's
 * files, its view of memory, the card on PCIe -- is mhi_pcie.c's to answer.
 *
 * A kernel built without the object has the lx_start() at the end of this file, which says so.
 */
#include <kern/clock.h>
#include <kern/kalloc.h>
#include <kern/locks.h>
#include <kern/sched_prim.h>
#include <kern/thread.h>
#include <os/atomic_private.h>
#include <libkern/libkern.h>
#include <mach/mach_types.h>
#include <mach/vm_param.h>
#include <pexpert/pexpert.h>
#include <sys/errno.h>
#include <sys/random.h>
#include <sys/annibale_input.h>
#include <sys/annibale_lx.h>
#include <sys/annibale_net.h>
#include <sys/annibale_sta.h>
#include <sys/systm.h>
#include <vm/memory_types.h>
#include <vm/vm_kern.h>
#include "../mhi/mhi_pcie_private.h"

extern vm_offset_t ml_io_map_unmappable(vm_offset_t phys_addr, vm_size_t size, unsigned int flags);
extern uint64_t kvtophys(vm_offset_t va);       /* pmap_paddr_t */
extern kern_return_t thread_terminate(thread_t thread);
extern void thread_set_thread_name(thread_t thread, const char *name);
extern void loader_log_putc(char c);

#define say annibale_wifi_say

static LCK_GRP_DECLARE(lx_lock_group, "annibale-lx");
static LCK_MTX_DECLARE(lx_lock, &lx_lock_group);
static LCK_MTX_DECLARE(say_lock, &lx_lock_group);
static bool leaving;

int
annibale_wifi_say(const char *format, ...)
{
	char line[400];
	va_list list;

	va_start(list, format);
	vsnprintf(line, sizeof(line), format, list);
	va_end(list);
	if (leaving) {
		for (const char *c = line; *c != 0; c++) {
			loader_log_putc(*c);
		}
		return 0;
	}
	lck_mtx_lock(&say_lock);
	for (const char *c = line; *c != 0; c++) {
		loader_log_putc(*c);
	}
	printf("%s", line);
	lck_mtx_unlock(&say_lock);
	return 0;
}

int
annibale_wifi_tell(const char *format, ...)
{
	char line[400];
	va_list list;

	va_start(list, format);
	vsnprintf(line, sizeof(line), format, list);
	va_end(list);
	if (leaving) {
		for (const char *c = line; *c != 0; c++) {
			loader_log_putc(*c);
		}
		return 0;
	}
	lck_mtx_lock(&say_lock);
	for (const char *c = line; *c != 0; c++) {
		loader_log_putc(*c);
	}
	printf("%s", line);
	lck_mtx_unlock(&say_lock);
	return 0;
}

uint32_t
annibale_wifi_option(const char *name)
{
	uint32_t value = 0;

	if (PE_parse_boot_argn(name, &value, sizeof(value))) {
		return value;
	}
	return 0;
}

bool
annibale_wifi_radio_address(uint8_t *address)
{
	char text[32] = "";
	uint8_t bytes[6];
	unsigned count = 0, digits = 0, value = 0;
	bool good;

	if (!PE_parse_boot_arg_str("wifi_mac", text, sizeof(text)) || text[0] == 0) {
		say("wifi: the driver asks for the radio's address: none was given (wifi_mac)\n");
		return false;
	}
	good = true;
	for (const char *c = text;; c++) {
		int digit = *c >= '0' && *c <= '9' ? *c - '0' : *c >= 'a' && *c <= 'f' ? *c - 'a' + 10 : *c >= 'A' && *c <= 'F' ?
		    *c - 'A' + 10 : -1;

		if (digit >= 0 && digits < 2) {
			value = value << 4 | (unsigned)digit;
			digits++;
		} else if ((*c == ':' || *c == 0) && digits != 0 && count < 6) {
			bytes[count++] = (uint8_t)value;
			digits = value = 0;
		} else {
			good = false;
		}
		if (*c == 0 || !good) {
			break;
		}
	}
	good = good && count == 6 && !(bytes[0] & 1) && (bytes[0] | bytes[1] | bytes[2] | bytes[3] | bytes[4] | bytes[5]) != 0;
	if (good) {
		memcpy(address, bytes, sizeof(bytes));
	}
	return good;
}

void
annibale_wifi_stop(void)
{
	annibale_apple80211_summary();
}

void
annibale_wifi_quiesce(void)
{
	leaving = true;
	annibale_apple80211_summary();
}

/* ---- memory ------------------------------------------------------------------------------------------ */

void *
lx_os_alloc(unsigned long size)
{
	return kalloc_data(size, Z_WAITOK | Z_ZERO);
}

void
lx_os_free(void *memory, unsigned long size)
{
	kfree_data(memory, size);
}

void *
lx_os_radio_memory(unsigned long size, unsigned long long *address)
{
	uint64_t physical;

	if (mhi_pcie_radio()) {
		void *memory = mhi_pcie_radio_memory(size, &physical);

		*address = physical;
		return memory;
	}
	return NULL;
}

void *
lx_os_map_registers(unsigned long long physical, unsigned long size)
{
	unsigned long long page = trunc_page(physical);
	vm_offset_t mapped = ml_io_map_unmappable(page, round_page(physical + size) - page, VM_WIMG_IO);

	return mapped == 0 ? NULL : (void *)(mapped + (physical - page));
}

int
lx_os_radio_registers(unsigned long long *physical, unsigned long *size)
{
	uint64_t pa, length;

	if (!mhi_pcie_radio_registers(&pa, &length)) {
		return ENXIO;
	}
	*physical = pa;
	*size = (unsigned long)length;
	return 0;
}

/* ---- saying things ----------------------------------------------------------------------------------- */

void
lx_os_print(const char *text)
{
	say("%s", text);
}

void
lx_os_tell(const char *text)
{
	annibale_wifi_tell("%s", text);
}

void
lx_os_panic(const char *text)
{
	panic("%s", text);
}

/* ---- time, threads, sleeping --------------------------------------------------------------------------- */

unsigned long long
lx_os_nanoseconds(void)
{
	uint64_t nanoseconds;

	absolutetime_to_nanoseconds(mach_absolute_time(), &nanoseconds);
	return nanoseconds;
}

void *
lx_os_thread_self(void)
{
	return current_thread();
}

struct lx_thread {
	void (*function)(void *);
	void *argument;
};

static void
lx_thread_runs(void *parameter, __unused wait_result_t result)
{
	struct lx_thread start = *(struct lx_thread *)parameter;

	kfree_type(struct lx_thread, parameter);
	start.function(start.argument);
	thread_terminate(current_thread());
}

int
lx_os_thread(const char *name, void (*function)(void *), void *argument)
{
	struct lx_thread *start = kalloc_type(struct lx_thread, Z_WAITOK | Z_ZERO);
	thread_t thread;

	if (start == NULL) {
		return ENOMEM;
	}
	start->function = function;
	start->argument = argument;
	if (kernel_thread_start(lx_thread_runs, start, &thread) != KERN_SUCCESS) {
		kfree_type(struct lx_thread, start);
		return EAGAIN;
	}
	thread_set_thread_name(thread, name);
	thread_deallocate(thread);
	return 0;
}

void
lx_os_lock(void)
{
	lck_mtx_lock(&lx_lock);
}

void
lx_os_unlock(void)
{
	lck_mtx_unlock(&lx_lock);
}

int
lx_os_sleep(const void *address, unsigned long long nanoseconds)
{
	uint64_t deadline;

	if (nanoseconds == 0) {
		return lck_mtx_sleep(&lx_lock, LCK_SLEEP_DEFAULT, (event_t)address, THREAD_UNINT) == THREAD_TIMED_OUT;
	}
	nanoseconds_to_absolutetime(nanoseconds, &deadline);
	deadline += mach_absolute_time();
	return lck_mtx_sleep_deadline(&lx_lock, LCK_SLEEP_DEFAULT, (event_t)address, THREAD_UNINT, deadline) == THREAD_TIMED_OUT;
}

void
lx_os_wakeup(const void *address)
{
	thread_wakeup((event_t)address);
}

/* ---- the rest of the machine ------------------------------------------------------------------------- */

void
lx_os_random(void *buffer, unsigned long size)
{
	read_random(buffer, (u_int)size);
}

unsigned
lx_os_option(const char *name)
{
	return annibale_wifi_option(name);
}

int
lx_os_firmware(const char *name, const void **data, unsigned long *size)
{
	uint64_t length = 0;
	const uint8_t *file = mhi_pcie_radio() ? mhi_pcie_radio_file(name, &length) : NULL;

	if (file == NULL) {
		return ENOENT;
	}
	*data = file;
	*size = (unsigned long)length;
	return 0;
}

int
lx_os_rproc_boot(void)
{
	if (mhi_pcie_radio()) {
		return mhi_pcie_radio_boot();
	}
	return ENXIO;
}

int
lx_os_radio_address(unsigned char *address)
{
	return annibale_wifi_radio_address(address);
}

int
lx_os_network(__unused unsigned char *name, __unused unsigned *name_length, __unused unsigned char *passphrase,
    __unused unsigned *passphrase_length)
{
	return 0;
}

/* ---- frames: the radio as the link behind en0 (sys/annibale_net.h) ------------------------------------ */

/*
 * A frame from the network stack comes on whatever thread sends it, and the driver's side keeps
 * a record of every thread that enters it: so frames are put in a queue here, and one thread of
 * ours takes them to the driver. A queue that is full drops what comes (TCP sends it again).
 */
#define LX_QUEUE        256

struct lx_frame {
	uint16_t length;
	uint8_t bytes[ANNIBALE_NET_FRAME_MAX];
};

static bool lx_link_attached;
static LCK_MTX_DECLARE(lx_queue_lock, &lx_lock_group);
static struct lx_frame *lx_queue;
static uint32_t lx_queue_in, lx_queue_out;      /* frames put in and taken out, counted from the start */
static uint64_t lx_queue_dropped;

static void
lx_queue_runs(__unused void *parameter, __unused wait_result_t result)
{
	for (;;) {
		struct lx_frame *frame;

		lck_mtx_lock(&lx_queue_lock);
		while (lx_queue_in == lx_queue_out) {
			lck_mtx_sleep(&lx_queue_lock, LCK_SLEEP_DEFAULT, (event_t)&lx_queue_in, THREAD_UNINT);
		}
		frame = &lx_queue[lx_queue_out % LX_QUEUE];     /* (stays ours until lx_queue_out moves) */
		lck_mtx_unlock(&lx_queue_lock);
		lx_transmit(frame->bytes, frame->length);
		lck_mtx_lock(&lx_queue_lock);
		lx_queue_out++;
		lck_mtx_unlock(&lx_queue_lock);
	}
}

static bool
lx_link_transmit(mbuf_t packet, size_t length)
{
	struct lx_frame *frame;

	lck_mtx_lock(&lx_queue_lock);
	if (length > ANNIBALE_NET_FRAME_MAX || lx_queue_in - lx_queue_out == LX_QUEUE) {
		lx_queue_dropped++;
		lck_mtx_unlock(&lx_queue_lock);
		return false;
	}
	frame = &lx_queue[lx_queue_in % LX_QUEUE];
	if (mbuf_copydata(packet, 0, length, frame->bytes) != 0) {
		lck_mtx_unlock(&lx_queue_lock);
		return false;
	}
	frame->length = (uint16_t)length;
	lx_queue_in++;
	lck_mtx_unlock(&lx_queue_lock);
	thread_wakeup((event_t)&lx_queue_in);
	return true;
}

static struct annibale_net_link lx_link = {
	.name = "the phone's radio (ath12k)",
	.wireless = true,
	.transmit = lx_link_transmit,
};

void
lx_os_net_attach(const unsigned char *address)
{
	thread_t thread;

	if (lx_link_attached) {
		return;
	}
	lx_queue = kalloc_data(LX_QUEUE * sizeof(*lx_queue), Z_WAITOK | Z_ZERO);
	if (lx_queue == NULL || kernel_thread_start(lx_queue_runs, NULL, &thread) != KERN_SUCCESS) {
		say("lx: no memory or no thread for the frames to send: the radio's frames go nowhere\n");
		return;
	}
	thread_set_thread_name(thread, "wifi-send");
	thread_deallocate(thread);
	memcpy(lx_link.address, address, sizeof(lx_link.address));
	lx_link_attached = annibale_net_attach(&lx_link);
	say("lx: %s\n", lx_link_attached ? "the radio is the link behind en0" : "EN0 HAS A LINK ALREADY: the radio's frames go "
	    "nowhere");
}

/*
 * With wifi=1 the interface is made when the kernel starts, before the radio is up: iOS's Wi-Fi
 * side looks for it and for its registry entry as soon as it runs, once, and a radio that
 * turns up twelve seconds later is one it has already failed to open.
 */
void
annibale_lx_net_early(void)
{
	uint8_t address[6];

	if (annibale_wifi_radio_address(address)) {
		lx_os_net_attach(address);
	}
}

void
lx_os_net_link(int up)
{
	if (lx_link_attached) {
		annibale_net_link_state(up != 0);
	}
}

void
lx_os_net_input(const unsigned char *frame, unsigned long length)
{
	if (lx_link_attached && length <= ANNIBALE_NET_FRAME_MAX) {
		annibale_net_input(frame, length);
	}
}

/* ---- the radio's interrupts ------------------------------------------------------------------------------- */

extern kern_return_t gic_v3_spi_attach(uint32_t intid, bool edge, void (*handler)(void *context, uint32_t intid), void *context);
extern void gic_v3_spi_mask(uint32_t intid);
extern void gic_v3_spi_unmask(uint32_t intid);
extern void gic_v3_spi_detach(uint32_t intid);
extern uint64_t gic_v3_spi_count(uint32_t intid);

#define LX_VECTORS      32

static struct {
	void (*function)(void *);
	void *argument;
	bool attached;
	bool enabled;
} lx_vector[LX_VECTORS];
static uint32_t lx_irq_first = 181;             /* DesignWare PCIe RC0 MSI -> GICv3 edge SPI INTID 181..184 */
static uint32_t lx_irq_pending;                 /* the vectors that have fired and are not dealt with yet */
static uint32_t lx_irq_running;                 /* the vectors whose function the thread is in */
static thread_t lx_irq_thread;
static LCK_MTX_DECLARE(lx_irq_lock, &lx_lock_group);

/* In interrupt context: the vector masked, DesignWare RC status read & ACKed (W1C), and the thread told. */
static void
lx_irq_arrived(__unused void *context, uint32_t intid)
{
	uint32_t line = intid >= lx_irq_first ? intid - lx_irq_first : 0;
	uint32_t status = 0;
	uint32_t mask = 0;

	gic_v3_spi_mask(intid);
	if (line < 4) {
		status = mhi_pcie_msi_status(line);
		if (status != 0) {
			mhi_pcie_msi_ack(line, status);
		}
	}
	if (status != 0) {
		for (unsigned b = 0; b < 32; b++) {
			unsigned v = line * 32 + b;
			if (v < LX_VECTORS && (status & (1u << b))) {
				if (lx_vector[v].attached) {
					mask |= (1u << v);
				}
			}
		}
	}
	if (mask == 0) {
		for (unsigned b = 0; b < 32; b++) {
			unsigned v = line * 32 + b;
			if (v < LX_VECTORS && lx_vector[v].attached) {
				mask |= (1u << v);
			}
		}
	}
	os_atomic_or(&lx_irq_pending, mask, relaxed);
	thread_wakeup((event_t)&lx_irq_pending);
}

static void
lx_irq_runs(__unused void *parameter, __unused wait_result_t result)
{
	for (;;) {
		uint32_t pending;

		for (;;) {
			assert_wait((event_t)&lx_irq_pending, THREAD_UNINT);
			if ((pending = os_atomic_xchg(&lx_irq_pending, 0, acquire)) != 0) {
				clear_wait(current_thread(), THREAD_AWAKENED);
				break;
			}
			thread_block(THREAD_CONTINUE_NULL);
		}
		for (unsigned v = 0; v < LX_VECTORS; v++) {
			if (!(pending & 1u << v)) {
				continue;
			}
			lck_mtx_lock(&lx_irq_lock);
			if (!lx_vector[v].attached) {
				lck_mtx_unlock(&lx_irq_lock);
				continue;
			}
			lx_irq_running |= 1u << v;
			lck_mtx_unlock(&lx_irq_lock);
			lx_vector[v].function(lx_vector[v].argument);
			lck_mtx_lock(&lx_irq_lock);
			lx_irq_running &= ~(1u << v);
			lck_mtx_unlock(&lx_irq_lock);
			gic_v3_spi_unmask(lx_irq_first + (v / 32));
			thread_wakeup((event_t)&lx_irq_running);
		}
	}
}

extern uint64_t mhi_pcie_get_sink_pa(void);

int
lx_os_irq_msi(unsigned long long *address, unsigned *data)
{
	uint64_t sink = mhi_pcie_get_sink_pa();
	if (sink == 0) {
		sink = 0x40200000ULL;
	}
	if (address != NULL) {
		*address = sink;
	}
	if (data != NULL) {
		*data = 0;
	}
	return 1;
}

int
lx_os_irq_attach(unsigned vector, void (*function)(void *), void *argument)
{
	kern_return_t kr;
	uint32_t spi_intid;

	if (vector >= LX_VECTORS || lx_irq_first == 0 || function == NULL) {
		return EINVAL;
	}
	spi_intid = lx_irq_first + (vector / 32);
	if (lx_irq_thread == THREAD_NULL) {
		annibale_wifi_tell("lx: wifi_irq: GICv3 edge SPI INTID %u..%u attached for radio MSI vectors\n",
		    lx_irq_first, lx_irq_first + 3);
		if (kernel_thread_start(lx_irq_runs, NULL, &lx_irq_thread) != KERN_SUCCESS) {
			lx_irq_thread = THREAD_NULL;
			return ENOMEM;
		}
		thread_set_thread_name(lx_irq_thread, "wifi-irq");
	}
	lck_mtx_lock(&lx_irq_lock);
	lx_vector[vector].function = function;
	lx_vector[vector].argument = argument;
	lx_vector[vector].attached = true;
	lx_vector[vector].enabled = false;
	lck_mtx_unlock(&lx_irq_lock);
	kr = gic_v3_spi_attach(spi_intid, true, lx_irq_arrived, NULL);
	if (kr != KERN_SUCCESS && kr != KERN_NAME_EXISTS) {
		lck_mtx_lock(&lx_irq_lock);
		lx_vector[vector].attached = false;
		lck_mtx_unlock(&lx_irq_lock);
		return kr == KERN_NAME_EXISTS ? EBUSY : EINVAL;
	}
	gic_v3_spi_mask(spi_intid);
	return 0;
}

void
lx_os_irq_enable(unsigned vector)
{
	if (vector < LX_VECTORS && lx_vector[vector].attached) {
		lck_mtx_lock(&lx_irq_lock);
		lx_vector[vector].enabled = true;
		lck_mtx_unlock(&lx_irq_lock);
		gic_v3_spi_unmask(lx_irq_first + (vector / 32));
	}
}

void
lx_os_irq_disable(unsigned vector)
{
	if (vector >= LX_VECTORS || !lx_vector[vector].attached) {
		return;
	}
	lck_mtx_lock(&lx_irq_lock);
	lx_vector[vector].enabled = false;
	bool others_enabled = false;
	unsigned group = vector / 32;
	for (unsigned i = group * 32; i < (group + 1) * 32 && i < LX_VECTORS; i++) {
		if (lx_vector[i].attached && lx_vector[i].enabled) {
			others_enabled = true;
			break;
		}
	}
	if (!others_enabled) {
		gic_v3_spi_mask(lx_irq_first + group);
	}
	lck_mtx_unlock(&lx_irq_lock);
	if (current_thread() == lx_irq_thread) {
		return;                         /* (from the vector's own function, or another's: nothing to wait for) */
	}
	lck_mtx_lock(&lx_irq_lock);
	while (lx_irq_running & (1u << vector)) {
		lck_mtx_sleep(&lx_irq_lock, LCK_SLEEP_DEFAULT, (event_t)&lx_irq_running, THREAD_UNINT);
	}
	lck_mtx_unlock(&lx_irq_lock);
}

void
lx_os_irq_detach_all(void)
{
	for (unsigned g = 0; g < 4; g++) {
		gic_v3_spi_mask(lx_irq_first + g);
		gic_v3_spi_detach(lx_irq_first + g);
	}
	lck_mtx_lock(&lx_irq_lock);
	for (unsigned v = 0; v < LX_VECTORS; v++) {
		lx_vector[v].attached = false;
		lx_vector[v].enabled = false;
	}
	while (lx_irq_running != 0 && current_thread() != lx_irq_thread) {
		lck_mtx_sleep(&lx_irq_lock, LCK_SLEEP_DEFAULT, (event_t)&lx_irq_running, THREAD_UNINT);
	}
	lck_mtx_unlock(&lx_irq_lock);
	os_atomic_store(&lx_irq_pending, 0, relaxed);
}

unsigned long long
lx_os_irq_count(unsigned vector)
{
	return vector < LX_VECTORS && lx_irq_first != 0 ? gic_v3_spi_count(lx_irq_first + (vector / 32)) : 0;
}

/* ---- the station (sys/annibale_sta.h) --------------------------------------------------------------------- */

void
lx_os_station(const struct annibale_sta_ops *ops)
{
	annibale_sta_attach(ops);
}

void
lx_os_station_lost(int error)
{
	annibale_sta_lost(error);
}

/* ---- the driver ---------------------------------------------------------------------------------------- */

/* The object has its own; this is the one of a kernel built without it. */
__attribute__((weak)) int
lx_start(void)
{
	say("lx: THE DRIVER IS NOT BUILT IN: its object was not there when this kernel was built (tools/mk-ath12k.sh, then "
	    "build the kernel again)\n");
	return ENXIO;
}

__attribute__((weak)) void
lx_stop(void)
{
}

__attribute__((weak)) int
lx_prepare(void)
{
	return 0;
}

__attribute__((weak)) int
lx_transmit(__unused const unsigned char *frame, __unused unsigned long length)
{
	return ENXIO;
}

int
annibale_lx_start(void)
{
	return lx_start();
}

void
annibale_lx_stop(void)
{
	lx_stop();
}

int
annibale_lx_prepare(void)
{
	return lx_prepare();
}

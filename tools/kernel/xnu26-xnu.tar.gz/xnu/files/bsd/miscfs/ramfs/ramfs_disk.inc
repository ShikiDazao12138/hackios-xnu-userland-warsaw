/*
 * Direct UFS persistence for /private/var (ANNFS001).
 *
 * File data pages are written straight through to 16 KB blocks on /dev/ufs_darwin_var
 * at ANNFS_DATA_OFFSET + dblk * PAGE_SIZE, and faulted in on demand when read.
 * Metadata (inodes, directories, symlinks, extended attributes, and per-file block
 * tables) is checkpointed to two alternating 32 MiB slots at the start of the
 * partition (0 MiB and 32 MiB), each protected by superblock and payload CRC32s.
 */

extern bool annibale_ufs_var_info(uint64_t *size_bytes_out);
extern int annibale_ufs_var_io(bool write, uint64_t offset, void *buf, uint64_t len);

#define ANNFS_MAGIC_STR          "ANNFS001"
#define ANNFS_VERSION            3u
#define rm_disk_enabled          rm_disk_backed
#define ANNFS_SUPER_BYTES        4096u
#define ANNFS_SLOT0_OFFSET       0ULL
#define ANNFS_SLOT1_OFFSET       (32ULL << 20)
#define ANNFS_SLOT_MAX           (32ULL << 20)
/*
 * How often a dirty volume is checkpointed, and what a checkpoint costs.
 *
 * The 1.5 s below is how much of /private/var a hard reset could lose, so it is short on purpose; but a
 * checkpoint serialises every node (92,485 of them on the K90 Ultra, 196,703 data pages) and puts the
 * result to UFS. Boot-arg annfs_sync_ms=N changes the timer (500 to 600000); annfs_time=1 prints what
 * each checkpoint cost, split into pack, CRC and write, so the numbers can be had without a rebuild
 * per hypothesis.
 */
static uint32_t annfs_sync_ms;
static int annfs_time;

static void
annfs_read_settings(void)
{
	if (annfs_sync_ms == 0) {
		uint32_t ms = 1500;
		int report = 0;

		PE_parse_boot_argn("annfs_sync_ms", &ms, sizeof(ms));
		PE_parse_boot_argn("annfs_time", &report, sizeof(report));
		annfs_sync_ms = ms < 500 ? 500 : ms > 600000 ? 600000 : ms;
		annfs_time = report != 0 ? 1 : -1;
	}
}

static uint64_t
annfs_us_between(uint64_t from, uint64_t to)
{
	uint64_t ns = 0;

	absolutetime_to_nanoseconds(to - from, &ns);
	return ns / 1000;
}

#define ANNFS_PANIC_OFFSET       (64ULL << 20)
#define ANNFS_PANIC_SIZE         (16ULL << 20)
#define ANNFS_DATA_OFFSET        (512ULL << 20)
#define ANNFS_INIT_META_CAP      (8ULL << 20)
#define ANNFS_ALIGN8(n)          (((uint64_t)(n) + 7ULL) & ~7ULL)
#define ANNFS_ALIGN4K(n)         (((uint64_t)(n) + 4095ULL) & ~4095ULL)

#define KLOG_MAGIC               0x474f4c4bU     /* 'KLOG' */
#define KLOG_MAGIC_ARCHIVED      0x474f4c44U     /* 'DLOG' */
#define KLOG_VERSION             1U
#define ANNFS_BL_MAGIC           0x424c5332U     /* 'BLS2' */

struct klog_head {
	uint32_t magic;
	uint32_t version;
	uint64_t payload_bytes;
	uint64_t timestamp;
	uint32_t boot_counter;
	uint32_t payload_crc;
	uint32_t head_crc;
	uint32_t flags;
	uint8_t  reserved[24];
};
_Static_assert(sizeof(struct klog_head) == 64, "klog_head must be 64 bytes");

struct annfs_super {
	char     magic[8];
	uint32_t version;
	uint32_t page_size;
	uint64_t generation;
	uint64_t payload_bytes;
	uint64_t next_ino;
	uint32_t node_count;
	uint32_t payload_crc;
	uint32_t super_crc;
	uint32_t bl_magic;
	uint32_t bl_panel_v;
	uint32_t bl_millinits;
	uint8_t  reserved[4096 - 64];
};
_Static_assert(sizeof(struct annfs_super) == 4096, "annfs_super must be 4096 bytes");

struct annfs_inode_rec {
	uint64_t ino;
	uint64_t size;
	uint64_t parent_ino;
	uint32_t type;
	uint32_t mode;
	uint32_t uid;
	uint32_t gid;
	uint32_t bsdflags;
	uint32_t dataprotect_class;
	uint32_t nlink;
	uint32_t target_len;
	uint32_t nblocks;
	uint32_t nxattrs;
	uint32_t ndirents;
	uint32_t iflags;                /* ramfs_node.rn_iflags */
	uint32_t document_id;           /* ramfs_node.rn_docid */
	uint32_t write_gen;             /* ramfs_node.rn_write_gen */
	int64_t  atime_sec, atime_nsec;
	int64_t  mtime_sec, mtime_nsec;
	int64_t  ctime_sec, ctime_nsec;
	int64_t  btime_sec, btime_nsec;
};

struct annfs_xattr_rec {
	uint32_t namelen;
	uint32_t size;
};

struct annfs_dirent_rec {
	uint64_t child_ino;
	uint32_t namelen;
	uint32_t reserved;
};

static struct ramfs_mount *ramfs_disk_rm;
static bool ramfs_disk_claimed;
static int ramfs_var_disk_loaded;
static int ramfs_var_seed_done = 1;
static bool ramfs_bl_probed;
static bool ramfs_bl_saved;
static uint32_t ramfs_bl_panel_v;
static uint32_t ramfs_bl_millinits;

static void ramfs_disk_dirty_locked(struct ramfs_mount *rm);
static int ramfs_disk_sync_impl(struct ramfs_mount *rm);
#define ramfs_disk_sync(rm, ...) ramfs_disk_sync_impl(rm)

static void
ramfs_disk_mark_seed_done(struct ramfs_mount *rm)
{
	if (rm != NULL) {
		lck_mtx_lock(&rm->rm_lock);
		rm->rm_seed_done = true;
		ramfs_var_seed_done = 1;
		ramfs_disk_dirty_locked(rm);
		lck_mtx_unlock(&rm->rm_lock);
		(void)ramfs_disk_sync(rm, true);
	}
}

static int
sysctl_var_seed_done SYSCTL_HANDLER_ARGS
{
#pragma unused(oidp, arg1, arg2)
	int val = ramfs_var_seed_done;
	int error = sysctl_io_number(req, val, sizeof(val), &val, NULL);

	if (error == 0 && req->newptr != USER_ADDR_NULL) {
		ramfs_var_seed_done = val;
		if (ramfs_disk_rm != NULL) {
			if (val != 0) {
				ramfs_disk_mark_seed_done(ramfs_disk_rm);
			} else {
				lck_mtx_lock(&ramfs_disk_rm->rm_lock);
				ramfs_disk_rm->rm_seed_done = false;
				lck_mtx_unlock(&ramfs_disk_rm->rm_lock);
			}
		}
	}
	return error;
}

SYSCTL_DECL(_kern_annibale);
SYSCTL_INT(_kern_annibale, OID_AUTO, var_disk_loaded, CTLFLAG_RD | CTLFLAG_LOCKED,
    &ramfs_var_disk_loaded, 0, "1 when /private/var was loaded from ANNFS001 on disk");
SYSCTL_PROC(_kern_annibale, OID_AUTO, var_seed_done,
    CTLTYPE_INT | CTLFLAG_RW | CTLFLAG_LOCKED,
    &ramfs_var_seed_done, 0, sysctl_var_seed_done, "I",
    "1 when /private/var seed unpack has completed");

static void *
ramfs_vm_alloc(size_t bytes)
{
	vm_offset_t addr = 0;

	return kmem_alloc(kernel_map, &addr, bytes, KMA_KOBJECT | KMA_DATA | KMA_ZERO,
	    VM_KERN_MEMORY_FILE) == KERN_SUCCESS ? (void *)addr : NULL;
}

static void
ramfs_vm_free(void *ptr, size_t bytes)
{
	if (ptr != NULL && bytes != 0) {
		kmem_free(kernel_map, (vm_offset_t)ptr, bytes);
	}
}

static void
ramfs_disk_bmap_set(struct ramfs_mount *rm, uint32_t dblk)
{
	if (rm->rm_bmap != NULL && dblk > 0 && dblk < rm->rm_bmap_max) {
		rm->rm_bmap[dblk >> 5] |= (1u << (dblk & 31u));
	}
}

static void
ramfs_disk_bmap_free(struct ramfs_mount *rm, uint32_t dblk)
{
	if (rm->rm_bmap != NULL && dblk > 0 && dblk < rm->rm_bmap_max) {
		rm->rm_bmap[dblk >> 5] &= ~(1u << (dblk & 31u));
	}
}

static uint32_t
ramfs_disk_bmap_alloc(struct ramfs_mount *rm)
{
	uint32_t start_word, w, words = rm->rm_bmap_words;

	if (rm->rm_bmap == NULL || words == 0) {
		return 0;
	}
	start_word = rm->rm_bmap_next >> 5;
	if (start_word >= words) {
		start_word = 0;
	}
	for (uint32_t step = 0; step < words; step++) {
		uint32_t word;

		w = start_word + step;
		if (w >= words) {
			w -= words;
		}
		word = rm->rm_bmap[w];
		if (word == 0xffffffffu) {
			continue;
		}
		for (uint32_t bit = 0; bit < 32u; bit++) {
			uint32_t dblk = (w << 5) + bit;

			if (dblk == 0 || dblk >= rm->rm_bmap_max) {
				continue;
			}
			if ((word & (1u << bit)) == 0) {
				rm->rm_bmap[w] |= (1u << bit);
				rm->rm_bmap_next = (dblk + 1u < rm->rm_bmap_max) ? (dblk + 1u) : 1u;
				return dblk;
			}
		}
	}
	return 0;
}

static int
ramfs_disk_read_block(struct ramfs_mount *rm, uint32_t dblk, void *dst)
{
	if (!rm->rm_disk_backed || dblk == 0 || dblk >= rm->rm_bmap_max) {
		return EIO;
	}
	return annibale_ufs_var_io(false, ANNFS_DATA_OFFSET + (uint64_t)dblk * PAGE_SIZE, dst, PAGE_SIZE);
}

static int
ramfs_disk_write_block(struct ramfs_mount *rm, uint32_t dblk, const void *src)
{
	if (!rm->rm_disk_backed || dblk == 0 || dblk >= rm->rm_bmap_max) {
		return EIO;
	}
	return annibale_ufs_var_io(true, ANNFS_DATA_OFFSET + (uint64_t)dblk * PAGE_SIZE,
	    (void *)(uintptr_t)src, PAGE_SIZE);
}

static void
ramfs_disk_fault_page(struct ramfs_node *node, uint64_t index)
{
	struct ramfs_mount *rm = node->rn_mount;
	void *page;

	if (!rm->rm_disk_backed || index >= node->rn_nslots || node->rn_pages[index] != NULL ||
	    node->rn_blocks == NULL || node->rn_blocks[index] == 0) {
		return;
	}
	if (os_atomic_load(&ramfs_pages_in_use, relaxed) >= rm->rm_max_pages / 2) {
		return;
	}
	page = ramfs_page_alloc(false);
	if (page == NULL) {
		return;
	}
	if (ramfs_disk_read_block(rm, node->rn_blocks[index], page) == 0) {
		node->rn_pages[index] = page;
		os_atomic_inc(&ramfs_pages_in_use, relaxed);
	} else {
		ramfs_page_free(page);
	}
}

static void
ramfs_disk_evict_page_locked(struct ramfs_mount *rm, struct ramfs_node *node, uint64_t index, void *page)
{
	if (os_atomic_load(&ramfs_pages_in_use, relaxed) >= rm->rm_max_pages / 2) {
		if (node->rn_pages != NULL && index < node->rn_nslots && node->rn_pages[index] == page) {
			ramfs_page_free(page);
			node->rn_pages[index] = NULL;
			os_atomic_dec(&ramfs_pages_in_use, relaxed);
		}
	}
}

static void
ramfs_disk_dirty_locked(struct ramfs_mount *rm)
{
	if (rm == NULL || !rm->rm_disk_backed || rm->rm_disk_loading) {
		return;
	}
	rm->rm_meta_state = RAMFS_META_DIRTY;
	if (ramfs_var_seed_done == 0 || !rm->rm_seed_done) {
		return;
	}
	if (rm->rm_meta_gen > 0 && rm->rm_meta_call != NULL && !rm->rm_meta_syncing) {
		uint64_t deadline;

		annfs_read_settings();
		clock_interval_to_deadline(annfs_sync_ms, NSEC_PER_MSEC, &deadline);
		thread_call_enter_delayed((thread_call_t)rm->rm_meta_call, deadline);
	}
}

/* Serialize all live nodes into rm->rm_meta_buf + ANNFS_SUPER_BYTES. rm->rm_lock is held. */
static int
ramfs_disk_pack_locked(struct ramfs_mount *rm, uint64_t *payload_bytes_out, uint32_t *node_count_out)
{
	uint8_t *base = (uint8_t *)rm->rm_meta_buf + ANNFS_SUPER_BYTES;
	uint64_t cap = rm->rm_meta_cap > ANNFS_SUPER_BYTES ? (rm->rm_meta_cap - ANNFS_SUPER_BYTES) : 0;
	uint64_t at = 0;
	uint32_t nodes = 0;

	for (uint32_t h = 0; h < RAMFS_HASH_SIZE; h++) {
		for (struct ramfs_node *node = rm->rm_hash[h]; node != NULL; node = node->rn_hnext) {
			struct annfs_inode_rec rec;
			struct ramfs_xattr *xa;
			struct ramfs_dirent *de;
			uint32_t nblocks = 0, nxattrs = 0, ndirents = 0, target_len = 0;
			uint64_t need;

			if (node->rn_nlink == 0 || node->rn_type == VSOCK) {
				continue;
			}
			if (node->rn_type == VLNK && node->rn_target != NULL) {
				target_len = (uint32_t)node->rn_size;
			}
			if (node->rn_type == VREG && node->rn_blocks != NULL && node->rn_size > 0) {
				uint64_t slots_used = (node->rn_size + PAGE_MASK) / PAGE_SIZE;

				if (slots_used > node->rn_nslots) {
					slots_used = node->rn_nslots;
				}
				nblocks = (uint32_t)slots_used;
			}
			TAILQ_FOREACH(xa, &node->rn_xattrs, rx_link) {
				nxattrs++;
			}
			if (node->rn_type == VDIR) {
				TAILQ_FOREACH(de, &node->rn_entries, rd_link) {
					if (de->rd_node != NULL && de->rd_node->rn_nlink > 0 &&
					    de->rd_node->rn_type != VSOCK) {
						ndirents++;
					}
				}
			}
			need = sizeof(rec) + ANNFS_ALIGN8(target_len) +
			    ANNFS_ALIGN8((uint64_t)nblocks * sizeof(uint32_t));
			if (at + need > cap) {
				return ENOSPC;
			}
			bzero(&rec, sizeof(rec));
			rec.ino = node->rn_ino;
			rec.size = node->rn_size;
			rec.parent_ino = (node->rn_type == VDIR && node->rn_parent != NULL) ?
			    node->rn_parent->rn_ino : RAMFS_ROOT_INO;
			rec.type = (uint32_t)node->rn_type;
			rec.mode = node->rn_mode;
			rec.uid = node->rn_uid;
			rec.gid = node->rn_gid;
			rec.bsdflags = node->rn_bsdflags;
			rec.dataprotect_class = node->rn_dataprotect_class;
			rec.nlink = node->rn_nlink;
			rec.target_len = target_len;
			rec.nblocks = nblocks;
			rec.nxattrs = nxattrs;
			rec.ndirents = ndirents;
			rec.iflags = node->rn_iflags;
			rec.document_id = node->rn_docid;
			rec.write_gen = node->rn_write_gen;
			rec.atime_sec = node->rn_atime.tv_sec;
			rec.atime_nsec = node->rn_atime.tv_nsec;
			rec.mtime_sec = node->rn_mtime.tv_sec;
			rec.mtime_nsec = node->rn_mtime.tv_nsec;
			rec.ctime_sec = node->rn_ctime.tv_sec;
			rec.ctime_nsec = node->rn_ctime.tv_nsec;
			rec.btime_sec = node->rn_btime.tv_sec;
			rec.btime_nsec = node->rn_btime.tv_nsec;

			memcpy(base + at, &rec, sizeof(rec));
			at += sizeof(rec);

			if (target_len > 0) {
				uint64_t alen = ANNFS_ALIGN8(target_len);

				memcpy(base + at, node->rn_target, target_len);
				bzero(base + at + target_len, (size_t)(alen - target_len));
				at += alen;
			}
			if (nblocks > 0) {
				uint64_t bbytes = (uint64_t)nblocks * sizeof(uint32_t);
				uint64_t alen = ANNFS_ALIGN8(bbytes);

				memcpy(base + at, node->rn_blocks, (size_t)bbytes);
				bzero(base + at + bbytes, (size_t)(alen - bbytes));
				at += alen;
			}
			TAILQ_FOREACH(xa, &node->rn_xattrs, rx_link) {
				struct annfs_xattr_rec xrec = {
					.namelen = (uint32_t)xa->rx_namelen,
					.size = (uint32_t)xa->rx_size,
				};
				uint64_t raw = (uint64_t)xrec.namelen + (uint64_t)xrec.size;
				uint64_t alen = ANNFS_ALIGN8(raw);

				if (at + sizeof(xrec) + alen > cap) {
					return ENOSPC;
				}
				memcpy(base + at, &xrec, sizeof(xrec));
				at += sizeof(xrec);
				memcpy(base + at, xa->rx_name, xrec.namelen);
				if (xrec.size > 0 && xa->rx_data != NULL) {
					memcpy(base + at + xrec.namelen, xa->rx_data, xrec.size);
					bzero(base + at + raw, (size_t)(alen - raw));
				} else {
					/* Preserve zero-filled values for attributes without resident data. */
					bzero(base + at + xrec.namelen, (size_t)(alen - xrec.namelen));
				}
				at += alen;
			}
			if (node->rn_type == VDIR) {
				TAILQ_FOREACH(de, &node->rn_entries, rd_link) {
					struct annfs_dirent_rec drec;
					uint64_t alen;

					if (de->rd_node == NULL || de->rd_node->rn_nlink == 0 ||
					    de->rd_node->rn_type == VSOCK) {
						continue;
					}
					drec.child_ino = de->rd_node->rn_ino;
					drec.namelen = de->rd_namelen;
					drec.reserved = 0;
					alen = ANNFS_ALIGN8(drec.namelen);
					if (at + sizeof(drec) + alen > cap) {
						return ENOSPC;
					}
					memcpy(base + at, &drec, sizeof(drec));
					at += sizeof(drec);
					memcpy(base + at, de->rd_name, drec.namelen);
					bzero(base + at + drec.namelen, (size_t)(alen - drec.namelen));
					at += alen;
				}
			}
			nodes++;
		}
	}
	*payload_bytes_out = at;
	*node_count_out = nodes;
	return 0;
}

static int
ramfs_disk_sync_impl(struct ramfs_mount *rm)
{
	uint64_t payload_bytes = 0, write_bytes, gen, slot_off;
	uint32_t node_count = 0;
	struct annfs_super *sup;
	int error = 0;
	uint64_t began = mach_absolute_time(), after_pack = 0, after_crc = 0;

	if (rm == NULL || !rm->rm_disk_enabled || !rm->rm_seed_done || ramfs_var_seed_done == 0 || rm->rm_disk_loading) {
		return 0;
	}
	lck_mtx_lock(&rm->rm_lock);
	while (rm->rm_meta_syncing) {
		msleep(&rm->rm_meta_syncing, &rm->rm_lock, PRIBIO, "annfssync", NULL);
	}
	if (rm->rm_meta_gen == 0 && rm->rm_meta_state == RAMFS_META_CLEAN) {
		rm->rm_meta_state = RAMFS_META_DIRTY;
	}
	/* A mutation resets SLOT_FULL in ramfs_disk_dirty_locked(); unchanged input still cannot fit. */
	if (rm->rm_meta_state == RAMFS_META_SLOT_FULL) {
		lck_mtx_unlock(&rm->rm_lock);
		return ENOSPC;
	}
	if (rm->rm_meta_state == RAMFS_META_CLEAN) {
		lck_mtx_unlock(&rm->rm_lock);
		return 0;
	}

	while (ramfs_disk_pack_locked(rm, &payload_bytes, &node_count) == ENOSPC) {
		size_t old_cap = rm->rm_meta_cap;
		size_t new_cap = old_cap ? old_cap * 2 : ANNFS_INIT_META_CAP;
		void *new_buf;

		if (new_cap > ANNFS_SLOT_MAX) {
			if (old_cap >= ANNFS_SLOT_MAX) {
				rm->rm_meta_state = RAMFS_META_SLOT_FULL;
				lck_mtx_unlock(&rm->rm_lock);
				return ENOSPC;
			}
			new_cap = ANNFS_SLOT_MAX;
		}
		rm->rm_meta_syncing = true;
		lck_mtx_unlock(&rm->rm_lock);
		new_buf = ramfs_vm_alloc(new_cap);
		lck_mtx_lock(&rm->rm_lock);
		rm->rm_meta_syncing = false;
		wakeup(&rm->rm_meta_syncing);
		if (new_buf == NULL) {
			lck_mtx_unlock(&rm->rm_lock);
			return ENOMEM;
		}
		if (rm->rm_meta_cap == old_cap) {
			ramfs_vm_free(rm->rm_meta_buf, old_cap);
			rm->rm_meta_buf = new_buf;
			rm->rm_meta_cap = new_cap;
		} else {
			ramfs_vm_free(new_buf, new_cap);
		}
	}

	after_pack = mach_absolute_time();
	rm->rm_meta_state = RAMFS_META_CLEAN;
	rm->rm_meta_syncing = true;
	gen = rm->rm_meta_gen + 1;
	write_bytes = ANNFS_ALIGN4K(ANNFS_SUPER_BYTES + payload_bytes);
	if (write_bytes > ANNFS_SUPER_BYTES + payload_bytes) {
		bzero((uint8_t *)rm->rm_meta_buf + ANNFS_SUPER_BYTES + payload_bytes,
		    (size_t)(write_bytes - (ANNFS_SUPER_BYTES + payload_bytes)));
	}
	sup = (struct annfs_super *)rm->rm_meta_buf;
	bzero(sup, sizeof(*sup));
	memcpy(sup->magic, ANNFS_MAGIC_STR, 8);
	sup->version = ANNFS_VERSION;
	sup->page_size = PAGE_SIZE;
	sup->generation = gen;
	sup->payload_bytes = payload_bytes;
	sup->next_ino = rm->rm_next_ino;
	sup->node_count = node_count;
	sup->payload_crc = crc32(0, (uint8_t *)rm->rm_meta_buf + ANNFS_SUPER_BYTES, (size_t)payload_bytes);
	sup->super_crc = crc32(0, sup, __builtin_offsetof(struct annfs_super, super_crc));
	after_crc = mach_absolute_time();
	if (ramfs_bl_saved) {
		sup->bl_magic = ANNFS_BL_MAGIC;
		sup->bl_panel_v = ramfs_bl_panel_v;
		sup->bl_millinits = ramfs_bl_millinits;
	}

	/* Preserve the recovered slot even when generations have unusual parity. */
	slot_off = rm->rm_meta_slot == 0 ? ANNFS_SLOT1_OFFSET : ANNFS_SLOT0_OFFSET;
	lck_mtx_unlock(&rm->rm_lock);

	if (write_bytes > ANNFS_SUPER_BYTES) {
		error = annibale_ufs_var_io(true, slot_off + ANNFS_SUPER_BYTES,
		    (uint8_t *)rm->rm_meta_buf + ANNFS_SUPER_BYTES, write_bytes - ANNFS_SUPER_BYTES);
	}
	if (error == 0) {
		error = annibale_ufs_var_io(true, slot_off, rm->rm_meta_buf, ANNFS_SUPER_BYTES);
	}
	if (error == 0 && gen == 1) {
		if (write_bytes > ANNFS_SUPER_BYTES) {
			(void)annibale_ufs_var_io(true, ANNFS_SLOT1_OFFSET + ANNFS_SUPER_BYTES,
			    (uint8_t *)rm->rm_meta_buf + ANNFS_SUPER_BYTES, write_bytes - ANNFS_SUPER_BYTES);
		}
		(void)annibale_ufs_var_io(true, ANNFS_SLOT1_OFFSET, rm->rm_meta_buf, ANNFS_SUPER_BYTES);
	}

	annfs_read_settings();
	if (annfs_time > 0 && after_pack != 0 && after_crc != 0) {
		printf("ramfs: checkpoint gen %llu: %u nodes, %llu bytes, pack %llu us, crc %llu us, "
		    "write %llu us\n", gen, node_count, write_bytes - ANNFS_SUPER_BYTES,
		    annfs_us_between(began, after_pack), annfs_us_between(after_pack, after_crc),
		    annfs_us_between(after_crc, mach_absolute_time()));
	}
	lck_mtx_lock(&rm->rm_lock);
	rm->rm_meta_syncing = false;
	wakeup(&rm->rm_meta_syncing);
	if (error == 0) {
		rm->rm_meta_gen = gen;
		rm->rm_meta_slot = slot_off == ANNFS_SLOT0_OFFSET ? 0 : 1;
	} else {
		rm->rm_meta_state = RAMFS_META_DIRTY;
	}
	if (error != 0) {
		printf("ramfs: metadata write failed (%d)\n", error);
	} else if (rm->rm_meta_state != RAMFS_META_CLEAN && rm->rm_seed_done && ramfs_var_seed_done != 0 &&
	    rm->rm_meta_call != NULL) {
		uint64_t deadline;

		annfs_read_settings();
		clock_interval_to_deadline(annfs_sync_ms, NSEC_PER_MSEC, &deadline);
		thread_call_enter_delayed((thread_call_t)rm->rm_meta_call, deadline);
	}
	lck_mtx_unlock(&rm->rm_lock);
	return error;
}

static void
ramfs_disk_meta_thread(thread_call_param_t param0, __unused thread_call_param_t param1)
{
	struct ramfs_mount *rm = (struct ramfs_mount *)param0;

	if (rm != NULL && rm->rm_disk_backed && rm->rm_meta_gen > 0) {
		(void)ramfs_disk_sync(rm);
	}
}

int ramfs_disk_flush_all(void);

int
ramfs_disk_flush_all(void)
{
	struct ramfs_mount *rm = ramfs_disk_rm;
	int error = 0;

	if (rm == NULL || !rm->rm_disk_enabled || !rm->rm_seed_done || rm->rm_disk_loading) {
		return 0;
	}
	lck_mtx_lock(&rm->rm_lock);
	/* New inodes cannot extend this pass indefinitely while mapped pages are flushed. */
	uint64_t limit = rm->rm_next_ino;
	for (uint32_t h = 0; h < RAMFS_HASH_SIZE; h++) {
		uint64_t after = 0;

		for (;;) {
			uint64_t next = limit;
			vnode_t vp = NULLVP;
			uint32_t vid = 0;

			/* Inode order survives removals while the lock is dropped; node pointers do not. */
			for (struct ramfs_node *node = rm->rm_hash[h]; node != NULL; node = node->rn_hnext) {
				if (node->rn_ino > after && node->rn_ino < next && node->rn_type == VREG &&
				    node->rn_nlink > 0 && node->rn_mapped_write && node->rn_vp != NULLVP) {
					next = node->rn_ino;
					vp = node->rn_vp;
					vid = node->rn_vid;
				}
			}
			if (vp == NULLVP) {
				break;
			}
			after = next;
			/* rm_lock also protects VNOP_RECLAIM; hold keeps vnode memory valid until vget. */
			vnode_hold(vp);
			lck_mtx_unlock(&rm->rm_lock);
			int sync_error = vnode_getwithvid(vp, vid);
			vnode_drop(vp);
			if (sync_error == 0) {
				sync_error = ubc_msync(vp, 0, ubc_getsize(vp), NULL, UBC_PUSHDIRTY | UBC_SYNC);
				vnode_put(vp);
			}
			if (error == 0) {
				error = sync_error;
			}
			lck_mtx_lock(&rm->rm_lock);
		}
	}
	lck_mtx_unlock(&rm->rm_lock);
	/* Skip this final checkpoint after a failed page flush; periodic sync remains independent. */
	return error != 0 ? error : ramfs_disk_sync(rm);
}

static struct ramfs_node *
ramfs_disk_find_ino(struct ramfs_mount *rm, uint64_t ino)
{
	for (struct ramfs_node *node = rm->rm_hash[ino & (RAMFS_HASH_SIZE - 1)]; node != NULL; node = node->rn_hnext) {
		if (node->rn_ino == ino) {
			return node;
		}
	}
	return NULL;
}

#include "ramfs_disk_restore.inc"

bool ramfs_backlight_load(uint32_t *panel_v_out, uint32_t *millinits_out);
void ramfs_backlight_save(uint32_t panel_v, uint32_t millinits);

bool
ramfs_backlight_load(uint32_t *panel_v_out, uint32_t *millinits_out)
{
	if (!ramfs_bl_probed) {
		uint64_t part_bytes = 0, offsets[2] = { ANNFS_SLOT0_OFFSET, ANNFS_SLOT1_OFFSET };
		struct annfs_super *sup = kalloc_type(struct annfs_super, Z_WAITOK | Z_ZERO);
		uint64_t best_gen = 0;

		if (sup != NULL && annibale_ufs_var_info(&part_bytes) &&
		    part_bytes >= ANNFS_DATA_OFFSET + 2 * PAGE_SIZE) {
			for (unsigned i = 0; i < 2; i++) {
				if (annibale_ufs_var_io(false, offsets[i], sup, sizeof(*sup)) == 0 &&
				    ramfs_disk_super_valid(sup) && sup->generation >= best_gen) {
					best_gen = sup->generation;
					if (sup->bl_magic == ANNFS_BL_MAGIC &&
					    sup->bl_panel_v != 0 && sup->bl_millinits != 0) {
						ramfs_bl_saved = true;
						ramfs_bl_panel_v = sup->bl_panel_v;
						ramfs_bl_millinits = sup->bl_millinits;
					} else {
						ramfs_bl_saved = false;
					}
				}
			}
			ramfs_bl_probed = true;
		}
		if (sup != NULL) {
			kfree_type(struct annfs_super, sup);
		}
	}
	if (!ramfs_bl_saved) {
		return false;
	}
	if (panel_v_out != NULL) {
		*panel_v_out = ramfs_bl_panel_v;
	}
	if (millinits_out != NULL) {
		*millinits_out = ramfs_bl_millinits;
	}
	return true;
}

void
ramfs_backlight_save(uint32_t panel_v, uint32_t millinits)
{
	struct ramfs_mount *rm = ramfs_disk_rm;

	if (panel_v == 0 || millinits == 0) {
		return;
	}
	if (ramfs_bl_saved && ramfs_bl_panel_v == panel_v && ramfs_bl_millinits == millinits) {
		return;
	}
	ramfs_bl_probed = true;
	ramfs_bl_saved = true;
	ramfs_bl_panel_v = panel_v;
	ramfs_bl_millinits = millinits;
	if (rm != NULL) {
		lck_mtx_lock(&rm->rm_lock);
		ramfs_disk_dirty_locked(rm);
		lck_mtx_unlock(&rm->rm_lock);
	}
}

static struct ramfs_node *
ramfs_disk_find_child(struct ramfs_node *dir, const char *name, size_t len)
{
	struct ramfs_dirent *de;

	if (dir == NULL || dir->rn_type != VDIR) {
		return NULL;
	}
	TAILQ_FOREACH(de, &dir->rn_entries, rd_link) {
		if (de->rd_namelen == len && memcmp(de->rd_name, name, len) == 0) {
			return de->rd_node;
		}
	}
	return NULL;
}

static void
ramfs_disk_prune_bloated_aircache(struct ramfs_mount *rm)
{
	struct ramfs_node *db_node, *cache_node;
	struct ramfs_dirent *de, *tmp;
	uint32_t removed = 0;

	lck_mtx_lock(&rm->rm_lock);
	db_node = ramfs_disk_find_child(rm->rm_root, "db", 2);
	cache_node = ramfs_disk_find_child(db_node, "annibale-aircache", 17);
	if (cache_node == NULL || cache_node->rn_type != VDIR || cache_node->rn_nentries <= 4096) {
		lck_mtx_unlock(&rm->rm_lock);
		return;
	}
	TAILQ_FOREACH_SAFE(de, &cache_node->rn_entries, rd_link, tmp) {
		struct ramfs_node *child = de->rd_node;

		if (child == NULL || child->rn_type != VREG || child->rn_vp != NULLVP) {
			continue;
		}
		TAILQ_REMOVE(&cache_node->rn_entries, de, rd_link);
		cache_node->rn_nentries--;
		ramfs_dirent_free(de);
		if (--child->rn_nlink == 0) {
			ramfs_node_free(child);
		}
		removed++;
	}
	if (cache_node->rn_dir_hash != NULL) {
		kfree_type(struct ramfs_dirent *, RAMFS_DIR_HASH_SIZE, cache_node->rn_dir_hash);
		cache_node->rn_dir_hash = NULL;
	}
	ramfs_disk_dirty_locked(rm);
	lck_mtx_unlock(&rm->rm_lock);
	(void)ramfs_disk_sync(rm);
	printf("ramfs: pruned %u legacy entries from /private/var/db/annibale-aircache (%llu nodes remain)\n",
	    removed, rm->rm_nodes);
}

static void
ramfs_disk_restore_panic_log(struct ramfs_mount *rm)
{
	uint8_t *head_buf;
	struct klog_head *kh;
	uint64_t pay_len, total_len, npages, nslots;
	uint8_t *full_buf;
	const uint8_t *payload;
	void **pages;
	uint32_t *blocks;
	struct ramfs_node *db_node, *log_node;
	struct ramfs_dirent *de;

	if (rm == NULL || !rm->rm_disk_backed || rm->rm_root == NULL) {
		return;
	}
	ramfs_disk_prune_bloated_aircache(rm);

	head_buf = (uint8_t *)ramfs_vm_alloc(PAGE_SIZE);
	if (head_buf == NULL) {
		return;
	}
	if (annibale_ufs_var_io(false, ANNFS_PANIC_OFFSET, head_buf, PAGE_SIZE) != 0) {
		ramfs_vm_free(head_buf, PAGE_SIZE);
		return;
	}

	kh = (struct klog_head *)head_buf;
	if (kh->magic != KLOG_MAGIC || kh->version != KLOG_VERSION) {
		ramfs_vm_free(head_buf, PAGE_SIZE);
		return;
	}
	if (crc32(0, kh, __builtin_offsetof(struct klog_head, head_crc)) != kh->head_crc) {
		printf("ramfs: panic log header crc mismatch\n");
		ramfs_vm_free(head_buf, PAGE_SIZE);
		return;
	}
	if (kh->payload_bytes == 0 || kh->payload_bytes > (ANNFS_PANIC_SIZE - sizeof(struct klog_head))) {
		ramfs_vm_free(head_buf, PAGE_SIZE);
		return;
	}

	pay_len = kh->payload_bytes;
	total_len = ANNFS_ALIGN4K(sizeof(struct klog_head) + pay_len);
	full_buf = (uint8_t *)ramfs_vm_alloc((size_t)total_len);
	if (full_buf == NULL) {
		ramfs_vm_free(head_buf, PAGE_SIZE);
		return;
	}
	if (annibale_ufs_var_io(false, ANNFS_PANIC_OFFSET, full_buf, total_len) != 0) {
		ramfs_vm_free(full_buf, (size_t)total_len);
		ramfs_vm_free(head_buf, PAGE_SIZE);
		return;
	}

	payload = full_buf + sizeof(struct klog_head);
	if (crc32(0, payload, (size_t)pay_len) != kh->payload_crc) {
		printf("ramfs: panic log payload crc mismatch\n");
		ramfs_vm_free(full_buf, (size_t)total_len);
		ramfs_vm_free(head_buf, PAGE_SIZE);
		return;
	}

	npages = (pay_len + PAGE_MASK) / PAGE_SIZE;
	nslots = 4;
	while (nslots < npages) {
		nslots *= 2;
	}

	pages = kalloc_type(void *, nslots, Z_WAITOK | Z_ZERO);
	blocks = kalloc_data((size_t)nslots * sizeof(uint32_t), Z_WAITOK | Z_ZERO);
	if (pages == NULL || blocks == NULL) {
		if (pages != NULL) {
			kfree_type(void *, nslots, pages);
		}
		if (blocks != NULL) {
			kfree_data(blocks, (size_t)nslots * sizeof(uint32_t));
		}
		ramfs_vm_free(full_buf, (size_t)total_len);
		ramfs_vm_free(head_buf, PAGE_SIZE);
		return;
	}

	for (uint64_t i = 0; i < npages; i++) {
		void *p = ramfs_page_alloc(true);
		if (p == NULL) {
			for (uint64_t j = 0; j < i; j++) {
				ramfs_page_free(pages[j]);
			}
			kfree_type(void *, nslots, pages);
			kfree_data(blocks, (size_t)nslots * sizeof(uint32_t));
			ramfs_vm_free(full_buf, (size_t)total_len);
			ramfs_vm_free(head_buf, PAGE_SIZE);
			return;
		}
		size_t chunk = (i + 1 == npages && (pay_len & PAGE_MASK)) ? (size_t)(pay_len & PAGE_MASK) : PAGE_SIZE;
		memcpy(p, payload + i * PAGE_SIZE, chunk);
		pages[i] = p;
	}

	lck_mtx_lock(&rm->rm_lock);
	db_node = ramfs_disk_find_child(rm->rm_root, "db", 2);
	if (db_node == NULL) {
		db_node = ramfs_node_alloc(rm, VDIR, NULL);
		db_node->rn_ino = rm->rm_next_ino++;
		db_node->rn_mode = 0755;
		db_node->rn_nlink = 2;
		db_node->rn_parent = rm->rm_root;
		ramfs_hash_insert(rm, db_node);
		rm->rm_nodes++;

		de = ramfs_dirent_alloc("db", 2);
		de->rd_node = db_node;
		TAILQ_INSERT_TAIL(&rm->rm_root->rn_entries, de, rd_link);
		rm->rm_root->rn_nentries++;
	}

	log_node = ramfs_disk_find_child(db_node, "panic.log", 9);
	if (log_node != NULL) {
		if (log_node->rn_pages != NULL) {
			for (uint64_t i = 0; i < log_node->rn_nslots; i++) {
				if (log_node->rn_pages[i] != NULL) {
					ramfs_page_free(log_node->rn_pages[i]);
					os_atomic_dec(&ramfs_pages_in_use, relaxed);
				}
				if (log_node->rn_blocks != NULL && log_node->rn_blocks[i] != 0) {
					ramfs_disk_bmap_free(rm, log_node->rn_blocks[i]);
					os_atomic_dec(&ramfs_var_used_pages, relaxed);
				}
			}
			kfree_type(void *, log_node->rn_nslots, log_node->rn_pages);
		}
		if (log_node->rn_blocks != NULL) {
			kfree_data(log_node->rn_blocks, (size_t)log_node->rn_nslots * sizeof(uint32_t));
		}
	} else {
		log_node = ramfs_node_alloc(rm, VREG, NULL);
		log_node->rn_ino = rm->rm_next_ino++;
		log_node->rn_mode = 0644;
		log_node->rn_nlink = 1;
		ramfs_hash_insert(rm, log_node);
		rm->rm_nodes++;

		de = ramfs_dirent_alloc("panic.log", 9);
		de->rd_node = log_node;
		TAILQ_INSERT_TAIL(&db_node->rn_entries, de, rd_link);
		db_node->rn_nentries++;
	}

	log_node->rn_pages = pages;
	log_node->rn_blocks = blocks;
	log_node->rn_nslots = nslots;
	log_node->rn_nalloc = (uint32_t)npages;
	log_node->rn_size = pay_len;
	rm->rm_pages += npages;
	os_atomic_add(&ramfs_pages_in_use, npages, relaxed);

	for (uint64_t i = 0; i < npages; i++) {
		uint32_t dblk = ramfs_disk_bmap_alloc(rm);
		if (dblk != 0) {
			blocks[i] = dblk;
			os_atomic_inc(&ramfs_var_used_pages, relaxed);
		}
	}
	ramfs_disk_dirty_locked(rm);
	lck_mtx_unlock(&rm->rm_lock);

	for (uint64_t i = 0; i < npages; i++) {
		if (blocks[i] != 0 && pages[i] != NULL) {
			(void)ramfs_disk_write_block(rm, blocks[i], pages[i]);
		}
	}

	kh->magic = KLOG_MAGIC_ARCHIVED;
	kh->head_crc = crc32(0, kh, __builtin_offsetof(struct klog_head, head_crc));
	bzero(head_buf, PAGE_SIZE);
	memcpy(head_buf, kh, sizeof(*kh));
	(void)annibale_ufs_var_io(true, ANNFS_PANIC_OFFSET, head_buf, PAGE_SIZE);

	ramfs_vm_free(full_buf, (size_t)total_len);
	ramfs_vm_free(head_buf, PAGE_SIZE);
	(void)ramfs_disk_sync(rm);
	printf("ramfs: restored %llu bytes of crash log to /private/var/db/panic.log\n", (unsigned long long)pay_len);
}

#include "ramfs_disk_mount.inc"

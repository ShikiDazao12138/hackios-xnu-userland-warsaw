/*
 * Return-to-loader debug channel.
 *
 * On hardware without a serial port there is no way to get the kernel log
 * out. The XNU loader therefore leaves UEFI intact (no ExitBootServices) and
 * publishes the physical address of a return stub in /chosen/loader-return.
 * When the kernel has nothing more to do (panic, halt, timer) it collects its
 * message buffer, the panic buffer and any kprintf output, maps the stub 1:1
 * through TTBR0 and jumps to it with that log. The loader then restores the UEFI environment and writes
 * the log to storage.
 *
 * Only valid while the kernel does not drive hardware that UEFI also uses.
 */
#include <mach/mach_types.h>
#include <machine/atomic.h>
#include <kern/cpu_number.h>
#include <kern/debug.h>
#include <kern/startup.h>
#include <kern/thread_call.h>
#include <kern/clock.h>
#include <arm/cpu_internal.h>
#include <arm/machine_routines.h>
#include <arm64/psci_smp.h>
#include <arm64/proc_reg.h>
#include <pexpert/pexpert.h>
#include <pexpert/arm64/board_config.h>
#include <vm/vm_page.h>
/* (xnu-12377 declares it in no header; osfmk/kern/debug.c does the same) */
extern int vsnprintf(char *, size_t, const char *, va_list);
#if __has_include(<vm/vm_compressor_internal.h>)
#include <vm/vm_compressor_internal.h>  /* xnu-12377: c_segment_pages_compressed */
#define MEMSTAT_THRESHOLD_NAMES 1       /* ... and jetsam's thresholds have new names */
#else
#include <vm/vm_compressor.h>
#endif

/*
 * The console log handed back to the loader. A long session writes more than fits, and both
 * ends matter: the start of the boot is kept as it is, and of everything after it the most
 * recent part (a ring); room is left for what is appended on the way out (the kernel message
 * buffer, a panic's text). loader_log_linearize() puts the pieces in order before returning.
 */
#define LOADER_LOG_SIZE (1536 * 1024)
#define LOADER_LOG_HEAD (256 * 1024)
#define LOADER_LOG_RING (1024 * 1024)

#if defined(GENERIC_GIC_V3_IRQ)
extern void gic_v3_irq_quiesce(void);
extern void gic_v3_irq_cpu_shutdown(void);
#endif

void loader_log_putc(char c);
void loader_return(void);
void hv_wdt_pet_NOW(void);
extern void adreno8_quiesce(void);
extern void adreno8_return_quiesce(void);
extern void annibale_wifi_stop(void);
extern void annibale_wifi_quiesce(void);
extern void annibale_haptic_quiesce(void);
extern void annibale_torch_quiesce(void);
extern bool annibale_iris_return_quiesce(void);
extern void MiniIOMobileFramebufferQuiesce(void);   /* iokit/Kernel/MiniFramebufferFlip.inc */
extern void MiniIOMobileFramebufferPowerOff(void);
boolean_t annibale_halting_poweroff = FALSE;
extern void annibale_ufs_quiesce(void);
extern void annibale_var_save_on_return(void);   /* bsd/dev/annibale_ufs.c: the data volume into the flash */
extern int annibale_ufs_var_io(bool write, uint64_t offset, void *buf, uint64_t len);
extern uint32_t crc32(uint32_t crc, const void *buf, size_t len);
void loader_checkpoint(uint64_t n);

#define ANNFS_PANIC_OFFSET       (64ULL << 20)
#define ANNFS_PANIC_SIZE         (16ULL << 20)
#define KLOG_MAGIC               0x474f4c4bU     /* 'KLOG' */
#define KLOG_VERSION             1U

struct klog_head {
	uint32_t magic;
	uint32_t version;
	uint64_t payload_bytes;
	uint64_t timestamp;
	uint32_t boot_counter;
	uint32_t payload_crc;
	uint32_t head_crc;
	uint32_t flags;
	uint8_t  reserved[24];
};
_Static_assert(sizeof(struct klog_head) == 64, "klog_head must be 64 bytes");

struct loader_live {
	uint64_t magic;                 /* "XNULIVE!" */
	uint64_t heartbeat;             /* goes up every HV_WDT_PET_SECONDS while the kernel is alive */
	const char *log;                /* loader_log */
	const uint32_t *log_len;        /* how much of it is in use */
	const uint32_t *log_ring_at;    /* where the ring part is being written */
	const bool *log_wrapped;        /* the ring has gone round */
	uint64_t log_head, log_ring;    /* sizes of the two parts */
	const uint64_t *recording;      /* loader_recording: { physical address, length } of a screen recording */
	volatile uint64_t stop;         /* the loader's to write: the host has asked for the run to end */
	uint64_t magic2;                /* "XNULIVE2": what follows is there (a loader may meet an older kernel) */
	const uint64_t *sound;          /* loader_sound: the same for a recording of the sound */
	uint64_t magic3;                /* "XNULIVE3": the command mailbox follows */
	volatile uint64_t cmd_seq;      /* the loader's to write, after cmd: a new command is in cmd */
	volatile char cmd[120];         /* the loader's to write: "oem sh TEXT" from the host, NUL-terminated */
	uint64_t magic4;                /* "XNULIVE4": the inbox follows */
	char *inbox;                    /* where the loader puts a file the host pushes ("oem push") */
	uint64_t inbox_size;            /* how many bytes it holds */
	volatile uint64_t inbox_len;    /* the loader's to write: the length of the last file */
	volatile uint64_t inbox_seq;    /* the loader's to write, after the file and inbox_len */
};
extern struct loader_live loader_live;

void loader_panic_sync_ufs(const char *reason, uint32_t flags);

/* Also referenced from the early exception vector in start.s. */
char     loader_log[LOADER_LOG_SIZE];
uint32_t loader_log_len;
static bool     loader_return_entered;

/* One L1 table and one L2 table are enough to map a single 2 MB block. */
static uint64_t loader_l1[512] __attribute__((aligned(4096)));
static uint64_t loader_l2[512] __attribute__((aligned(4096)));

static uint32_t loader_log_ring_at;      /* where the next character goes in the ring */
static bool     loader_log_wrapped;
static bool     loader_log_linear;       /* the pieces have been put in order: only appending from now on */
static char     loader_log_scratch[LOADER_LOG_RING];

/*
 * Characters come from every processor, and from interrupt handlers on top of whatever was
 * writing one. The lock is of the simplest kind, good from the first line of C code to the
 * last of a panic; whoever cannot have it for a long while (its holder is gone: a panic
 * inside this very function) goes ahead without it.
 */
static uint32_t loader_log_lock;

static void loader_log_put_locked(char c);

void
loader_log_putc(char c)
{
	uint64_t daif;
	bool locked = false;

	if (c == '\r') {
		return;
	}
	daif = __builtin_arm_rsr64("DAIF");
	__builtin_arm_wsr("DAIFSet", DAIFSC_IRQF | DAIFSC_FIQF);
	for (uint32_t tries = 0; !locked && tries < 10000000; tries++) {
		locked = os_atomic_cmpxchg(&loader_log_lock, 0, 1, acquire);
	}
	loader_log_put_locked(c);
	if (locked) {
		os_atomic_store(&loader_log_lock, 0, release);
	}
	__builtin_arm_wsr64("DAIF", daif);
}

/*
 * A whole line at once, under the lock: lines written from several processors at the same time
 * (tools/latency.py's "tl:" lines, a frame's on one and a touch's on another) are not mixed up.
 */
void loader_log_line(const char *line);

void
loader_log_line(const char *line)
{
	uint64_t daif;
	bool locked = false;

	daif = __builtin_arm_rsr64("DAIF");
	__builtin_arm_wsr("DAIFSet", DAIFSC_IRQF | DAIFSC_FIQF);
	for (uint32_t tries = 0; !locked && tries < 10000000; tries++) {
		locked = os_atomic_cmpxchg(&loader_log_lock, 0, 1, acquire);
	}
	for (; *line != 0; line++) {
		if (*line != '\r') {
			loader_log_put_locked(*line);
		}
	}
	if (locked) {
		os_atomic_store(&loader_log_lock, 0, release);
	}
	__builtin_arm_wsr64("DAIF", daif);
}

/* Record the initial trap without acquiring the video console lock. */
void loader_fault_log(const char *message, uint64_t pc, uint64_t lr, uint32_t esr, uint64_t far);

void
loader_fault_log(const char *message, uint64_t pc, uint64_t lr, uint32_t esr, uint64_t far)
{
	char text[256];

	snprintf(text, sizeof(text), "\nFAULT: %s pc=0x%llx lr=0x%llx esr=0x%x far=0x%llx\n",
	    message, pc, lr, esr, far);
	loader_log_line(text);
}

#define LOADER_PANIC_BUF_SIZE    (256 * 1024)
static char loader_panic_buf[LOADER_PANIC_BUF_SIZE] __attribute__((aligned(4096)));
static uint32_t loader_panic_sync_lock;
static uint32_t loader_panic_sync_seq;

void
loader_panic_sync_ufs(const char *reason, uint32_t flags)
{
	uint64_t daif;
	bool locked = false;
	clock_sec_t secs = 0;
	clock_usec_t usecs = 0;
	char *p;
	size_t cap, at = 0;
	struct klog_head *kh;
	uint64_t write_len;
	int n;

	daif = __builtin_arm_rsr64("DAIF");
	__builtin_arm_wsr("DAIFSet", DAIFSC_IRQF | DAIFSC_FIQF);
	for (uint32_t tries = 0; !locked && tries < 1000000; tries++) {
		locked = os_atomic_cmpxchg(&loader_panic_sync_lock, 0, 1, acquire);
	}

	clock_get_system_microtime(&secs, &usecs);
	p = loader_panic_buf + sizeof(struct klog_head);
	cap = LOADER_PANIC_BUF_SIZE - sizeof(struct klog_head);

	n = snprintf(p + at, cap - at,
	    "=== HACKIOS KERNEL CRASH LOG ===\n"
	    "Reason: %s, Flags: 0x%x, Time: %llu sec, Beat: %llu, SyncSeq: %u\n",
	    reason ? reason : "unknown", flags, (unsigned long long)secs,
	    (unsigned long long)loader_live.heartbeat, ++loader_panic_sync_seq);
	if (n > 0 && (size_t)n < cap - at) {
		at += (size_t)n;
	}

	if (debug_buf_base != NULL && debug_buf_ptr > debug_buf_base) {
		size_t pb_len = (size_t)(debug_buf_ptr - debug_buf_base);
		int hn = snprintf(p + at, cap - at, "\n--- panic buffer (%lu bytes) ---\n", (unsigned long)pb_len);
		if (hn > 0 && (size_t)hn < cap - at) {
			at += (size_t)hn;
		}
		if (pb_len > cap - at - 1) {
			pb_len = cap - at - 1;
		}
		if (pb_len > 0) {
			memcpy(p + at, debug_buf_base, pb_len);
			at += pb_len;
			p[at] = '\0';
		}
	}

	if (loader_log_len > 0) {
		uint32_t log_take = loader_log_len;
		if (log_take > (uint32_t)(cap - at - 64)) {
			log_take = (uint32_t)(cap - at - 64);
		}
		if (log_take > 0) {
			int hn = snprintf(p + at, cap - at, "\n--- console log tail (%u bytes) ---\n", log_take);
			if (hn > 0 && (size_t)hn < cap - at) {
				at += (size_t)hn;
			}
			uint32_t log_start = loader_log_len - log_take;
			memcpy(p + at, loader_log + log_start, log_take);
			at += log_take;
			p[at] = '\0';
		}
	}

	write_len = (sizeof(struct klog_head) + at + 4095ULL) & ~4095ULL;
	if (write_len > LOADER_PANIC_BUF_SIZE) {
		write_len = LOADER_PANIC_BUF_SIZE;
	}
	if (write_len > sizeof(struct klog_head) + at) {
		bzero(p + at, (size_t)(write_len - (sizeof(struct klog_head) + at)));
	}

	kh = (struct klog_head *)loader_panic_buf;
	bzero(kh, sizeof(*kh));
	kh->magic = KLOG_MAGIC;
	kh->version = KLOG_VERSION;
	kh->payload_bytes = at;
	kh->timestamp = (uint64_t)secs;
	kh->boot_counter = (uint32_t)loader_live.heartbeat;
	kh->flags = flags;
	kh->payload_crc = crc32(0, p, at);
	kh->head_crc = crc32(0, kh, __builtin_offsetof(struct klog_head, head_crc));

	(void)annibale_ufs_var_io(true, ANNFS_PANIC_OFFSET, loader_panic_buf, write_len);

	if (locked) {
		os_atomic_store(&loader_panic_sync_lock, 0, release);
	}
	__builtin_arm_wsr64("DAIF", daif);
}

/* Save the original panic before platform debugger setup can itself fault. */
void loader_panic_log(const char *format, va_list *args, unsigned long caller);

void
loader_panic_log(const char *format, va_list *args, unsigned long caller)
{
	char text[768];
	va_list copy;

	snprintf(text, sizeof(text), "\nPANIC caller 0x%lx: ", caller);
	loader_log_line(text);
	va_copy(copy, *args);
	vsnprintf(text, sizeof(text), format, copy);
	va_end(copy);
	loader_log_line(text);
	loader_log_putc('\n');

	loader_panic_sync_ufs("panic_trap", 1);
}

static void
loader_log_put_locked(char c)
{
	if (loader_log_linear || loader_log_len < LOADER_LOG_HEAD) {
		if (loader_log_len < LOADER_LOG_SIZE) {
			loader_log[loader_log_len++] = c;
		}
	} else {
		loader_log[LOADER_LOG_HEAD + loader_log_ring_at] = c;
		if (++loader_log_ring_at == LOADER_LOG_RING) {
			loader_log_ring_at = 0;
			loader_log_wrapped = true;
		}
		if (!loader_log_wrapped) {
			loader_log_len = LOADER_LOG_HEAD + loader_log_ring_at;
		}
	}
}

/* Oldest first: the head, a note about what was dropped, then the ring from its oldest character. */
static void
loader_log_linearize(void)
{
	static const char note[] = "\n\n[... the log between the first 256 KB and the last 1 MB was dropped ...]\n\n";
	uint32_t older = LOADER_LOG_RING - loader_log_ring_at, n = LOADER_LOG_HEAD;

	if (loader_log_linear) {
		return;
	}
	loader_log_linear = true;
	if (!loader_log_wrapped) {
		return;
	}
	__builtin_memcpy(loader_log_scratch, loader_log + LOADER_LOG_HEAD + loader_log_ring_at, older);
	__builtin_memcpy(loader_log_scratch + older, loader_log + LOADER_LOG_HEAD, loader_log_ring_at);
	/* the note takes the place of the oldest characters of the ring */
	__builtin_memcpy(loader_log + n, note, sizeof(note) - 1);
	n += sizeof(note) - 1;
	__builtin_memcpy(loader_log + n, loader_log_scratch + sizeof(note) - 1, LOADER_LOG_RING - (sizeof(note) - 1));
	loader_log_len = LOADER_LOG_HEAD + LOADER_LOG_RING;
}

/* Patched by the loader: { magic, PA of its return stub, checkpoint to stop at, PA - VA }. See start.s. */
extern uint64_t loader_stub_slot[4];

/*
 * For a loader that watches from another processor core while the kernel runs (it starts the
 * kernel on a core of its choice and stays on the first one): a sign of life, and where the log
 * is, so that the log of a kernel that hangs -- or dies before it has said a word through any
 * other channel -- is not lost with it. The loader finds this by its first word in the kernel
 * it has loaded. The addresses are the kernel's virtual ones, filled in by the linker and so
 * valid from the first instruction; the loader knows the distance to the physical ones.
 */

/* The inbox: a file from the host while the kernel runs, for annsh "pull" (kern.annibale.inbox), so a
 * library can be replaced without a new image. In the kernel image so its memory is contiguous and
 * the loader reaches it the way it reaches the log. 16 MB holds the AIR library (about 15 MB); the
 * kernel's static span and the root image after it have to end below the resident system image at
 * 128 MB (xnuloader RESIDENT_RD_OFFSET), and 32 MB here left the root image 24 MB, too little for
 * a /private/var seed with the icon cache (tools/k90auto/make-payload.py checks the room). */
#define LOADER_INBOX_SIZE (16ULL << 20)
static char loader_inbox[LOADER_INBOX_SIZE] __attribute__((aligned(16384)));

/*
 * A screen recording (the display driver makes one with boot-arg rec_secs): where it is, for the
 * loader to hand to the host once the kernel is back. { physical address, bytes, kernel address }.
 */
uint64_t loader_recording[3];
/* ... and of the sound (/dev/annibale-audio makes one with boot-arg rec_sound). */
uint64_t loader_sound[3];

struct loader_live loader_live = {
	.magic = 0x214556494c554e58ULL, .log = loader_log, .log_len = &loader_log_len, .log_ring_at = &loader_log_ring_at,
	.log_wrapped = &loader_log_wrapped, .log_head = LOADER_LOG_HEAD, .log_ring = LOADER_LOG_RING,
	.recording = loader_recording,
	.magic2 = 0x324556494c554e58ULL, .sound = loader_sound,
	.magic3 = 0x334556494c554e58ULL,
	.magic4 = 0x344556494c554e58ULL, .inbox = loader_inbox, .inbox_size = LOADER_INBOX_SIZE,
};

/* The last file the host pushed and its sequence number, 0 before the first. */
uint64_t
loader_live_inbox(const char **data, uint64_t *len)
{
	uint64_t seq = loader_live.inbox_seq;

	__asm__ volatile ("dmb ish" ::: "memory");
	*len = seq != 0 && loader_live.inbox_len <= LOADER_INBOX_SIZE ? loader_live.inbox_len : 0;
	*data = loader_inbox;
	return seq;
}

/*
 * The last command the host passed through the loader ("oem sh TEXT") and its sequence number, 0
 * before the first; for kern.annibale.cmd in bsd/dev/annibale_threads.c. The loader writes the text
 * and then the number from its own core without a lock, so the text is taken only when the number
 * reads the same before and after the copy.
 */
uint64_t
loader_live_command(char *text, size_t size)
{
	uint64_t seq = 0;

	for (int attempt = 0; attempt < 8; attempt++) {
		size_t n = 0;

		seq = loader_live.cmd_seq;
		__asm__ volatile ("dmb ish" ::: "memory");
		while (n + 1 < size && n < sizeof(loader_live.cmd) && loader_live.cmd[n] != 0) {
			text[n] = loader_live.cmd[n];
			n++;
		}
		text[n] = 0;
		__asm__ volatile ("dmb ish" ::: "memory");
		if (loader_live.cmd_seq == seq) {
			break;
		}
	}
	return seq;
}

/* Valid from the first instruction of C code: does not depend on gVirtBase/gPhysBase being set up. */
static inline uint64_t
static_kvtophys(const void *va)
{
	return (uint64_t)va + loader_stub_slot[3];
}

/*
 * Jump to the loader's return stub. reason: 0 = orderly end, 2 = checkpoint.
 * Returns only if no loader is listening.
 */
static void
loader_jump(uint64_t reason, uint64_t code)
{
#if ARM_PGSHIFT == 12
	uint64_t stub = loader_stub_slot[1];
	uint64_t tcr, t0sz;
	uint32_t own_core = 0;

	if (stub == 0 || loader_return_entered) {
		return;
	}

	tcr = __builtin_arm_rsr64("TCR_EL1");
	t0sz = tcr & 0x3f;
	/* The TTBR0 walk must start at L1 (1 GB per entry) and reach the stub. */
	if (t0sz < 25 || t0sz > 33 || (stub >> (64 - t0sz)) != 0) {
		return;
	}
	loader_return_entered = true;
#if defined(GENERIC_GIC_V3_IRQ)
	gic_v3_irq_quiesce();
	/*
	 * With a core of its own (bootcpu=) the kernel does not go back into the loader's code on
	 * this processor: the stub leaves the log where the loader's core finds it and has the
	 * firmware switch this one off. It must go as the other cores do (psci_smp_cpu_off()), with
	 * nothing pending: after a panic the "stop" signal and the timer are.
	 */
	/* Early checkpoints can return before PE_init_platform installs bootArgs. */
	if (PE_state.bootArgs != NULL && PE_parse_boot_argn("bootcpu", &own_core, sizeof(own_core))) {
		__builtin_arm_wsr64("CNTV_CTL_EL0", CNTV_CTL_EL0_IMASKED);
		gic_v3_irq_cpu_shutdown();
	}
#endif

	loader_l1[stub >> 30] = static_kvtophys(loader_l2) | ARM_TTE_TYPE_TABLE | ARM_TTE_VALID;
	loader_l2[(stub >> 21) & 0x1ff] = (stub & ~0x1fffffULL) | ARM_TTE_VALID | ARM_TTE_TYPE_BLOCK |
	    ARM_TTE_BLOCK_AF | ARM_TTE_BLOCK_SH(SH_OUTER_MEMORY) | ARM_TTE_BLOCK_AP(AP_RWNA) |
	    ARM_TTE_BLOCK_ATTRINDX(CACHE_ATTRINDX_WRITEBACK);

	/*
	 * The stub turns the MMU off, and on real hardware dirty cache lines do
	 * not survive that: write the log back to RAM first.
	 */
	for (uintptr_t p = (uintptr_t)loader_log & ~63UL; p < (uintptr_t)loader_log + loader_log_len; p += 64) {
		__asm__ volatile ("dc cvac, %0" : : "r" (p));
	}
	/* ... and a screen recording, and the note of where it is */
	for (uintptr_t p = loader_recording[2] & ~63UL; p < loader_recording[2] + loader_recording[1]; p += 64) {
		__asm__ volatile ("dc cvac, %0" : : "r" (p));
	}
	__asm__ volatile ("dc cvac, %0" : : "r" ((uintptr_t)loader_recording));
	__asm__ volatile ("dc cvac, %0" : : "r" ((uintptr_t)loader_recording + 16));
	for (uintptr_t p = loader_sound[2] & ~63UL; p < loader_sound[2] + loader_sound[1]; p += 64) {
		__asm__ volatile ("dc cvac, %0" : : "r" (p));
	}
	__asm__ volatile ("dc cvac, %0" : : "r" ((uintptr_t)loader_sound));
	__asm__ volatile ("dc cvac, %0" : : "r" ((uintptr_t)loader_sound + 16));
	__asm__ volatile ("dsb sy");

	register uint64_t r_ttbr0 __asm__("x0") = static_kvtophys(loader_l1);
	register uint64_t r_log __asm__("x2") = static_kvtophys(loader_log);
	register uint64_t r_len __asm__("x3") = loader_log_len;
	register uint64_t r_tcr __asm__("x4") = tcr;
	register uint64_t r_stub __asm__("x5") = stub;
	register uint64_t r_reason __asm__("x6") = reason;
	register uint64_t r_code __asm__("x7") = code;

	__asm__ volatile (
                "msr DAIFSet, #0xf\n"
                "bic x4, x4, #0x80\n"           /* TCR_EL1.EPD0: allow TTBR0 walks */
                "msr TCR_EL1, x4\n"
                "msr TTBR0_EL1, x0\n"
                "isb\n"
                "tlbi vmalle1\n"
                "dsb sy\n"
                "isb\n"
                "mov x0, x2\n"
                "mov x1, x3\n"
                "mov x2, x6\n"
                "mov x3, x7\n"
                "br x5\n"
                : : "r" (r_ttbr0), "r" (r_log), "r" (r_len), "r" (r_tcr), "r" (r_stub), "r" (r_reason), "r" (r_code));
	__builtin_unreachable();
#else
	(void)reason; (void)code;
#endif /* ARM_PGSHIFT == 12 */
}

extern char *debug_buf_base, *debug_buf_ptr;

/* bsd/sys/msgbuf.h (not includable from osfmk) */
struct msgbuf {
	int   msg_magic;
	int   msg_size;
	int   msg_bufx;         /* write pointer */
	int   msg_bufr;         /* read pointer */
	char *msg_bufc;         /* buffer */
};
extern struct msgbuf *msgbufp;

static void
loader_log_puts(const char *s)
{
	for (; *s; s++) {
		loader_log_putc(*s);
	}
}

/*
 * Everything printf()/IOLog()/os_log wrote ends up in the kernel message
 * buffer (what dmesg shows), whether or not a console displayed it.
 */
static void
loader_log_append_msgbuf(void)
{
	struct msgbuf *mb = msgbufp;

	if (mb == NULL || mb->msg_bufc == NULL || mb->msg_size <= 0 || mb->msg_bufx < 0 || mb->msg_bufx > mb->msg_size) {
		return;
	}
	loader_log_puts("\n--- kernel message buffer ---\n");
	/* oldest data first: [bufx, size) is only meaningful once the buffer has wrapped */
	for (int pass = 0; pass < 2; pass++) {
		int from = pass == 0 ? mb->msg_bufx : 0;
		int to = pass == 0 ? mb->msg_size : mb->msg_bufx;
		for (int i = from; i < to; i++) {
			if (mb->msg_bufc[i] != 0) {
				loader_log_putc(mb->msg_bufc[i]);
			}
		}
	}
}

void
loader_return(void)
{
#if defined(GENERIC_PSCI_SMP)
	/*
	 * With more than one processor: the others switch themselves off first, and the rest of
	 * this is done by the boot processor, the one the loader gave us. This call comes back
	 * on that processor only (on another one it has it call loader_return() in its turn).
	 */
	psci_smp_stop_others();
#endif
	/*
	 * A panic's text is first collected in the panic buffer and only later
	 * flushed to the console; if the console itself is what failed, that
	 * never happens. Append the buffer so the loader gets it either way.
	 */
	loader_log_linearize();
	if (!loader_return_entered) {
		loader_log_append_msgbuf();
	}
	if (!loader_return_entered && debug_buf_base != NULL && debug_buf_ptr > debug_buf_base &&
	    (size_t)(debug_buf_ptr - debug_buf_base) < 256 * 1024) {
		loader_log_puts("\n--- panic buffer ---\n");
		for (const char *c = debug_buf_base; c < debug_buf_ptr; c++) {
			loader_log_putc(*c);
		}
	}
	/* Synchronously flush final complete panic/crash log to darwin_var reserved sector before storage quiesce */
	loader_panic_sync_ufs("loader_return", 1);

	annibale_ufs_quiesce();          /* this kernel's requests to the storage done, UEFI's list as it was, for the log */
	adreno8_return_quiesce();       /* the GMU back in reset and its translation off without parking */
	bool iris_quiesced = annibale_iris_return_quiesce();
	annibale_wifi_quiesce();         /* the Wi-Fi DSP, if it still runs (a panic), is not left to itself */
	annibale_haptic_quiesce();      /* or the PMIC's haptics block of the other phone, if it was configured */
	annibale_torch_quiesce();       /* or the other phone's, lit on its PMIC's flash module */
	if (annibale_halting_poweroff) {
		MiniIOMobileFramebufferPowerOff();
	} else {
		MiniIOMobileFramebufferQuiesce();       /* the display back on the boot framebuffer, the last frame in it (fb_flip) */
	}

	hv_wdt_pet_NOW();
	/* reason 3 keeps loader memory held even if every kernel CPU is off. */
	loader_jump(iris_quiesced ? 0 : 3, iris_quiesced ? 0 : 9);
}

/* Bring-up aid: stop here if the loader asked for checkpoint n. */
void
loader_checkpoint(uint64_t n)
{
	if (loader_stub_slot[2] == n) {
		loader_jump(2, n);
	}
}

/*
 * boot-arg loader_return_after=<seconds>: hand control back to the loader
 * after that long, whatever the kernel is doing. This is how the log gets out
 * when the kernel does not panic but simply waits (e.g. for a root device).
 */
/*
 * For trying the ways out when there is more than one processor: boot-arg return_cpu=<n> has
 * that processor make the timed return, from an interrupt handler -- any but the boot processor
 * has to hand it over (psci_smp_stop_others()) --, and return_panic=1 makes a panic of it.
 */
static void
loader_return_test(void *as_panic)
{
	if (as_panic != (void *)1) {
		panic("return_panic: the panic that was asked for, on cpu %d", cpu_number());
	}
	loader_return();
}

static void
loader_return_timer(__unused thread_call_param_t p0, __unused thread_call_param_t p1)
{
	static const char banner[] = "\n--- loader_return_after expired ---\n";
	uint32_t cpu = 0, as_panic = 0;

	for (const char *c = banner; *c; c++) {
		loader_log_putc(*c);
	}
	PE_parse_boot_argn("return_panic", &as_panic, sizeof(as_panic));
	if (as_panic) {
		loader_panic_sync_ufs("return_panic_timer", 2);
	}
	if (!as_panic) {
		annibale_var_save_on_return();   /* the data volume kept, while the system is still whole */
		annibale_wifi_stop();            /* and the Wi-Fi DSP, if it runs, shut down */
	}
	if (PE_parse_boot_argn("return_cpu", &cpu, sizeof(cpu)) && cpu <= (uint32_t)ml_get_max_cpu_number() &&
	    cpu_xcall((int)cpu, loader_return_test, (void *)(uintptr_t)(as_panic ? 2 : 1)) == KERN_SUCCESS) {
		for (;;) {
			delay_for_interval(1000, NSEC_PER_MSEC);        /* that processor ends it */
		}
	}
	loader_return_test((void *)(uintptr_t)(as_panic ? 2 : 1));
}

__startup_func
static void
loader_return_timer_init(void)
{
	uint32_t seconds = 0;
	uint64_t deadline;

	if (!PE_parse_boot_argn("loader_return_after", &seconds, sizeof(seconds)) || seconds == 0) {
		return;
	}
	thread_call_t call = thread_call_allocate(loader_return_timer, NULL);
	clock_interval_to_deadline(seconds, NSEC_PER_SEC, &deadline);
	thread_call_enter_delayed(call, deadline);
}
STARTUP(EARLY_BOOT, STARTUP_RANK_LAST, loader_return_timer_init);

/*
 * A loader that watches from another core also listens to the host, and passes on a request to
 * end the run ("xl stop") by setting loader_live.stop. Look once a second.
 */
static thread_call_t loader_stop_call;

static void
loader_stop_poll(__unused thread_call_param_t p0, __unused thread_call_param_t p1)
{
	uint64_t deadline;

	if (loader_live.stop) {
		static const char banner[] = "\n--- the host asked for the end of the run: back to the loader ---\n";
		for (const char *c = banner; *c; c++) {
			loader_log_putc(*c);
		}
		annibale_var_save_on_return();
		annibale_wifi_stop();
		loader_return();
	}
	clock_interval_to_deadline(100, NSEC_PER_MSEC, &deadline);
	thread_call_enter_delayed(loader_stop_call, deadline);
}

__startup_func
static void
loader_stop_poll_init(void)
{
	loader_stop_call = thread_call_allocate(loader_stop_poll, NULL);
	loader_stop_poll(NULL, NULL);
}
STARTUP(EARLY_BOOT, STARTUP_RANK_LAST, loader_stop_poll_init);

/*
 * boot-arg hv_wdt_pet=1: the loader has armed the Qualcomm hypervisor's
 * virtual watchdog (it resets the phone when a kernel hangs, so that test
 * runs need nobody at the device). Its timeout is at most 65 seconds; feed
 * it from a timer so that a healthy kernel can run for as long as it likes.
 */
#define VIRT_WDT_PET            0x86000007u
#define HV_WDT_PET_SECONDS      10

static thread_call_t hv_wdt_call;
static uint32_t hv_wdt_enabled;

#define MEMORY_REPORT_BEATS     6               /* a line about memory every so many heartbeats */

#if MEMSTAT_THRESHOLD_NAMES
extern uint32_t memorystatus_available_pages, memstat_idle_threshold, memstat_critical_threshold;
#define memorystatus_available_pages_critical           memstat_idle_threshold
#define memorystatus_available_pages_critical_base      memstat_critical_threshold
#else
extern unsigned int memorystatus_available_pages, memorystatus_available_pages_critical,
    memorystatus_available_pages_critical_base;
#endif
extern uint32_t c_segment_pages_compressed;
extern _Atomic uint64_t ramfs_pages_in_use;
extern void MiniIOSurfaceUsage(uint32_t *count, uint64_t *bytes);

/*
 * Where the memory is, in megabytes: for reading a session's log afterwards. "available" is what
 * the kernel's own count says (free and file-backed): below the first threshold it kills idle
 * daemons, and once none is left and it is below the second, whatever is next in line -- the
 * window server included.
 */
void annibale_memory_line(char *buf, size_t len);

/* The line itself (also kern.annibale_memory, for a job list to keep: bsd/miscfs/apfs/apfs_vfsops.c) */
void
annibale_memory_line(char *buf, size_t len)
{
#define MB(pages)       ((unsigned int)(((uint64_t)(pages) * PAGE_SIZE) >> 20))
	uint32_t surfaces = 0;
	uint64_t surface_bytes = 0;

	MiniIOSurfaceUsage(&surfaces, &surface_bytes);
	snprintf(buf, len, "memory: free %u, files %u, programs %u, wired %u (%u surfaces %u, ramfs %u), compressor %u "
	    "(holding %u) MB; available %u, kills below %u (the idle) and %u (anybody)\n",
	    MB(vm_page_free_count), MB(vm_page_pageable_external_count), MB(vm_page_pageable_internal_count),
	    MB(vm_page_wire_count), surfaces, (unsigned int)(surface_bytes >> 20),
	    MB(os_atomic_load(&ramfs_pages_in_use, relaxed)),
	    MB(VM_PAGE_COMPRESSOR_COUNT), MB(c_segment_pages_compressed),
	    MB(memorystatus_available_pages),
	    MB(memorystatus_available_pages_critical), MB(memorystatus_available_pages_critical_base));
#undef MB
}

static void
memory_report(void)
{
	char line[256];

	annibale_memory_line(line, sizeof(line));
	printf("%s", line);
}

void
hv_wdt_pet_NOW(void)
{
	register uint64_t x0 __asm__("x0") = VIRT_WDT_PET;
	register uint64_t x1 __asm__("x1") = 0;
	register uint64_t x2 __asm__("x2") = 0;
	register uint64_t x3 __asm__("x3") = 0;

	__asm__ volatile ("smc #0" : "+r" (x0), "+r" (x1), "+r" (x2), "+r" (x3) : :
	    "x4", "x5", "x6", "x7", "x8", "x9", "x10", "x11", "x12", "x13", "x14", "x15", "x16", "x17");
}

/* Every HV_WDT_PET_SECONDS: feed the watchdog if there is one, and show any watching loader a sign of life. */
static void
hv_wdt_pet(__unused thread_call_param_t p0, __unused thread_call_param_t p1)
{
	uint64_t deadline;

	if (debug_buf_base != NULL && debug_buf_ptr > debug_buf_base) {
		loader_panic_sync_ufs("watchdog_panic", 2);
	}

	if (hv_wdt_enabled) {
		hv_wdt_pet_NOW();
	}
	if (++loader_live.heartbeat % MEMORY_REPORT_BEATS == 0) {
		memory_report();
	}

	clock_interval_to_deadline(HV_WDT_PET_SECONDS, NSEC_PER_SEC, &deadline);
	thread_call_enter_delayed(hv_wdt_call, deadline);
}

__startup_func
static void
hv_wdt_pet_init(void)
{
	PE_parse_boot_argn("hv_wdt_pet", &hv_wdt_enabled, sizeof(hv_wdt_enabled));
	hv_wdt_call = thread_call_allocate(hv_wdt_pet, NULL);
	hv_wdt_pet(NULL, NULL);
}
STARTUP(EARLY_BOOT, STARTUP_RANK_LAST, hv_wdt_pet_init);

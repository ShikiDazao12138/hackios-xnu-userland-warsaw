/*
 * minicrypto: AES (FIPS 197) with ECB, CBC and CTR modes, in the descriptor
 * format the kernel's crypto interface expects (struct ccmode_*).
 *
 * A compact byte-oriented implementation written from the specification; the
 * S-boxes were generated from their definition. It is not constant-time and
 * not fast: it exists so that kernel code which merely needs a block cipher
 * at boot (the TCP stack keys an AES context during initialisation) works.
 * Checked at boot against FIPS-197 / OpenSSL vectors (mc_aes_selftest).
 *
 * Not implemented: XTS, GCM.
 */
#include <corecrypto/ccmode.h>
#include <corecrypto/ccmode_impl.h>
#include <corecrypto/ccaes.h>
#include <string.h>

#include "minicrypto.h"
#include "mc_ce_arm64.h"

static const uint8_t aes_sbox[256] = {
	0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
	0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
	0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
	0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
	0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
	0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
	0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
	0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
	0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
	0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
	0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
	0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
	0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
	0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
	0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
	0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16,
};

static const uint8_t aes_inv_sbox[256] = {
	0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb,
	0x7c, 0xe3, 0x39, 0x82, 0x9b, 0x2f, 0xff, 0x87, 0x34, 0x8e, 0x43, 0x44, 0xc4, 0xde, 0xe9, 0xcb,
	0x54, 0x7b, 0x94, 0x32, 0xa6, 0xc2, 0x23, 0x3d, 0xee, 0x4c, 0x95, 0x0b, 0x42, 0xfa, 0xc3, 0x4e,
	0x08, 0x2e, 0xa1, 0x66, 0x28, 0xd9, 0x24, 0xb2, 0x76, 0x5b, 0xa2, 0x49, 0x6d, 0x8b, 0xd1, 0x25,
	0x72, 0xf8, 0xf6, 0x64, 0x86, 0x68, 0x98, 0x16, 0xd4, 0xa4, 0x5c, 0xcc, 0x5d, 0x65, 0xb6, 0x92,
	0x6c, 0x70, 0x48, 0x50, 0xfd, 0xed, 0xb9, 0xda, 0x5e, 0x15, 0x46, 0x57, 0xa7, 0x8d, 0x9d, 0x84,
	0x90, 0xd8, 0xab, 0x00, 0x8c, 0xbc, 0xd3, 0x0a, 0xf7, 0xe4, 0x58, 0x05, 0xb8, 0xb3, 0x45, 0x06,
	0xd0, 0x2c, 0x1e, 0x8f, 0xca, 0x3f, 0x0f, 0x02, 0xc1, 0xaf, 0xbd, 0x03, 0x01, 0x13, 0x8a, 0x6b,
	0x3a, 0x91, 0x11, 0x41, 0x4f, 0x67, 0xdc, 0xea, 0x97, 0xf2, 0xcf, 0xce, 0xf0, 0xb4, 0xe6, 0x73,
	0x96, 0xac, 0x74, 0x22, 0xe7, 0xad, 0x35, 0x85, 0xe2, 0xf9, 0x37, 0xe8, 0x1c, 0x75, 0xdf, 0x6e,
	0x47, 0xf1, 0x1a, 0x71, 0x1d, 0x29, 0xc5, 0x89, 0x6f, 0xb7, 0x62, 0x0e, 0xaa, 0x18, 0xbe, 0x1b,
	0xfc, 0x56, 0x3e, 0x4b, 0xc6, 0xd2, 0x79, 0x20, 0x9a, 0xdb, 0xc0, 0xfe, 0x78, 0xcd, 0x5a, 0xf4,
	0x1f, 0xdd, 0xa8, 0x33, 0x88, 0x07, 0xc7, 0x31, 0xb1, 0x12, 0x10, 0x59, 0x27, 0x80, 0xec, 0x5f,
	0x60, 0x51, 0x7f, 0xa9, 0x19, 0xb5, 0x4a, 0x0d, 0x2d, 0xe5, 0x7a, 0x9f, 0x93, 0xc9, 0x9c, 0xef,
	0xa0, 0xe0, 0x3b, 0x4d, 0xae, 0x2a, 0xf5, 0xb0, 0xc8, 0xeb, 0xbb, 0x3c, 0x83, 0x53, 0x99, 0x61,
	0x17, 0x2b, 0x04, 0x7e, 0xba, 0x77, 0xd6, 0x26, 0xe1, 0x69, 0x14, 0x63, 0x55, 0x21, 0x0c, 0x7d,
};

/* struct mc_aes_key is defined in mc_ce_arm64.h */

static inline uint8_t
xtime(uint8_t x)
{
	return (uint8_t)((x << 1) ^ ((x >> 7) * 0x1b));
}

static inline uint8_t
gmul(uint8_t a, uint8_t b)
{
	uint8_t p = 0;
	while (b) {
		if (b & 1) {
			p ^= a;
		}
		a = xtime(a);
		b >>= 1;
	}
	return p;
}

static int
mc_aes_setkey(struct mc_aes_key *k, size_t key_len, const uint8_t *key)
{
	uint32_t nk = (uint32_t)key_len / 4;
	uint8_t rcon = 1;

	if (key_len != 16 && key_len != 24 && key_len != 32) {
		return -1;
	}
	k->rounds = nk + 6;
	memcpy(k->rk, key, key_len);
	for (uint32_t i = nk; i < 4 * (k->rounds + 1); i++) {
		uint8_t t[4];
		memcpy(t, k->rk + 4 * (i - 1), 4);
		if (i % nk == 0) {
			uint8_t first = t[0];
			t[0] = aes_sbox[t[1]] ^ rcon;
			t[1] = aes_sbox[t[2]];
			t[2] = aes_sbox[t[3]];
			t[3] = aes_sbox[first];
			rcon = xtime(rcon);
		} else if (nk > 6 && i % nk == 4) {
			for (uint32_t j = 0; j < 4; j++) {
				t[j] = aes_sbox[t[j]];
			}
		}
		for (uint32_t j = 0; j < 4; j++) {
			k->rk[4 * i + j] = k->rk[4 * (i - nk) + j] ^ t[j];
		}
	}
	return 0;
}

static void
mc_aes_encrypt_block(const struct mc_aes_key *k, const uint8_t *in, uint8_t *out)
{
	uint8_t s[16], t[16];

	for (uint32_t i = 0; i < 16; i++) {
		s[i] = in[i] ^ k->rk[i];
	}
	for (uint32_t r = 1; r <= k->rounds; r++) {
		/* SubBytes + ShiftRows (state is column-major: s[4*col + row]) */
		for (int c = 0; c < 4; c++) {
			for (int row = 0; row < 4; row++) {
				t[4 * c + row] = aes_sbox[s[4 * ((c + row) & 3) + row]];
			}
		}
		if (r != k->rounds) {
			for (int c = 0; c < 4; c++) {
				uint8_t *p = t + 4 * c;
				uint8_t a0 = p[0], a1 = p[1], a2 = p[2], a3 = p[3];
				p[0] = (uint8_t)(xtime(a0) ^ xtime(a1) ^ a1 ^ a2 ^ a3);
				p[1] = (uint8_t)(a0 ^ xtime(a1) ^ xtime(a2) ^ a2 ^ a3);
				p[2] = (uint8_t)(a0 ^ a1 ^ xtime(a2) ^ xtime(a3) ^ a3);
				p[3] = (uint8_t)(xtime(a0) ^ a0 ^ a1 ^ a2 ^ xtime(a3));
			}
		}
		for (uint32_t i = 0; i < 16; i++) {
			s[i] = t[i] ^ k->rk[16 * r + i];
		}
	}
	memcpy(out, s, 16);
}

static void
mc_aes_decrypt_block(const struct mc_aes_key *k, const uint8_t *in, uint8_t *out)
{
	uint8_t s[16], t[16];

	for (uint32_t i = 0; i < 16; i++) {
		s[i] = in[i] ^ k->rk[16 * k->rounds + i];
	}
	for (uint32_t r = k->rounds; r-- > 0;) {
		/* InvShiftRows + InvSubBytes */
		for (int c = 0; c < 4; c++) {
			for (int row = 0; row < 4; row++) {
				t[4 * ((c + row) & 3) + row] = aes_inv_sbox[s[4 * c + row]];
			}
		}
		for (uint32_t i = 0; i < 16; i++) {
			t[i] ^= k->rk[16 * r + i];
		}
		if (r != 0) {
			for (int c = 0; c < 4; c++) {
				uint8_t *p = t + 4 * c;
				uint8_t a0 = p[0], a1 = p[1], a2 = p[2], a3 = p[3];
				p[0] = (uint8_t)(gmul(a0, 14) ^ gmul(a1, 11) ^ gmul(a2, 13) ^ gmul(a3, 9));
				p[1] = (uint8_t)(gmul(a0, 9) ^ gmul(a1, 14) ^ gmul(a2, 11) ^ gmul(a3, 13));
				p[2] = (uint8_t)(gmul(a0, 13) ^ gmul(a1, 9) ^ gmul(a2, 14) ^ gmul(a3, 11));
				p[3] = (uint8_t)(gmul(a0, 11) ^ gmul(a1, 13) ^ gmul(a2, 9) ^ gmul(a3, 14));
			}
		}
		memcpy(s, t, 16);
	}
	memcpy(out, s, 16);
}

/* ---------------------------------------------------------------- ECB --- */

static int
mc_ecb_init(const struct ccmode_ecb *ecb __unused, ccecb_ctx *ctx, size_t key_nbytes, const void *key)
{
	return mc_aes_setkey((struct mc_aes_key *)ctx, key_nbytes, key);
}

static int
mc_ecb_encrypt(const ccecb_ctx *ctx, size_t nblocks, const void *in, void *out)
{
	const struct mc_aes_key *k = (const struct mc_aes_key *)ctx;
#if defined(KERNEL)
	if (mc_ce_has_aes() && !ml_at_interrupt_context() && nblocks >= 4) {
		struct mc_fpu_state fpu;
		kernel_fpu_begin(&fpu);
		mc_ce_aes_ecb_encrypt(k, nblocks, in, out);
		kernel_fpu_end(&fpu);
		return 0;
	}
#else
	if (mc_ce_has_aes() && nblocks >= 4) {
		mc_ce_aes_ecb_encrypt(k, nblocks, in, out);
		return 0;
	}
#endif
	const uint8_t *i = in;
	uint8_t *o = out;
	for (; nblocks > 0; nblocks--, i += 16, o += 16) {
		mc_aes_encrypt_block(k, i, o);
	}
	return 0;
}

static int
mc_ecb_decrypt(const ccecb_ctx *ctx, size_t nblocks, const void *in, void *out)
{
	const struct mc_aes_key *k = (const struct mc_aes_key *)ctx;
#if defined(KERNEL)
	if (mc_ce_has_aes() && !ml_at_interrupt_context() && nblocks >= 4) {
		struct mc_fpu_state fpu;
		kernel_fpu_begin(&fpu);
		mc_ce_aes_ecb_decrypt(k, nblocks, in, out);
		kernel_fpu_end(&fpu);
		return 0;
	}
#else
	if (mc_ce_has_aes() && nblocks >= 4) {
		mc_ce_aes_ecb_decrypt(k, nblocks, in, out);
		return 0;
	}
#endif
	const uint8_t *i = in;
	uint8_t *o = out;
	for (; nblocks > 0; nblocks--, i += 16, o += 16) {
		mc_aes_decrypt_block(k, i, o);
	}
	return 0;
}

const struct ccmode_ecb mc_aes_ecb_encrypt = {
	.size = sizeof(struct mc_aes_key),
	.block_size = 16,
	.init = mc_ecb_init,
	.ecb = mc_ecb_encrypt,
};

const struct ccmode_ecb mc_aes_ecb_decrypt = {
	.size = sizeof(struct mc_aes_key),
	.block_size = 16,
	.init = mc_ecb_init,
	.ecb = mc_ecb_decrypt,
};

/* ---------------------------------------------------------------- CBC --- */

static int
mc_cbc_init(const struct ccmode_cbc *cbc __unused, cccbc_ctx *ctx, size_t key_len, const void *key)
{
	return mc_aes_setkey((struct mc_aes_key *)ctx, key_len, key);
}

static int
mc_cbc_encrypt(const cccbc_ctx *ctx, cccbc_iv *iv, size_t nblocks, const void *in, void *out)
{
	const struct mc_aes_key *k = (const struct mc_aes_key *)ctx;
#if defined(KERNEL)
	if (mc_ce_has_aes() && !ml_at_interrupt_context() && nblocks >= 4) {
		struct mc_fpu_state fpu;
		kernel_fpu_begin(&fpu);
		mc_ce_aes_cbc_encrypt(k, (uint8_t *)iv, nblocks, in, out);
		kernel_fpu_end(&fpu);
		return 0;
	}
#else
	if (mc_ce_has_aes() && nblocks >= 4) {
		mc_ce_aes_cbc_encrypt(k, (uint8_t *)iv, nblocks, in, out);
		return 0;
	}
#endif
	const uint8_t *i = in;
	uint8_t *o = out, *chain = (uint8_t *)iv;

	for (; nblocks > 0; nblocks--, i += 16, o += 16) {
		for (int b = 0; b < 16; b++) {
			chain[b] ^= i[b];
		}
		mc_aes_encrypt_block(k, chain, chain);
		memcpy(o, chain, 16);
	}
	return 0;
}

static int
mc_cbc_decrypt(const cccbc_ctx *ctx, cccbc_iv *iv, size_t nblocks, const void *in, void *out)
{
	const struct mc_aes_key *k = (const struct mc_aes_key *)ctx;
#if defined(KERNEL)
	if (mc_ce_has_aes() && !ml_at_interrupt_context() && nblocks >= 4) {
		struct mc_fpu_state fpu;
		kernel_fpu_begin(&fpu);
		mc_ce_aes_cbc_decrypt(k, (uint8_t *)iv, nblocks, in, out);
		kernel_fpu_end(&fpu);
		return 0;
	}
#else
	if (mc_ce_has_aes() && nblocks >= 4) {
		mc_ce_aes_cbc_decrypt(k, (uint8_t *)iv, nblocks, in, out);
		return 0;
	}
#endif
	const uint8_t *i = in;
	uint8_t *o = out, *chain = (uint8_t *)iv;

	for (; nblocks > 0; nblocks--, i += 16, o += 16) {
		uint8_t cipher[16], plain[16];
		memcpy(cipher, i, 16); /* in and out may be the same buffer */
		mc_aes_decrypt_block(k, cipher, plain);
		for (int b = 0; b < 16; b++) {
			o[b] = plain[b] ^ chain[b];
		}
		memcpy(chain, cipher, 16);
	}
	return 0;
}

const struct ccmode_cbc mc_aes_cbc_encrypt = {
	.size = sizeof(struct mc_aes_key),
	.block_size = 16,
	.init = mc_cbc_init,
	.cbc = mc_cbc_encrypt,
};

const struct ccmode_cbc mc_aes_cbc_decrypt = {
	.size = sizeof(struct mc_aes_key),
	.block_size = 16,
	.init = mc_cbc_init,
	.cbc = mc_cbc_decrypt,
};

/* ---------------------------------------------------------------- CTR --- */

struct mc_aes_ctr {
	struct mc_aes_key key;
	uint8_t  counter[16];       /* 128-bit big-endian counter */
	uint8_t  stream[16];
	uint32_t used;              /* bytes of stream[] already consumed */
};

static int
mc_ctr_setctr(const struct ccmode_ctr *mode __unused, ccctr_ctx *ctx, const void *ctr)
{
	struct mc_aes_ctr *c = (struct mc_aes_ctr *)ctx;
	memcpy(c->counter, ctr, 16);
	c->used = 16;
	return 0;
}

static int
mc_ctr_init(const struct ccmode_ctr *mode, ccctr_ctx *ctx, size_t key_len, const void *key, const void *iv)
{
	struct mc_aes_ctr *c = (struct mc_aes_ctr *)ctx;
	int rc = mc_aes_setkey(&c->key, key_len, key);
	if (rc == 0) {
		rc = mc_ctr_setctr(mode, ctx, iv);
	}
	return rc;
}

static int
mc_ctr_crypt(ccctr_ctx *ctx, size_t nbytes, const void *in, void *out)
{
	struct mc_aes_ctr *c = (struct mc_aes_ctr *)ctx;
	const uint8_t *i = in;
	uint8_t *o = out;

	/* Drain any remaining keystream in stream buffer */
	while (nbytes > 0 && c->used < 16) {
		*o++ = *i++ ^ c->stream[c->used++];
		nbytes--;
	}
	if (nbytes == 0) {
		return 0;
	}

#if defined(KERNEL)
	if (mc_ce_has_aes() && !ml_at_interrupt_context() && nbytes >= 64) {
		struct mc_fpu_state fpu;
		kernel_fpu_begin(&fpu);
		size_t full_blocks = (nbytes / 16) * 16;
		mc_ce_aes_ctr_crypt(&c->key, c->counter, full_blocks, i, o);
		kernel_fpu_end(&fpu);
		i += full_blocks;
		o += full_blocks;
		nbytes -= full_blocks;
		c->used = 16;
	}
#else
	if (mc_ce_has_aes() && nbytes >= 64) {
		size_t full_blocks = (nbytes / 16) * 16;
		mc_ce_aes_ctr_crypt(&c->key, c->counter, full_blocks, i, o);
		i += full_blocks;
		o += full_blocks;
		nbytes -= full_blocks;
		c->used = 16;
	}
#endif

	for (; nbytes > 0; nbytes--) {
		if (c->used == 16) {
			mc_aes_encrypt_block(&c->key, c->counter, c->stream);
			for (int b = 15; b >= 0 && ++c->counter[b] == 0; b--) {
			}
			c->used = 0;
		}
		*o++ = *i++ ^ c->stream[c->used++];
	}
	return 0;
}

const struct ccmode_ctr mc_aes_ctr_crypt = {
	.size = sizeof(struct mc_aes_ctr),
	.block_size = 1,
	.ecb_block_size = 16,
	.init = mc_ctr_init,
	.setctr = mc_ctr_setctr,
	.ctr = mc_ctr_crypt,
};

/* ---------------------------------------------------------- self test --- */

/* Returns a description of the first failing check, or NULL if all pass. */
const char *
mc_aes_selftest(void)
{
	static const uint8_t key[32] = { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f };
	static const uint8_t iv[16] = { 0xf0, 0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7, 0xf8, 0xf9, 0xfa, 0xfb, 0xfc, 0xfd, 0xfe, 0xff };
	static const uint8_t plain[48] = { 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0x6b, 0xc1, 0xbe, 0xe2, 0x2e, 0x40, 0x9f, 0x96, 0xe9, 0x3d, 0x7e, 0x11, 0x73, 0x93, 0x17, 0x2a, 0xae, 0x2d, 0x8a, 0x57, 0x1e, 0x03, 0xac, 0x9c, 0x9e, 0xb7, 0x6f, 0xac, 0x45, 0xaf, 0x8e, 0x51 };
	static const uint8_t ecb128[16] = { 0x69, 0xc4, 0xe0, 0xd8, 0x6a, 0x7b, 0x04, 0x30, 0xd8, 0xcd, 0xb7, 0x80, 0x70, 0xb4, 0xc5, 0x5a };   /* FIPS 197 C.1 */
	static const uint8_t ecb256[16] = { 0x8e, 0xa2, 0xb7, 0xca, 0x51, 0x67, 0x45, 0xbf, 0xea, 0xfc, 0x49, 0x90, 0x4b, 0x49, 0x60, 0x89 };   /* FIPS 197 C.3 */
	static const uint8_t cbc128[48] = { 0x77, 0x02, 0xfc, 0x9b, 0x71, 0xc6, 0x3d, 0x26, 0xa2, 0xf0, 0x9d, 0xf5, 0xc4, 0x45, 0x10, 0x2a, 0x12, 0x4e, 0x7d, 0x18, 0xd9, 0x0f, 0xb7, 0x68, 0x47, 0x71, 0xd3, 0xb9, 0x5b, 0x9b, 0x45, 0xcd, 0x56, 0x95, 0x95, 0xd6, 0xeb, 0x0c, 0x39, 0x43, 0x74, 0xf8, 0x70, 0x7e, 0xa5, 0x3e, 0xe7, 0x03 };      /* OpenSSL */
	static const uint8_t ctr256[40] = { 0x92, 0x11, 0xef, 0xbe, 0x67, 0xc3, 0xe6, 0xbc, 0xd2, 0xf0, 0x4c, 0xef, 0x8c, 0xef, 0x8d, 0xeb, 0xa1, 0x9e, 0xc5, 0xa2, 0xdf, 0x6a, 0xab, 0x57, 0x87, 0x9a, 0x2b, 0x30, 0x39, 0xe4, 0x91, 0xa4, 0x37, 0x41, 0xab, 0x0c, 0x0a, 0x1b, 0x59, 0x04 };      /* OpenSSL */
	struct mc_aes_key k;
	struct mc_aes_ctr c;
	uint8_t chain[16], out[48];

	mc_aes_setkey(&k, 16, key);
	mc_aes_encrypt_block(&k, plain, out);
	if (memcmp(out, ecb128, 16) != 0) {
		return "aes-128 encrypt";
	}
	mc_aes_decrypt_block(&k, ecb128, out);
	if (memcmp(out, plain, 16) != 0) {
		return "aes-128 decrypt";
	}
	mc_aes_setkey(&k, 32, key);
	mc_aes_encrypt_block(&k, plain, out);
	if (memcmp(out, ecb256, 16) != 0) {
		return "aes-256 encrypt";
	}
	mc_aes_decrypt_block(&k, ecb256, out);
	if (memcmp(out, plain, 16) != 0) {
		return "aes-256 decrypt";
	}

	mc_aes_setkey(&k, 16, key);
	memcpy(chain, iv, 16);
	mc_cbc_encrypt((const cccbc_ctx *)&k, (cccbc_iv *)chain, 3, plain, out);
	if (memcmp(out, cbc128, 48) != 0) {
		return "aes-128-cbc encrypt";
	}
	memcpy(chain, iv, 16);
	mc_cbc_decrypt((const cccbc_ctx *)&k, (cccbc_iv *)chain, 3, out, out); /* in place */
	if (memcmp(out, plain, 48) != 0) {
		return "aes-128-cbc decrypt";
	}

	mc_ctr_init(&mc_aes_ctr_crypt, (ccctr_ctx *)&c, 32, key, iv);
	mc_ctr_crypt((ccctr_ctx *)&c, 7, plain, out);          /* uneven pieces */
	mc_ctr_crypt((ccctr_ctx *)&c, 33, plain + 7, out + 7);
	if (memcmp(out, ctr256, 40) != 0) {
		return "aes-256-ctr";
	}

	/*
	 * 80-byte (5 blocks) cross-comparison: exercises the ARMv8 CE hardware
	 * path (nblocks >= 4 for ECB/CBC and nbytes >= 64 for CTR) and verifies
	 * exact bit-for-bit equivalence against the scalar reference.
	 */
	static const uint8_t plain80[80] = {
		0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff,
		0x6b, 0xc1, 0xbe, 0xe2, 0x2e, 0x40, 0x9f, 0x96, 0xe9, 0x3d, 0x7e, 0x11, 0x73, 0x93, 0x17, 0x2a,
		0xae, 0x2d, 0x8a, 0x57, 0x1e, 0x03, 0xac, 0x9c, 0x9e, 0xb7, 0x6f, 0xac, 0x45, 0xaf, 0x8e, 0x51,
		0x30, 0xc8, 0x1c, 0x46, 0xa3, 0x5c, 0xe4, 0x11, 0xe5, 0xfb, 0xc1, 0x19, 0x1a, 0x0a, 0x52, 0xef,
		0xf6, 0x9f, 0x24, 0x45, 0xdf, 0x4f, 0x9b, 0x17, 0xad, 0x2b, 0x41, 0x7b, 0xe6, 0x6c, 0x37, 0x10,
	};
	uint8_t sc_ref[80], hw_out[80], hw_dec[80];

	/* 1. ECB 80-byte cross-comparison (5 blocks >= 4) */
	mc_aes_setkey(&k, 32, key);
	for (int b = 0; b < 5; b++) {
		mc_aes_encrypt_block(&k, plain80 + b * 16, sc_ref + b * 16);
	}
	mc_ecb_encrypt((const ccecb_ctx *)&k, 5, plain80, hw_out);
	if (memcmp(hw_out, sc_ref, 80) != 0) {
		return "aes-256-ecb-80 hardware encrypt";
	}
	mc_ecb_decrypt((const ccecb_ctx *)&k, 5, hw_out, hw_dec);
	if (memcmp(hw_dec, plain80, 80) != 0) {
		return "aes-256-ecb-80 hardware decrypt";
	}

	/* 2. CBC 80-byte cross-comparison (5 blocks >= 4) */
	uint8_t cbc_iv[16];
	memcpy(cbc_iv, iv, 16);
	for (int b = 0; b < 5; b++) {
		for (int j = 0; j < 16; j++) {
			cbc_iv[j] ^= plain80[b * 16 + j];
		}
		mc_aes_encrypt_block(&k, cbc_iv, cbc_iv);
		memcpy(sc_ref + b * 16, cbc_iv, 16);
	}
	memcpy(cbc_iv, iv, 16);
	mc_cbc_encrypt((const cccbc_ctx *)&k, (cccbc_iv *)cbc_iv, 5, plain80, hw_out);
	if (memcmp(hw_out, sc_ref, 80) != 0) {
		return "aes-256-cbc-80 hardware encrypt";
	}
	memcpy(cbc_iv, iv, 16);
	mc_cbc_decrypt((const cccbc_ctx *)&k, (cccbc_iv *)cbc_iv, 5, hw_out, hw_dec);
	if (memcmp(hw_dec, plain80, 80) != 0) {
		return "aes-256-cbc-80 hardware decrypt";
	}

	/* 3. CTR 80-byte cross-comparison (80 bytes >= 64) */
	uint8_t ctr_cnt[16];
	memcpy(ctr_cnt, iv, 16);
	for (int b = 0; b < 5; b++) {
		uint8_t ks[16];
		mc_aes_encrypt_block(&k, ctr_cnt, ks);
		for (int j = 15; j >= 0 && ++ctr_cnt[j] == 0; j--) {
		}
		for (int j = 0; j < 16; j++) {
			sc_ref[b * 16 + j] = (uint8_t)(plain80[b * 16 + j] ^ ks[j]);
		}
	}
	mc_ctr_init(&mc_aes_ctr_crypt, (ccctr_ctx *)&c, 32, key, iv);
	mc_ctr_crypt((ccctr_ctx *)&c, 80, plain80, hw_out);
	if (memcmp(hw_out, sc_ref, 80) != 0) {
		return "aes-256-ctr-80 hardware crypt";
	}
	mc_ctr_init(&mc_aes_ctr_crypt, (ccctr_ctx *)&c, 32, key, iv);
	mc_ctr_crypt((ccctr_ctx *)&c, 80, hw_out, hw_dec);
	if (memcmp(hw_dec, plain80, 80) != 0) {
		return "aes-256-ctr-80 hardware decrypt";
	}

	return NULL;
}

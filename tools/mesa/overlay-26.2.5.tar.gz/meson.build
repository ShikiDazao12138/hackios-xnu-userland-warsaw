# Copyright © 2017-2020 Intel Corporation
# SPDX-License-Identifier: MIT

project(
  'mesa',
  ['c', 'cpp'],
  version : files('VERSION'),
  license : 'MIT',
  meson_version : '>= 1.4.0',
  default_options : [
    'buildtype=debugoptimized',
    'b_ndebug=if-release',
    'c_std=c11',
    'cpp_std=c++17',
    'rust_std=2021',
    'build.rust_std=2021',
  ],
)

project_version = meson.project_version()

if host_machine.system() == 'darwin'
  add_languages('objc', native : false)
  libname_prefix = 'lib'
  libname_suffix = 'dylib'
elif host_machine.system() == 'windows'
  libname_prefix = ''
  libname_suffix = 'dll'
else
  libname_prefix = 'lib'
  libname_suffix = 'so'
endif

cc = meson.get_compiler('c')
cpp = meson.get_compiler('cpp')
fs = import('fs')

sizeof_pointer = cc.sizeof('void*').to_string()

null_dep = dependency('', required : false)

if get_option('layout') != 'mirror'
  error('`mirror` is the only build directory layout supported')
endif

if get_option('b_lto')
  project_version += '-lto'
  # LTO causes random issues that are nearly impossible to debug, so bug reports from LTO builds have been
  # rejected for a long time now.
  # Explicitly reject LTO when building to prevent more people from running into bugs that end up inactionable.
  if not get_option('allow-broken-lto')
     error('Building Mesa with LTO is not supported. Please disable LTO for building Mesa.')
  endif
endif

with_llvm = get_option('llvm')
amd_with_llvm = with_llvm.allowed() and get_option('amd-use-llvm')

with_mesa_debug = get_option('buildtype') == 'debug'

# This means the final value of b_ndebug==true
with_mesa_ndebug = get_option('b_ndebug') == 'true' or (get_option('buildtype') == 'release' and get_option('b_ndebug') == 'if-release')

# We need to set -fmacro-prefix-map properly for driver CL reproducability.
relative_dir = fs.relative_to(meson.project_source_root(), meson.project_build_root())

cl_args = [
  '-fmacro-prefix-map=@0@/='.format(relative_dir),
  '-fmacro-prefix-map=@0@/='.format(meson.project_source_root()),
  '-fmacro-prefix-map=@0@/='.format(meson.project_build_root()),

  # Set the OpenCL standard to CL 2.0, enabling everything at a frontend.
  # Drivers may not actually support everything but that's ok.
  '-cl-std=cl2.0',
  '-D__OPENCL_VERSION__=200',

  # Declare supported clang builtins since we don't autodetect for OpenCL
  '-DHAVE___BUILTIN_FFS',
  '-DHAVE___BUILTIN_CLZ',
]

if with_mesa_ndebug
  cl_args += ['-DNDEBUG']
endif

# Arguments for the preprocessor, put these in a separate array from the C and
# C++ (cpp in meson terminology) arguments since they need to be added to the
# default arguments for both C and C++.
pre_args = [
  '-D__STDC_CONSTANT_MACROS',
  '-D__STDC_FORMAT_MACROS',
  '-D__STDC_LIMIT_MACROS',
  '-DPACKAGE_VERSION="@0@"'.format(project_version),
  '-DPACKAGE_BUGREPORT="https://gitlab.freedesktop.org/mesa/mesa/-/issues"',
]
# Arguments for c or cpp compiler, can be compiler options
c_cpp_args = []

c_args = []
cpp_args = []

with_moltenvk_dir = get_option('moltenvk-dir')
with_vulkan_loader_rpath = get_option('vulkan-loader-rpath')
with_vulkan_icd_dir = get_option('vulkan-icd-dir')
with_tests = get_option('build-tests')
with_glcpp_tests = get_option('enable-glcpp-tests')
with_radv_tests = get_option('build-radv-tests')
with_aco_tests = get_option('build-aco-tests')
with_glx_read_only_text = get_option('glx-read-only-text')
with_glx_direct = get_option('glx-direct')
with_osmesa = get_option('osmesa')
with_vulkan_overlay_layer = get_option('vulkan-layers').contains('overlay')
with_vulkan_device_select_layer = get_option('vulkan-layers').contains('device-select')
with_vulkan_screenshot_layer = get_option('vulkan-layers').contains('screenshot')
with_vulkan_vram_report_limit_layer = get_option('vulkan-layers').contains('vram-report-limit')
with_vulkan_anti_lag_layer = get_option('vulkan-layers').contains('anti-lag')
with_tools = get_option('tools')
if with_tools.contains('all')
  with_tools = [
    'amd',
    'asahi',
    'dlclose-skip',
    'drm-shim',
    'etnaviv',
    'freedreno',
    'glsl',
    'imagination',
    'intel',
    'intel-ui',
    'lima',
    'nir',
    'nouveau',
    'panfrost',
    'gamma',
    'zink',
  ]
endif

with_any_vulkan_layers = get_option('vulkan-layers').length() != 0
with_intel_tools = with_tools.contains('intel') or with_tools.contains('intel-ui')
with_imgui = with_intel_tools or with_vulkan_overlay_layer or with_tools.contains('gamma')

dri_drivers_path = get_option('dri-drivers-path')
if dri_drivers_path == ''
  dri_drivers_path = join_paths(get_option('prefix'), get_option('libdir'), 'dri')
endif

gbm_backends_path = get_option('gbm-backends-path')
if gbm_backends_path == ''
  gbm_backends_path = join_paths(get_option('prefix'), get_option('libdir'), 'gbm')
endif

with_opengl = get_option('opengl')
with_gles1 = get_option('gles1').allowed()
with_gles2 = get_option('gles2').allowed()

pre_args += '-DHAVE_OPENGL=@0@'.format(with_opengl.to_int())
pre_args += '-DHAVE_OPENGL_ES_1=@0@'.format(with_gles1.to_int())
pre_args += '-DHAVE_OPENGL_ES_2=@0@'.format(with_gles2.to_int())

with_any_opengl = with_opengl or with_gles1 or with_gles2

system_has_kms_drm = ['openbsd', 'netbsd', 'freebsd', 'gnu/kfreebsd', 'dragonfly', 'linux', 'sunos', 'android', 'managarm'].contains(host_machine.system())

gallium_drivers = get_option('gallium-drivers')
if gallium_drivers.contains('auto')
  if system_has_kms_drm
    # TODO: Sparc
    # TODO: handle llvm being disabled or auto when setting default_drivers
    if ['x86', 'x86_64'].contains(host_machine.cpu_family())
      gallium_drivers = [
        'r300', 'r600', 'radeonsi', 'nouveau', 'virgl', 'svga', 'llvmpipe', 'softpipe',
        'iris', 'crocus', 'i915', 'zink'
      ]
    elif ['aarch64'].contains(host_machine.cpu_family())
      gallium_drivers = [
        'v3d', 'vc4', 'freedreno', 'etnaviv', 'nouveau', 'svga',
        'tegra', 'virgl', 'lima', 'panfrost', 'llvmpipe', 'softpipe', 'iris',
        'zink', 'asahi'
      ]
    elif ['arm'].contains(host_machine.cpu_family())
      gallium_drivers = [
        'v3d', 'vc4', 'freedreno', 'etnaviv', 'nouveau', 'svga',
        'tegra', 'virgl', 'lima', 'panfrost', 'llvmpipe', 'softpipe', 'iris',
        'zink'
      ]
    elif ['mips', 'mips64', 'ppc', 'ppc64', 'riscv32', 'riscv64'].contains(host_machine.cpu_family())
      gallium_drivers = [
        'r300', 'r600', 'radeonsi', 'nouveau', 'virgl', 'llvmpipe', 'softpipe', 'zink'
      ]
    elif ['loongarch64'].contains(host_machine.cpu_family())
      gallium_drivers = [
        'r300', 'r600', 'radeonsi', 'nouveau', 'virgl', 'etnaviv', 'llvmpipe', 'softpipe', 'zink'
      ]
    else
      error('Unknown architecture @0@. Please pass -Dgallium-drivers to set driver options. Patches gladly accepted to fix this.'.format(
            host_machine.cpu_family()))
    endif
  elif ['windows'].contains(host_machine.system())
    gallium_drivers = ['llvmpipe', 'softpipe', 'zink', 'd3d12']
  elif ['darwin', 'cygwin', 'haiku'].contains(host_machine.system())
    gallium_drivers = ['llvmpipe', 'softpipe']
  else
    error('Unknown OS @0@. Please pass -Dgallium-drivers to set driver options. Patches gladly accepted to fix this.'.format(
          host_machine.system()))
  endif
elif gallium_drivers.contains('all')
   gallium_drivers = [
     'r300', 'r600', 'radeonsi', 'crocus', 'v3d', 'vc4', 'freedreno', 'etnaviv', 'i915',
     'nouveau', 'svga', 'tegra', 'virgl', 'lima', 'panfrost', 'llvmpipe', 'softpipe', 'iris',
     'zink', 'd3d12', 'asahi', 'rocket', 'ethosu'
   ]
endif

with_amdgpu_virtio = get_option('amdgpu-virtio')

with_gallium_radeonsi = gallium_drivers.contains('radeonsi')
with_gallium_r300 = gallium_drivers.contains('r300')
with_gallium_r600 = gallium_drivers.contains('r600')
with_gallium_nouveau = gallium_drivers.contains('nouveau')
with_gallium_freedreno = gallium_drivers.contains('freedreno')
with_gallium_softpipe = gallium_drivers.contains('softpipe')
with_gallium_llvmpipe = gallium_drivers.contains('llvmpipe')
with_gallium_vc4 = gallium_drivers.contains('vc4')
with_gallium_v3d = gallium_drivers.contains('v3d')
with_gallium_panfrost = gallium_drivers.contains('panfrost')
with_gallium_etnaviv = gallium_drivers.contains('etnaviv')
with_gallium_tegra = gallium_drivers.contains('tegra')
with_gallium_crocus = gallium_drivers.contains('crocus')
with_gallium_iris = gallium_drivers.contains('iris')
with_gallium_i915 = gallium_drivers.contains('i915')
with_gallium_svga = gallium_drivers.contains('svga')
with_gallium_virgl = gallium_drivers.contains('virgl')
with_gallium_lima = gallium_drivers.contains('lima')
with_gallium_zink = gallium_drivers.contains('zink')
with_gallium_d3d12 = gallium_drivers.contains('d3d12')
with_gallium_asahi = gallium_drivers.contains('asahi')
with_gallium_rocket = gallium_drivers.contains('rocket')
with_gallium_ethosu = gallium_drivers.contains('ethosu')
foreach gallium_driver : gallium_drivers
  pre_args += '-DHAVE_@0@'.format(gallium_driver.to_upper())
endforeach
draw_with_llvm = with_llvm.allowed() and get_option('draw-use-llvm')
r300_needs_draw = host_machine.cpu_family().startswith('x86')
if with_gallium_r300 and r300_needs_draw and not draw_with_llvm
  warning('r300 built without LLVM will be slow on integrated chipsets requiring software vertex processing.')
endif
with_llvm = with_llvm \
  .enable_if(with_gallium_i915, error_message : 'i915 Gallium driver requires LLVM for vertex shaders') \
  .enable_if(with_gallium_llvmpipe, error_message : 'LLVMPipe Gallium driver requires LLVM') \
  .enable_if(with_gallium_r300 and r300_needs_draw and draw_with_llvm, error_message : 'R300 Gallium driver requires LLVM for vertex shaders on IGP parts') \
  .enable_if(with_gallium_radeonsi and amd_with_llvm, error_message : 'RadeonSI Gallium driver configured to require LLVM')

# compatibility for "swrast" as an internal-ish driver name
with_gallium_swrast = with_gallium_softpipe or with_gallium_llvmpipe
if with_gallium_swrast
  pre_args += '-DHAVE_SWRAST'
endif

with_gallium = gallium_drivers.length() != 0
with_gallium_drm = system_has_kms_drm and [
  with_gallium_asahi,
  with_gallium_etnaviv,
  with_gallium_freedreno,
  with_gallium_lima,
  with_gallium_panfrost,
  with_gallium_v3d,
  with_gallium_vc4,
].contains(true)

_vulkan_drivers = get_option('vulkan-drivers')
if _vulkan_drivers.contains('auto')
  # TODO: handle swrat driver if llvm is auto/disabled
  if system_has_kms_drm
    if host_machine.cpu_family().startswith('x86')
      _vulkan_drivers = ['amd', 'intel', 'intel_hasvk', 'nouveau', 'swrast']
    elif ['aarch64'].contains(host_machine.cpu_family())
      _vulkan_drivers = ['swrast', 'intel', 'panfrost', 'freedreno', 'asahi']
    elif ['arm'].contains(host_machine.cpu_family())
      _vulkan_drivers = ['swrast', 'intel', 'panfrost', 'freedreno']
    elif ['mips', 'mips64', 'ppc', 'ppc64', 'riscv32', 'riscv64'].contains(host_machine.cpu_family())
      _vulkan_drivers = ['amd', 'swrast']
    elif ['loongarch64'].contains(host_machine.cpu_family())
      _vulkan_drivers = ['amd', 'swrast']
    else
      error('Unknown architecture @0@. Please pass -Dvulkan-drivers to set driver options. Patches gladly accepted to fix this.'.format(
            host_machine.cpu_family()))
    endif
  elif ['darwin', 'windows', 'cygwin', 'haiku'].contains(host_machine.system())
    # No vulkan driver supports windows or macOS currently
    _vulkan_drivers = []
  else
    error('Unknown OS @0@. Please pass -Dvulkan-drivers to set driver options. Patches gladly accepted to fix this.'.format(
          host_machine.system()))
  endif
elif _vulkan_drivers.contains('all')
   # Build every vulkan driver regardless of architecture.
   _vulkan_drivers = ['amd', 'intel', 'intel_hasvk', 'swrast',
                      'freedreno', 'panfrost', 'virtio', 'broadcom',
                      'imagination', 'microsoft-experimental',
                      'nouveau', 'asahi', 'gfxstream', 'kosmickrisp']
endif

with_intel_vk = _vulkan_drivers.contains('intel')
with_intel_hasvk = _vulkan_drivers.contains('intel_hasvk')
with_amd_vk = _vulkan_drivers.contains('amd')
with_freedreno_vk = _vulkan_drivers.contains('freedreno')
with_panfrost_vk = _vulkan_drivers.contains('panfrost')
with_swrast_vk = _vulkan_drivers.contains('swrast')
with_virtio_vk = _vulkan_drivers.contains('virtio')
with_broadcom_vk = _vulkan_drivers.contains('broadcom')
with_imagination_vk = _vulkan_drivers.contains('imagination')
with_imagination_srv = get_option('imagination-srv')
with_microsoft_vk = _vulkan_drivers.contains('microsoft-experimental')
with_nouveau_vk = _vulkan_drivers.contains('nouveau')
with_asahi_vk = _vulkan_drivers.contains('asahi')
with_gfxstream_vk = _vulkan_drivers.contains('gfxstream')
with_kosmickrisp_vk = _vulkan_drivers.contains('kosmickrisp')
with_any_vk = _vulkan_drivers.length() != 0

with_llvm = with_llvm \
  .enable_if(with_swrast_vk, error_message : 'Lavapipe Vulkan driver requires LLVM') \
  .enable_if(with_amd_vk and with_aco_tests, error_message : 'RadV ACO tests require LLVM')

with_any_llvmpipe = with_gallium_llvmpipe or with_swrast_vk
with_gallium_or_lvp = with_gallium or with_swrast_vk

freedreno_kmds = get_option('freedreno-kmds')
if freedreno_kmds.length() != 0 and freedreno_kmds != [ 'msm' ] and with_freedreno_vk
  if freedreno_kmds.contains('msm')
      warning('Turnip with the DRM KMD will require libdrm to always be present at runtime which may not always be the case on platforms such as Android.')
  elif with_gallium_drm
      warning('Turnip is forced to link with libdrm when built alongside Gallium DRM drivers which platforms such as Android may not have available at runtime.')
  elif _vulkan_drivers != [ 'freedreno' ]
      warning('Turnip is forced to link with libdrm when built alongside other Vulkan drivers which platforms such as Android may not have available at runtime.')
  else
    # If DRM support isn't needed, we can get rid of it since linking
    # to libdrm can be a potential compatibility hazard.
    system_has_kms_drm = false
  endif
endif

# This has to be below the freedreno_kmds check since that can change system_has_kms_drm
with_gallium_kmsro = with_gallium_drm or (system_has_kms_drm and with_gallium_zink)

pre_args += ['-DMESA_SYSTEM_HAS_KMS_DRM=@0@'.format(system_has_kms_drm.to_int())]
if host_machine.cpu_family() == 'x86' and with_glx_read_only_text
    pre_args += ['-DGLX_X86_READONLY_TEXT']
endif

with_intel_virtio = get_option('intel-virtio-experimental')
if with_intel_virtio
  pre_args += '-DHAVE_INTEL_VIRTIO'
endif

with_vdrm = [
  with_amdgpu_virtio,
  freedreno_kmds.contains('virtio'),
  with_gallium_asahi,
  with_asahi_vk,
  with_intel_virtio,
].contains(true)

with_dri = false
if with_gallium and (system_has_kms_drm or (with_gallium_zink and (freedreno_kmds.contains('kgsl') or host_machine.system() == 'darwin')))
  _glx = get_option('glx')
  _egl = get_option('egl')
  if _glx == 'dri' or _egl.enabled() or (_glx == 'disabled' and _egl.allowed())
    with_dri = true
  endif
endif

with_any_broadcom = [
  with_gallium_vc4,
  with_gallium_v3d,
  with_broadcom_vk,
].contains(true)

with_intel_vk_rt = get_option('intel-rt') \
   .disable_auto_if(not with_intel_vk) \
   .disable_if(sizeof_pointer != '8', \
               error_message: 'Intel Ray Tracing requires 64-bit architectures') \
  .allowed()

with_any_intel = [
  with_gallium_crocus,
  with_gallium_i915,
  with_gallium_iris,
  with_intel_hasvk,
  with_intel_tools,
  with_intel_vk,
].contains(true)
with_any_nouveau = with_gallium_nouveau or with_nouveau_vk

# needed in the loader
if with_nouveau_vk
  pre_args += '-DHAVE_NVK'
endif

if with_gallium_tegra and not with_gallium_nouveau
  error('tegra driver requires nouveau driver')
endif
if with_aco_tests and not with_amd_vk
  error('ACO tests require Radv')
endif
if with_aco_tests and not with_tools.contains('drm-shim')
  error('ACO tests require AMDGPU drm-shim')
endif
if with_radv_tests and not with_amd_vk
  error('RADV tests require RADV')
endif
if with_radv_tests and not with_tools.contains('drm-shim')
  error('RADV tests require AMDGPU drm-shim')
endif

with_microsoft_clc = get_option('microsoft-clc').enabled()
with_spirv_to_dxil = get_option('spirv-to-dxil')

if host_machine.system() == 'darwin'
  with_dri_platform = 'apple'
  pre_args += '-DBUILDING_MESA'
elif ['windows', 'cygwin'].contains(host_machine.system())
  with_dri_platform = 'windows'
elif system_has_kms_drm
  with_dri_platform = 'drm'
elif host_machine.system() == 'gnu' or (freedreno_kmds.contains('kgsl') and with_gallium_zink)
  with_dri_platform = 'pseudo-drm'
else
  # FIXME: haiku doesn't use dri, and xlib doesn't use dri, probably should
  # assert here that one of those cases has been met.
  # FIXME: illumos ends up here as well
  with_dri_platform = 'none'
endif

with_vulkan_beta = get_option('vulkan-beta')
if host_machine.system() == 'darwin'
  #macOS seems to need beta extensions to build for now:
  with_vulkan_beta = true
endif
if with_vulkan_beta
  pre_args += '-DVK_ENABLE_BETA_EXTENSIONS'
endif

_codecs = get_option('video-codecs')
patent_codecs = ['vc1dec', 'h264dec', 'h264enc', 'h265dec', 'h265enc']
free_codecs = ['av1dec', 'av1enc', 'vp9dec', 'mpeg12dec', 'jpegdec']
all_codecs = patent_codecs + free_codecs

if _codecs.contains('all')
  _codecs = all_codecs
elif _codecs.contains('all_free')
  _codecs += free_codecs
endif

with_video_encode = false
foreach c : _codecs
  if c.contains('enc')
    with_video_encode = true
    break
  endif
endforeach

foreach c : all_codecs
   pre_args += '-DVIDEO_CODEC_@0@=@1@'.format(c.to_upper(), _codecs.contains(c).to_int())
endforeach

_platforms = get_option('platforms')
if _platforms.contains('auto')
  if system_has_kms_drm
    _platforms = ['x11', 'wayland']
  elif host_machine.system() == 'cygwin'
    _platforms = ['x11']
  elif host_machine.system() == 'haiku'
    _platforms = ['haiku']
  elif host_machine.system() == 'windows'
    _platforms = ['windows']
  elif host_machine.system() == 'darwin'
    _platforms = ['x11', 'macos']
  else
    error('Unknown OS @0@. Please pass -Dplatforms to set platforms. Patches gladly accepted to fix this.'.format(
          host_machine.system()))
  endif
endif

with_platform_android = _platforms.contains('android')
with_platform_x11 = _platforms.contains('x11')
with_platform_wayland = _platforms.contains('wayland')
with_platform_haiku = _platforms.contains('haiku')
with_platform_windows = _platforms.contains('windows')
with_platform_macos = _platforms.contains('macos')

with_gfxstream_emulated_android = with_gfxstream_vk and with_platform_android and host_machine.system() == 'linux'
if with_gfxstream_emulated_android
  # When building the android_stub with a non-Bionic sysroot/target, we to have
  # define macros that are typically in <sys/cdefs.h> when using a Bionic
  # sysroot
  pre_args += '-D__INTRODUCED_IN(api_level)='

  # We don't want to build Vulkan common code when running the emulated
  # gfxstream Android platform.  This causes issues when building in
  # tandem with host Lavapipe.
  #
  # TODO(gfxstream-devs@): Modifying the user-provided platform can be removed
  # when Cuttlefish moves it's host library builds off Soong, and on to Github.
  # For now, add basic sanity checks before modifying user arguments.
  if _platforms.contains('android') and _platforms.length() != 1
    error('You cannot enable platform "android" at the same time as another platform')
  endif
  _platforms = []
  with_platform_android = false
endif

with_glx = get_option('glx')
if with_glx == 'auto'
  if not with_opengl
    with_glx = 'disabled'
  elif with_platform_android
    with_glx = 'disabled'
  elif with_dri
    with_glx = 'dri'
  elif with_platform_haiku
    with_glx = 'disabled'
  elif host_machine.system() == 'windows'
    with_glx = 'disabled'
  elif with_gallium
    # Even when building just gallium drivers the user probably wants dri
    with_glx = 'dri'
  elif with_platform_x11 and with_any_opengl and not with_any_vk
    # The automatic behavior should not be to turn on xlib based glx when
    # building only vulkan drivers
    with_glx = 'xlib'
  else
    with_glx = 'disabled'
  endif
endif
if with_glx == 'dri'
   if with_gallium
      with_dri = true
   endif
endif

if not with_opengl and with_glx != 'disabled'
  error('Building GLX without OpenGL is not supported.')
endif

if not (with_dri or with_gallium or with_glx != 'disabled')
  with_gles1 = false
  with_gles2 = false
  with_opengl = false
  with_any_opengl = false
endif

with_gbm = get_option('gbm') \
  .require(system_has_kms_drm, error_message : 'GBM only supports DRM/KMS platforms') \
  .disable_auto_if(not with_dri) \
  .allowed()

with_xlib_lease = get_option('xlib-lease') \
  .require(with_platform_x11 and (system_has_kms_drm or with_dri_platform == 'apple' or with_dri_platform == 'pseudo-drm'), error_message : 'xlib-lease requires X11 and KMS/DRM support') \
  .allowed()

with_egl = get_option('egl') \
  .require(with_platform_windows or with_platform_haiku or with_dri or with_platform_android, error_message : 'EGL requires DRI, Haiku, Windows or Android') \
  .require(with_glx != 'xlib', error_message :'EGL requires DRI, but GLX is being built with xlib support') \
  .disable_auto_if(with_platform_haiku) \
  .allowed()

if with_gbm
  pre_args += '-DHAVE_LIBGBM'
endif

if with_egl
  _platforms += 'surfaceless'
  if with_gbm and not with_platform_android
    _platforms += 'drm'
  endif

  # All the other platforms can be detected and cannot reach the native platform code
  _undetectable_platforms = ['x11', 'haiku', 'android', 'surfaceless']

  # Don't enforce the native platform if none of the undetectable platforms are enabled
  _undetectable_platforms_enabled = []
  foreach _platform : _platforms
    if _platform in _undetectable_platforms
      _undetectable_platforms_enabled += _platform
    endif
  endforeach

  egl_native_platform = ''

  if _undetectable_platforms_enabled.length() > 0
    egl_native_platform = get_option('egl-native-platform')

    if egl_native_platform.contains('auto')
      egl_native_platform = _undetectable_platforms_enabled[0]

    # Since we always add surfaceless without the user's ability to
    # enable/disable it, if this is the only undetectable platform enabled,
    # silently select it as the native platform.
    elif _undetectable_platforms_enabled == ['surfaceless']
      _undetectable_platforms_enabled = []
      egl_native_platform = 'surfaceless'

    # Make sure the native platform is one of the ones that can't be detected
    elif egl_native_platform not in _undetectable_platforms
      error('`-D egl-native-platform=...` must be one of: ' + ', '.join(_undetectable_platforms_enabled))
    endif
  endif
endif

if 'x11' in _platforms
  _platforms += 'xcb'
endif

foreach platform : _platforms
  pre_args += '-DHAVE_@0@_PLATFORM'.format(platform.to_upper())
endforeach

if with_platform_android and get_option('platform-sdk-version') >= 29
  # By default the NDK compiler, at least, emits emutls references instead of
  # ELF TLS, even when building targeting newer API levels.  Make it actually do
  # ELF TLS instead.
  c_cpp_args += '-fno-emulated-tls'
  add_project_link_arguments('-Wl,-plugin-opt=-emulated-tls=0', language: ['c', 'cpp'])
endif

# -mtls-dialect=gnu2 speeds up non-initial-exec TLS significantly but requires
# full toolchain (including libc) support.
have_mtls_dialect = false
foreach c_arg : get_option('c_args')
  if c_arg.startswith('-mtls-dialect=')
    have_mtls_dialect = true
    break
  endif
endforeach
if not have_mtls_dialect
  # need .run to check libc support. meson aborts when calling .run when
  # cross-compiling, but because this is just an optimization we can skip it
  if meson.is_cross_build() and not meson.can_run_host_binaries()
    warning('cannot auto-detect -mtls-dialect when cross-compiling, using compiler default')
  elif host_machine.system() == 'freebsd'
    warning('cannot use -mtls-dialect for FreeBSD, using compiler default')
  else
    # The way to specify the TLSDESC dialect is architecture-specific.
    # We probe both because there is not a fallback guaranteed to work for all
    # future architectures.
    foreach tlsdesc_arg : ['-mtls-dialect=gnu2', '-mtls-dialect=desc']
      # -fpic to force dynamic tls, otherwise TLS relaxation defeats check
      tlsdesc_test = cc.run('int __thread x; int main() { return x; }',
                            args: [tlsdesc_arg, '-fpic'],
                            name: tlsdesc_arg)
      if tlsdesc_test.returncode() == 0 and (
            # check for lld 13 bug: https://gitlab.freedesktop.org/mesa/mesa/-/issues/5665
            host_machine.cpu_family() != 'x86_64' or
            # get_linker_id misses LDFLAGS=-fuse-ld=lld: https://github.com/mesonbuild/meson/issues/6377
            #cc.get_linker_id() != 'ld.lld' or
            cc.links('''int __thread x; int y; int main() { __asm__(
                  "leaq x@TLSDESC(%rip), %rax\n"
                  "movq y@GOTPCREL(%rip), %rdx\n"
                  "call *x@TLSCALL(%rax)\n"); }''', name: 'split TLSDESC')
            )
        c_cpp_args += tlsdesc_arg
        break
      endif
    endforeach
  endif
endif

if with_glx != 'disabled'
  if not (with_platform_x11 and with_any_opengl)
    error('Cannot build GLX support without X11 platform support and at least one OpenGL API')
  elif with_glx == 'xlib'
    if not with_gallium
      error('xlib based GLX requires at least one gallium driver')
    elif not with_gallium_swrast
      error('xlib based GLX requires softpipe or llvmpipe.')
    elif with_dri
      error('xlib conflicts with any dri driver')
    endif
  endif
endif

_glvnd = get_option('glvnd') \
  .require(not with_platform_windows,
           error_message: 'glvnd cannot be used on Windows') \
  .require(with_glx != 'xlib',
           error_message: 'Cannot build glvnd support for GLX that is not DRI based.') \
  .require(with_glx != 'disabled' or with_egl,
           error_message: 'glvnd requires DRI based GLX and/or EGL') \
  .require(get_option('egl-lib-suffix') == '',
           error_message: '''EGL lib suffix can't be used with libglvnd''')
dep_glvnd = dependency('libglvnd', version : '>= 1.3.2', required : _glvnd)
with_glvnd = dep_glvnd.found()
pre_args += '-DUSE_LIBGLVND=@0@'.format(with_glvnd.to_int())
glvnd_vendor_name = get_option('glvnd-vendor-name')

if with_vulkan_icd_dir == ''
  with_vulkan_icd_dir = join_paths(get_option('datadir'), 'vulkan/icd.d')
endif

with_dri2 = (with_dri or with_any_vk) and (with_dri_platform == 'drm' or with_dri_platform == 'apple' or  with_dri_platform == 'pseudo-drm')

if with_dri
  if with_glx == 'disabled' and not with_egl and not with_gbm
    error('building dri drivers require at least one windowing system')
  endif
endif

dep_dxheaders = null_dep
if with_gallium_d3d12 or with_microsoft_clc or with_microsoft_vk or (with_any_vk and host_machine.system() == 'windows')
  dep_dxheaders = dependency('directx-headers', required : false)
  if not dep_dxheaders.found()
    dep_dxheaders = dependency('DirectX-Headers',
      version : '>= 1.619.1',
      fallback : ['DirectX-Headers', 'dep_dxheaders'],
      required : with_gallium_d3d12 or with_microsoft_vk
    )
  endif
endif

if dep_dxheaders.found()
  if (dep_dxheaders.version().version_compare('>= 1.700.0'))
    pre_args += '-DUSE_D3D12_PREVIEW_HEADERS=1'
  else
    pre_args += '-DUSE_D3D12_PREVIEW_HEADERS=0'
  endif
endif

_with_gallium_d3d12_video = get_option('gallium-d3d12-video')
with_gallium_d3d12_video = false
if with_gallium_d3d12 and not _with_gallium_d3d12_video.disabled()
  with_gallium_d3d12_video = true
  pre_args += '-DHAVE_GALLIUM_D3D12_VIDEO'
endif

with_bvh = with_amd_vk or with_intel_vk or with_swrast_vk or with_freedreno_vk
_glslang_preamble_version = '12.2'

# GLSL has interesting version output and Meson doesn't parse it correctly as of
# Meson 1.4.0
prog_glslang = find_program(
  'glslangValidator',
  native : true,
  required : with_vulkan_overlay_layer or with_aco_tests or with_bvh
)

if prog_glslang.found()
  _glslang_version = run_command(prog_glslang, ['--version'], check : false).stdout().split(':')[2]
  # Check if glslang has depfile support. Support was added in 11.3.0, but
  # Windows path support was broken until 11.9.0.
  #
  # It is intentional to check the build machine, since we need to ensure that
  # glslang will output valid paths on the build platform
  _glslang_check = build_machine.system() == 'windows' ? '>= 11.9.0' : '>= 11.3.0'
  if _glslang_version.version_compare(_glslang_check)
    glslang_depfile = ['--depfile', '@DEPFILE@']
  else
    glslang_depfile = []
  endif
  if with_bvh and _glslang_version.version_compare('< ' + _glslang_preamble_version)
    error('glslang >= ' + _glslang_preamble_version + ' is required.')
  endif
  if run_command(prog_glslang, [ '--quiet', '--version' ], check : false).returncode() == 0
    glslang_quiet = ['--quiet']
  else
    glslang_quiet = []
  endif
endif

_va_drivers = [
  with_gallium_d3d12_video,
  with_gallium_nouveau,
  with_gallium_r600,
  with_gallium_radeonsi,
  with_gallium_virgl,
]

allow_fallback_for_libva = get_option('allow-fallback-for').contains('libva')
_va = get_option('gallium-va') \
  .require(_va_drivers.contains(true),
           error_message : 'VA state tracker requires at least one of the following gallium drivers: r600, radeonsi, nouveau, d3d12 (with option gallium-d3d12-video), virgl.')
_dep_va_name = host_machine.system() == 'windows' ? 'libva-win32' : 'libva'
dep_va = dependency(
  _dep_va_name, version : '>= 1.8.0',
  required : _va,
  allow_fallback : allow_fallback_for_libva,
  default_options : [ 'c_std=none' ]
)
if dep_va.found()
  dep_va_headers = dep_va.partial_dependency(compile_args : true, includes : true)
  if cc.has_header_symbol('va/va.h', 'VASurfaceAttribDRMFormatModifiers',
                          dependencies: dep_va_headers)
    pre_args += '-DHAVE_VA_SURFACE_ATTRIB_DRM_FORMAT_MODIFIERS'
  endif
  libva_version = cc.get_define('VA_VERSION', prefix: '#include "va/va_version.h"',
                                dependencies: dep_va_headers).split('.')
endif
with_gallium_va = dep_va.found()

va_drivers_path = get_option('va-libs-path')
if va_drivers_path == ''
  va_drivers_path = join_paths(get_option('libdir'), 'dri')
endif

_mediafoundation_drivers = [
  with_gallium_d3d12_video,
]

with_gallium_mediafoundation = get_option('gallium-mediafoundation') \
  .require(host_machine.system() == 'windows', error_message : 'mediafoundation only supported on Windows') \
  .require(_mediafoundation_drivers.contains(true),
           error_message : 'Media foundation state tracker requires at least one of the following gallium drivers: d3d12 (with option gallium-d3d12-video).') \
  .enabled()

with_gallium_mediafoundation_test = get_option('gallium-mediafoundation-test')
if with_gallium_mediafoundation_test
  if not with_gallium_mediafoundation
    error('The mediafoundation test requires mediafoundation.')
  endif
endif

d3d_drivers_path = get_option('d3d-drivers-path')
if d3d_drivers_path == ''
  d3d_drivers_path = join_paths(get_option('prefix'), get_option('libdir'), 'd3d')
endif

with_gallium_st_d3d10umd =  get_option('gallium-d3d10umd')
if with_gallium_st_d3d10umd
  if not with_gallium_swrast
    error('The d3d10umd state tracker requires gallium softpipe/llvmpipe.')
  endif
endif

if host_machine.cpu_family() == 'ppc64' and host_machine.endian() == 'little'
  if cc.compiles('''
      #include <altivec.h>
      int main() {
        vector unsigned char r;
        vector unsigned int v = vec_splat_u32 (1);
        r = __builtin_vec_vgbbd ((vector unsigned char) v);
        return 0;
      }''',
      name : 'POWER8 intrinsics')
    pre_args += ['-D_ARCH_PWR8']
  endif
endif

if get_option('vmware-mks-stats')
  if not with_gallium_svga
    error('vmware-mks-stats requires gallium VMware/svga driver.')
  endif
  pre_args += '-DVMX86_STATS=1'
endif

_rtti = get_option('cpp_rtti')

with_panfrost_rust = (with_gallium_panfrost or with_panfrost_vk) and get_option('panfrost-rust')

with_gallium_rusticl = get_option('gallium-rusticl')
if with_gallium_rusticl
  if not with_gallium
    error('rusticl requires at least one gallium driver.')
  endif
endif

with_virtgpu_kumquat = get_option('virtgpu_kumquat') and with_gfxstream_vk
if with_gallium_rusticl or with_nouveau_vk or with_tools.contains('etnaviv') or with_virtgpu_kumquat or with_panfrost_rust
  # rust.bindgen() does not pass `--rust-target` to bindgen until 1.7.0.
  if meson.version().version_compare('< 1.7.0')
    error('Mesa Rust support requires Meson 1.7.0 or newer')
  endif

  add_languages('rust', required: true)
  rustc = meson.get_compiler('rust')
  rust = import('rust')

  # Keep this in sync with the `msrv` in clippy.toml
  if rustc.version().version_compare('< 1.85')
    error('Mesa requires Rust 1.85.0 or newer')
  endif

  # bindgen 0.71 is the first version that knows about `editions`
  bindgen_version = find_program('bindgen').version()
  bindgen_bad_versions = [
    # unknown covers buggy 0.69.0, 0.71.0
    'unknown',
    '0.72.0',
  ]
  if bindgen_version in bindgen_bad_versions
    error('Your bingden version is known to be buggy, please upgrade it. ' +
          'If your distribution does not ship a more recent version, ' +
          'you can install the latest version for your user with `cargo install bindgen-cli`.')
  elif bindgen_version.version_compare('< 0.71.1')
    error('Mesa requires bindgen 0.71.1 or newer. ' +
          'If your distribution does not ship a recent enough version, ' +
          'you can install the latest version for your user with `cargo install bindgen-cli`.')
  endif

  bindgen_output_args = [
    # This is needed to generate 2024-safe code
    '--wrap-unsafe-ops',
    # can't do anything about it anyway
    '--raw-line', '#![allow(clippy::all)]',
    '--raw-line', '#![allow(improper_ctypes)]',
    # Some bindgen versions assume `unsafe_op_in_unsafe_fn`
    '--raw-line', '#![allow(unused_unsafe)]',
    '--raw-line', '#![allow(non_camel_case_types)]',
    '--raw-line', '#![allow(non_snake_case)]',
    '--raw-line', '#![allow(non_upper_case_globals)]',
    # This is fixed in 0.72 but we don't have that in CI yet
    '--raw-line', '#![allow(unsafe_op_in_unsafe_fn)]',
  ]
  if rustc.version().version_compare('>= 1.88')
    bindgen_output_args += ['--raw-line', '#![allow(unnecessary_transmutes)]']
  endif

  rust_global_args = [
    # We want to be able to write `else { if {} }` when it makes more sense than
    # collapsing it into `else if {}`.
    '-Aclippy::collapsible_else_if',

    # "Needless lifetimes" might be needless but they're harmless and we
    # prefer being explicit, so allow them.
    '-Aclippy::needless_lifetimes',

    # Being explicit has value, allow it.
    '-Aclippy::question_mark',
  ]

  rust_2024_lint_args = [
    '-Dboxed_slice_into_iter',
    '-Ddeprecated_safe_2024',
    '-Dimpl_trait_overcaptures',
    '-Dkeyword_idents_2024',
    '-Dmissing_unsafe_on_extern',
    '-Dnever_type_fallback_flowing_into_unsafe',
    '-Drust_2024_guarded_string_incompatible_syntax',
    '-Drust_2024_incompatible_pat',
    '-Drust_2024_prelude_collisions',
    '-Dstatic_mut_refs',
    '-Dunsafe_op_in_unsafe_fn',

    # This requires cbindgen >= 0.28
    # '-Dunsafe_attr_outside_unsafe',

    # 1.83+
    # '-Dif_let_rescope',
  ]
endif

if get_option('precomp-compiler') != 'system'
  with_drivers_clc = get_option('precomp-compiler') == 'enabled'
else
  with_drivers_clc = false
endif

with_driver_using_cl = [
  with_gallium_iris, with_gallium_crocus, with_intel_vk, with_intel_hasvk,
  with_gallium_asahi, with_asahi_vk, with_tools.contains('asahi'),
  with_gallium_panfrost, with_panfrost_vk,
  with_gallium_rusticl,
  with_nouveau_vk, with_imagination_vk,
  with_kosmickrisp_vk,
].contains(true)

if get_option('mesa-clc') == 'system'
  prog_mesa_clc = find_program('mesa_clc', native : true)
  prog_vtn_bindgen2 = find_program('vtn_bindgen2', native : true)
  # Even with mesa-clc already built, rusticl still needs clc.
  with_clc = with_gallium_rusticl
else
  with_clc = get_option('mesa-clc') != 'auto' or \
             with_microsoft_clc or \
             with_drivers_clc or with_driver_using_cl
endif

with_llvm = with_llvm \
  .enable_if(with_clc, error_message : 'CLC requires LLVM')

with_poly = [
  with_gallium_asahi, with_asahi_vk, with_tools.contains('asahi'),
  with_kosmickrisp_vk,
].contains(true)

dep_clc = null_dep
if with_gallium_rusticl or with_microsoft_clc
  dep_clc = dependency('mesa-libclc', required : false,
    not_found_message :
    'mesa-libclc not found. Build will fall back to upstream libclc, however ' +
    'this is not recommended for most use cases.')
  if not dep_clc.found()
    dep_clc = dependency('libclc')
  endif
endif

with_gfx_compute = [
  with_any_opengl,
  with_any_vk,
  with_clc,
  with_gallium_va and with_video_encode,
  with_gallium_mediafoundation and with_video_encode,
].contains(true)
if with_gfx_compute
  pre_args += '-DHAVE_GFX_COMPUTE'
endif

gl_pkgconfig_c_flags = []
with_glx_indirect_rendering = false
if with_platform_x11
  if with_glx == 'xlib'
    pre_args += '-DUSE_XSHM'
  else
    with_glx_indirect_rendering = true
    pre_args += '-DGLX_INDIRECT_RENDERING'
    if with_glx_direct
      pre_args += '-DGLX_DIRECT_RENDERING'
    endif
    if with_dri_platform == 'drm'
      pre_args += '-DGLX_USE_DRM'
    elif with_dri_platform == 'apple'
      pre_args += '-DGLX_USE_APPLEGL'
    elif with_dri_platform == 'windows'
      pre_args += '-DGLX_USE_WINDOWSGL'
    endif
  endif
endif

with_glapi_export_proto_entry_points = false
if not with_glx_indirect_rendering
  # Imply !defined(GLX_INDIRECT_RENDERING)
  with_glapi_export_proto_entry_points = true
endif
pre_args += '-DGLAPI_EXPORT_PROTO_ENTRY_POINTS=@0@'.format(with_glapi_export_proto_entry_points.to_int())

with_android_stub = get_option('android-stub')
need_android_stub = with_platform_android or with_gfxstream_emulated_android
if with_android_stub and not need_android_stub
  error('`-D android-stub=true` makes no sense without `-D platforms=android` or emulated Android')
endif

with_libbacktrace = get_option('android-libbacktrace') \
  .require(with_platform_android, error_message : '`-D android-libbacktrace=enabled` makes no sense without `-D platforms=android`') \
  .disable_auto_if(not with_platform_android) \
  .allowed()

if with_platform_android
  dep_android_ui = null_dep
  dep_android_mapper4 = null_dep
  if not with_android_stub
    dep_android = [
      dependency('cutils'),
      dependency('hardware'),
      dependency('log'),
      dependency('sync'),
    ]
    if with_libbacktrace and get_option('platform-sdk-version') < 34
      cpp_args += '-DWITH_LIBBACKTRACE'
      dep_android += dependency('backtrace')
    endif
    if get_option('platform-sdk-version') >= 26
      dep_android += dependency('nativewindow')
    endif
    if get_option('platform-sdk-version') >= 30
      dep_android_mapper4 = dependency('android.hardware.graphics.mapper', version : '>= 4.0', required : false)
    endif
    if get_option('platform-sdk-version') >= 35
      dep_android_ui = dependency('ui', required : false)
    endif
    dep_hwvulkan_headers = dependency('android-hwvulkan-headers', required : false)
    if dep_hwvulkan_headers.found() and with_any_vk
      dep_android += dep_hwvulkan_headers
    endif
  endif
  pre_args += '-DANDROID_API_LEVEL=' + get_option('platform-sdk-version').to_string()
  if get_option('android-strict')
    pre_args += '-DANDROID_STRICT'
  endif
endif

# On Android, seccomp kills the process on kernels without
# CONFIG_KCMP/CONFIG_CHECKPOINT_RESTORE if it attemps to use KCMP.
# Since we can't detect that, err on the side of caution and disable
# KCMP by default on Android.
if get_option('allow-kcmp') \
    .disable_auto_if(with_platform_android) \
    .allowed()
  pre_args += '-DALLOW_KCMP'
endif

# Find a python executable that meets our version requirement.
# - On Windows, a venv has no versioned aliased to 'python'.
# - On RHEL 9, python3 is 3.9, so we must use python3.12.
python_version_req = '>= 3.10'
python_exec_list = ['python3.16', 'python3.15', 'python3.14', 'python3.13',
                    'python3.12', 'python3.11', 'python3.10', 'python3', 'python']

foreach p : python_exec_list
  prog_python = find_program(p, required : false, version : python_version_req)
  if not prog_python.found()
    continue
  endif

  has_mako = run_command(
    prog_python, '-c',
    '''
import sys

try:
    try:
        from packaging.version import Version
    except:
        from distutils.version import StrictVersion as Version
except:
    sys.exit(2)

try:
    import mako
except:
    sys.exit(1)

if Version(mako.__version__) < Version("0.8.0"):
    sys.exit(1)
''', check: false)
  if has_mako.returncode() != 0
    continue
  endif

  has_yaml = run_command(prog_python, '-c', 'import yaml', check: false)
  if has_yaml.returncode() != 0
    continue
  endif

  break
endforeach

if not prog_python.found()
  error('Python ' + python_version_req + ' not found')
endif

if has_mako.returncode() == 1
  error('Python (3.x) mako module >= 0.8.0 required to build mesa.')
elif has_mako.returncode() == 2
  error('One of Python (3.x) packaging or distutils module is required.')
endif

if has_yaml.returncode() != 0
  error('Python (3.x) yaml module (PyYAML) required to build mesa.')
endif

if cc.get_id() == 'gcc' and cc.version().version_compare('< 4.4.6')
  error('When using GCC, version 4.4.6 or later is required.')
endif

# Support systems without ETIME (e.g. FreeBSD)
if cc.get_define('ETIME', prefix : '#include <errno.h>') == ''
  pre_args += '-DETIME=ETIMEDOUT'
endif

# Define MESA_DEBUG to 1 for debug builds only (debugoptimized is not included on this one);
# otherwise define MESA_DEBUG to 0
pre_args += '-DMESA_DEBUG=@0@'.format(with_mesa_debug.to_int())

with_split_debug = get_option('split-debug') \
  .disable_if(not cc.has_argument('-gsplit-dwarf'),
    error_message : 'split-debug requires compiler -gsplit-dwarf support') \
  .disable_if(not cc.has_link_argument('-Wl,--gdb-index'),
    error_message : 'split-debug requires the linker argument -Wl,--gdb-index')

if with_split_debug.allowed() and get_option('debug')
  add_project_arguments('-gsplit-dwarf', language : ['c', 'cpp'])
  add_project_link_arguments('-Wl,--gdb-index', language : ['c', 'cpp'])
endif

with_shader_cache = get_option('shader-cache') \
  .require(host_machine.system() != 'windows', error_message : 'Shader Cache does not currently work on Windows') \
  .allowed()

if with_shader_cache
  pre_args += '-DENABLE_SHADER_CACHE'
  if not get_option('shader-cache-default')
    pre_args += '-DSHADER_CACHE_DISABLE_BY_DEFAULT'
  endif

  shader_cache_max_size = get_option('shader-cache-max-size')
  if shader_cache_max_size != ''
    pre_args += '-DMESA_SHADER_CACHE_MAX_SIZE="@0@"'.format(shader_cache_max_size)
  endif
endif

# Check for GCC style builtins
foreach b : ['bswap32', 'bswap64', 'clz', 'clzll', 'ctz', 'expect', 'ffs',
             'ffsll', 'popcount', 'popcountll', 'unreachable', 'types_compatible_p']
  if cc.has_function(b)
    pre_args += '-DHAVE___BUILTIN_@0@'.format(b.to_upper())
  endif
endforeach

# Check for GCC overflow intrinsics
foreach b : ['add_overflow', 'add_overflow_p', 'sub_overflow_p']
  if cc.has_function('__builtin_' + b)
    pre_args += '-DHAVE___BUILTIN_@0@'.format(b.to_upper())
  endif
endforeach

# Check for ARM FP state builtins
foreach b : ['arm_get_fpscr', 'arm_set_fpscr', 'aarch64_get_fpcr', 'aarch64_set_fpcr']
  if cc.has_function('__builtin_' + b)
    pre_args += '-DHAVE___BUILTIN_@0@'.format(b.to_upper())
  endif
endforeach

# check for GCC __attribute__
_attributes = [
  'const', 'flatten', 'malloc', 'pure', 'unused', 'warn_unused_result',
  'weak', 'format', 'packed', 'returns_nonnull', 'alias', 'noreturn',
  'optimize', 'cold',
]
foreach a : cc.get_supported_function_attributes(_attributes)
  pre_args += '-DHAVE_FUNC_ATTRIBUTE_@0@'.format(a.to_upper())
endforeach
if cc.has_function_attribute('visibility:hidden')
  pre_args += '-DHAVE_FUNC_ATTRIBUTE_VISIBILITY'
endif

_no_sanitize_flags = []
if get_option('b_sanitize').split(',').contains('address')
  _no_sanitize_flags += ['address']
endif
if get_option('b_sanitize').split(',').contains('undefined')
  _no_sanitize_flags += ['vptr']
endif
foreach flag: _no_sanitize_flags
  if cc.compiles('__attribute__((no_sanitize("@0@"))) int foo(void) { return 0; }'.format(flag),
                 name : 'no_sanitize(@0@)'.format(flag),
                 werror: true)
    pre_args += '-DHAVE_FUNC_ATTRIBUTE_NO_SANITIZE_@0@'.format(flag.to_upper())
  endif
endforeach

if cc.compiles('__uint128_t foo(void) { return 0; }',
               name : '__uint128_t')
  pre_args += '-DHAVE_UINT128'
endif

if cc.has_function('reallocarray')
   pre_args += '-DHAVE_REALLOCARRAY'
endif
if cc.has_function('fmemopen')
   pre_args += '-DHAVE_FMEMOPEN'
endif

# TODO: this is very incomplete
if ['linux', 'cygwin', 'gnu', 'freebsd', 'gnu/kfreebsd', 'haiku', 'android', 'managarm'].contains(host_machine.system())
  pre_args += '-D_GNU_SOURCE'
elif host_machine.system() == 'sunos'
  pre_args += '-D__EXTENSIONS__'
elif host_machine.system() == 'windows'
  pre_args += [
    '-D_WIN32_WINNT=0x0A00',
    '-DWINVER=0x0A00',
  ]
  if cc.get_argument_syntax() == 'msvc'
    pre_args += [
      '-D_USE_MATH_DEFINES',
      '-D_CRT_NONSTDC_NO_DEPRECATE',
      '-D_CRT_SECURE_NO_WARNINGS',
      '-D_CRT_SECURE_NO_DEPRECATE',
      '-D_SCL_SECURE_NO_WARNINGS',
      '-D_SCL_SECURE_NO_DEPRECATE',
      '-D_ALLOW_KEYWORD_MACROS',
      '-D_HAS_EXCEPTIONS=0', # Tell C++ STL to not use exceptions
      '-DNOMINMAX',
      '-D_UCRT_NOISY_NAN', # https://developercommunity.visualstudio.com/t/NAN-is-no-longer-compile-time-constant-i/10688907?viewtype=all
    ]
  else
    # MINGW also accept _GNU_SOURCE
    pre_args += '-D_GNU_SOURCE'

    # When the target is not (mingw with ucrt)
    # NOTE: clang's stddef.h are conflict with mingw or ucrt's stddef.h
    # So do not include headers that defined in clang for detecting
    # _UCRT
    if cc.compiles('''
      #include <string.h>
      #if defined(__MINGW32__) && defined(_UCRT)
      #error
      #endif
      int main(void) { return 0; }''')
      pre_args += ['-D__MSVCRT_VERSION__=0x0700']
    endif
  endif
elif host_machine.system() == 'openbsd'
  pre_args += '-D_ISOC11_SOURCE'
endif

# Check for generic C arguments
c_msvc_compat_args = []
no_override_init_args = []
cpp_msvc_compat_args = []
soong_compat_c_args = []
soong_compat_cpp_args = []
ld_args_gc_sections = []
if cc.get_argument_syntax() == 'msvc'
  _trial = [
    '/wd4018',  # signed/unsigned mismatch
    '/wd4056',  # overflow in floating-point constant arithmetic
    '/wd4244',  # conversion from 'type1' to 'type2', possible loss of data
    '/wd4267',  # 'var' : conversion from 'size_t' to 'type', possible loss of data
    '/wd4305',  # truncation from 'type1' to 'type2'
    '/wd4351',  # new behavior: elements of array 'array' will be default initialized
    '/wd4756',  # overflow in constant arithmetic
    '/wd4800',  # forcing value to bool 'true' or 'false' (performance warning)
    '/wd4291',  # no matching operator delete found
    '/wd4146',  # unary minus operator applied to unsigned type, result still unsigned
    '/wd4200',  # nonstandard extension used: zero-sized array in struct/union
    '/wd4624',  # destructor was implicitly defined as deleted [from LLVM]
    '/wd4309',  # 'initializing': truncation of constant value
    '/wd4838',  # conversion from 'int' to 'const char' requires a narrowing conversion
    '/wd5105',  # macro expansion producing 'defined' has undefined behavior (winbase.h, need Windows SDK upgrade)
    '/we4020',  # Error when passing the wrong number of parameters
    '/we4024',  # Error when passing different type of parameter
    '/we4189',  # 'identifier' : local variable is initialized but not referenced
    '/Zc:__cplusplus', #Set __cplusplus macro to match the /std:c++<version> on the command line
    '/Zc:enumTypes', # Enables C++ conforming enum underlying type and enumerator type deduction
    '/Zc:preprocessor', # Use the standards-conforming preprocessor
  ]
  c_args += cc.get_supported_arguments(_trial)
  cpp_args += cpp.get_supported_arguments(_trial)
else
  _trial_c = [
    '-Werror=implicit-function-declaration',
    '-Werror=missing-prototypes',
    '-Werror=return-type',
    '-Werror=empty-body',
    '-Werror=incompatible-pointer-types',
    '-Werror=int-conversion',
    '-Wimplicit-fallthrough',
    '-Wmisleading-indentation',
    '-Wno-error=maybe-uninitialized',
    '-Wno-missing-field-initializers',
    '-Wno-format-truncation',
    '-Wno-nonnull-compare',
    '-fno-math-errno',
    '-fno-trapping-math',
    '-Qunused-arguments',
    '-fno-common',
    '-Wno-unknown-pragmas',
    # Clang
    '-Wno-microsoft-enum-value',
    '-Wno-unused-function',
  ]
  _trial_cpp = [
    '-Werror=return-type',
    '-Werror=empty-body',
    '-Wmisleading-indentation',
    '-Wno-error=maybe-uninitialized',
    '-Wno-non-virtual-dtor',
    '-Wno-missing-field-initializers',
    '-Wno-format-truncation',
    '-fno-math-errno',
    '-fno-trapping-math',
    '-Qunused-arguments',
    # Some classes use custom new operator which zeroes memory, however
    # gcc does aggressive dead-store elimination which threats all writes
    # to the memory before the constructor as "dead stores".
    # For now we disable this optimization.
    '-flifetime-dse=1',
    '-Wno-unknown-pragmas',
    # Clang
    '-Wno-microsoft-enum-value',
  ]

  # MinGW chokes on format specifiers and I can't get it all working
  if not (cc.get_argument_syntax() == 'gcc' and host_machine.system() == 'windows')
    _trial_c += ['-Werror=format', '-Wformat-security']
    _trial_cpp += ['-Werror=format', '-Wformat-security']
  endif

  # FreeBSD annotated <pthread.h> but Mesa isn't ready
  if not (cc.get_id() == 'clang' and host_machine.system() == 'freebsd')
    _trial_c += ['-Werror=thread-safety']
  endif

  # If the compiler supports it, put function and data symbols in their
  # own sections and GC the sections after linking.  This lets drivers
  # drop shared code unused by that specific driver (particularly
  # relevant for Vulkan drivers).
  if cc.links('static char unused() { return 5; } int main() { return 0; }',
              args : '-Wl,--gc-sections', name : 'gc-sections')
    ld_args_gc_sections += '-Wl,--gc-sections'
    _trial_c += ['-ffunction-sections', '-fdata-sections']
    _trial_cpp += ['-ffunction-sections', '-fdata-sections']
  endif

  # Variables that are only used for assertions are considered unused when assertions
  # are disabled. Don't treat this as an error, since we build with -Werror even if
  # assertions are disabled.
  if with_mesa_ndebug
    _trial_c += ['-Wno-unused-variable', '-Wno-unused-but-set-variable', '/wd4189']
    _trial_cpp += ['-Wno-unused-variable', '-Wno-unused-but-set-variable', '/wd4189']
  endif

  c_args += cc.get_supported_arguments(_trial_c)
  cpp_args += cpp.get_supported_arguments(_trial_cpp)

  no_override_init_args += cc.get_supported_arguments(
    ['-Wno-override-init', '-Wno-initializer-overrides']
  )

  # Check for C and C++ arguments for MSVC compatibility. These are only used
  # in parts of the mesa code base that need to compile with MSVC, mainly
  # common code
  _trial_msvc = [
    '-Werror=pointer-arith',
    '-Werror=vla',
    '-Werror=gnu-empty-initializer',
    '-Wgnu-pointer-arith',
  ]
  c_msvc_compat_args += cc.get_supported_arguments(_trial_msvc)
  cpp_msvc_compat_args += cpp.get_supported_arguments(_trial_msvc)

  # Check for C and C++ arguments for Soong compatibility.
  _trial_soong_c = [
    '-Werror=date-time',
    '-Werror=gnu-alignof-expression',
    '-Werror=ignored-qualifiers',
    '-Werror=implicit-fallthrough',
    '-Werror=int-conversion',
    '-Werror=missing-prototypes',
    '-Werror=pragma-pack',
    '-Werror=pragma-pack-suspicious-include',
    '-Werror=sizeof-array-div',
    '-Werror=string-plus-int',
    '-Werror=unreachable-code-loop-increment',
  ]
  _trial_soong_cpp = [
    '-D_LIBCPP_ENABLE_THREAD_SAFETY_ANNOTATIONS',
    '-Werror=date-time',
    '-Werror=gnu-alignof-expression',
    '-Werror=ignored-qualifiers',
    '-Werror=implicit-fallthrough',
    '-Werror=pragma-pack',
    '-Werror=pragma-pack-suspicious-include',
    '-Werror=sizeof-array-div',
    '-Werror=string-plus-int',
    '-Werror=unreachable-code-loop-increment',
  ]
  if cpp.get_id() == 'gcc'
    _trial_soong_cpp += '-Werror=missing-declarations'
  else
    _trial_soong_cpp += '-Werror=missing-prototypes'
  endif
  soong_compat_c_args += cc.get_supported_arguments(_trial_soong_c)
  soong_compat_cpp_args += cpp.get_supported_arguments(_trial_soong_cpp)
endif

# set linker arguments
if host_machine.system() == 'windows'
  if cc.get_argument_syntax() == 'msvc'
    add_project_link_arguments(
      '/fixed:no',
      '/dynamicbase',
      '/nxcompat',
      language : ['c', 'cpp'],
    )
    if get_option('buildtype') != 'debug'
      add_project_link_arguments(
        '/incremental:no',
        language : ['c', 'cpp'],
      )
    endif
  else
    add_project_link_arguments(
      cc.get_supported_link_arguments(
        '-Wl,--nxcompat',
        '-Wl,--dynamicbase',
        '-static-libgcc',
        '-static-libstdc++',
      ),
      language : ['c'],
    )
    add_project_link_arguments(
      cpp.get_supported_link_arguments(
        '-Wl,--nxcompat',
        '-Wl,--dynamicbase',
        '-static-libgcc',
        '-static-libstdc++',
      ),
      language : ['cpp'],
    )
  endif
endif

sse2_arg = []
sse2_args = []
sse41_args = []
with_sse41 = false
if host_machine.cpu_family().startswith('x86')
  pre_args += '-DUSE_SSE41'
  with_sse41 = true

  if cc.get_id() != 'msvc'
    sse41_args = ['-msse4.1']

    if host_machine.cpu_family() == 'x86'
      # x86_64 have sse2 by default, so sse2 args only for x86
      sse2_arg = ['-msse2', '-mfpmath=sse']
      sse2_args = [sse2_arg, '-mstackrealign']
      if get_option('sse2')
        # These settings make generated GCC code match MSVC and follow
        # GCC advice on https://gcc.gnu.org/wiki/FloatingPointMath#x86note
        #
        # NOTE: We need to ensure stack is realigned given that we
        # produce shared objects, and have no control over the stack
        # alignment policy of the application. Therefore we need
        # -mstackrealign or -mincoming-stack-boundary=2.
        #
        # XXX: We could have SSE without -mstackrealign if we always used
        # __attribute__((force_align_arg_pointer)), but that's not
        # always the case.
        c_cpp_args += sse2_args
        # sse2_args are adopted into c_cpp_args to avoid duplicated sse2 command line args
        sse2_arg = []
        sse2_args = []
      else
        # GCC on x86 (not x86_64) with -msse* assumes a 16 byte aligned stack, but
        # that's not guaranteed
        sse41_args += '-mstackrealign'
      endif
    endif
  endif
endif

# Detect __builtin_ia32_clflushopt support
if cc.has_function('__builtin_ia32_clflushopt', args : '-mclflushopt')
  pre_args += '-DHAVE___BUILTIN_IA32_CLFLUSHOPT'
  clflushopt_args = ['-mclflushopt']
  with_clflushopt = true
else
  clflushopt_args = []
  with_clflushopt = false
endif

# Check for GCC style atomics
dep_atomic = null_dep

if cc.compiles('''#include <stdint.h>
                  int main() {
                    struct {
                      uint64_t *v;
                    } x;
                    return (int)__atomic_load_n(x.v, __ATOMIC_ACQUIRE) &
                           (int)__atomic_add_fetch(x.v, (uint64_t)1, __ATOMIC_ACQ_REL);

                  }''',
               name : 'GCC atomic builtins')
  pre_args += '-DUSE_GCC_ATOMIC_BUILTINS'

  # Not all atomic calls can be turned into lock-free instructions, in which
  # GCC will make calls into the libatomic library. Check whether we need to
  # link with -latomic.
  #
  # This can happen for 64-bit atomic operations on 32-bit architectures such
  # as ARM.
  if not cc.links('''#include <stdint.h>
                     int main() {
                       struct {
                         uint64_t *v;
                       } x;
                       return (int)__atomic_load_n(x.v, __ATOMIC_ACQUIRE) &
                              (int)__atomic_add_fetch(x.v, (uint64_t)1, __ATOMIC_ACQ_REL);
                     }''',
                  name : 'GCC atomic builtins required -latomic')
    dep_atomic = cc.find_library('atomic')
  endif
endif
if not cc.links('''#include <stdint.h>
                   uint64_t v;
                   int main() {
                     return __sync_add_and_fetch(&v, (uint64_t)1);
                   }''',
                dependencies : dep_atomic,
                name : 'GCC 64bit atomics')
  pre_args += '-DMISSING_64BIT_ATOMICS'
endif

dep_ws2_32 = cc.find_library('ws2_32', required : with_platform_windows)

# Check for standard headers and functions
if (cc.has_header_symbol('sys/sysmacros.h', 'major') and
  cc.has_header_symbol('sys/sysmacros.h', 'minor') and
  cc.has_header_symbol('sys/sysmacros.h', 'makedev'))
  pre_args += '-DMAJOR_IN_SYSMACROS'
endif
if (cc.has_header_symbol('sys/mkdev.h', 'major') and
  cc.has_header_symbol('sys/mkdev.h', 'minor') and
  cc.has_header_symbol('sys/mkdev.h', 'makedev'))
  pre_args += '-DMAJOR_IN_MKDEV'
endif

if cc.check_header('sched.h')
  pre_args += '-DHAS_SCHED_H'
  if cc.has_function('sched_getaffinity')
    pre_args += '-DHAS_SCHED_GETAFFINITY'
  endif
endif

if not ['linux'].contains(host_machine.system())
  # Deprecated on Linux and requires <sys/types.h> on FreeBSD and OpenBSD
  if cc.check_header('sys/sysctl.h', prefix : '#include <sys/types.h>')
    pre_args += '-DHAVE_SYS_SYSCTL_H'
  endif
endif

foreach h : ['xlocale.h', 'linux/futex.h', 'endian.h', 'dlfcn.h', 'sys/shm.h',
             'cet.h', 'pthread_np.h', 'poll.h', 'sys/inotify.h',
             'linux/udmabuf.h']
  if cc.check_header(h)
    pre_args += '-DHAVE_@0@'.format(h.to_upper().underscorify())
  endif
endforeach

functions_to_detect = {
  'strtof': '',
  'mkostemp': '',
  'memfd_create': '#include <sys/mman.h>',
  'random_r': '',
  'flock': '',
  'strtok_r': '',
  'getrandom': '#include <sys/random.h>',
  'qsort_s': '',
  'posix_fallocate': '',
  'secure_getenv': '',
  'sysconf': '#include <unistd.h>',
}

foreach f, prefix: functions_to_detect
  if cc.has_function(f, args: pre_args, prefix: prefix)
    pre_args += '-DHAVE_@0@'.format(f.to_upper())
  endif
endforeach

if cpp.links('''
    #define _GNU_SOURCE
    #include <stdlib.h>

    static int dcomp(const void *l, const void *r, void *t) { return 0; }

    int main(int ac, char **av) {
      int arr[] = { 1 };
      void *t = NULL;
      qsort_r((void*)&arr[0], 1, 1, dcomp, t);
      return (0);
    }''',
    args : pre_args,
    name : 'GNU qsort_r')
  pre_args += '-DHAVE_GNU_QSORT_R'
elif cpp.links('''
    #include <stdlib.h>

    static int dcomp(void *t, const void *l, const void *r) { return 0; }

    int main(int ac, char **av) {
      int arr[] = { 1 };
      void *t = NULL;
      qsort_r((void*)&arr[0], 1, 1, t, dcomp);
      return (0);
    }''',
    args : pre_args,
    name : 'BSD qsort_r')
  pre_args += '-DHAVE_BSD_QSORT_R'
endif

if cc.has_header_symbol('time.h', 'struct timespec')
   pre_args += '-DHAVE_STRUCT_TIMESPEC'
endif

with_c11_threads = false
if cc.has_function('thrd_create', prefix: '#include <threads.h>')
  if with_platform_android
    # Current only Android's c11 <threads.h> are verified
    pre_args += '-DHAVE_THRD_CREATE'
    with_c11_threads = true
  endif
endif

if cc.has_header_symbol('errno.h', 'program_invocation_name',
                        args : '-D_GNU_SOURCE')
   pre_args += '-DHAVE_PROGRAM_INVOCATION_NAME'
elif with_tools.contains('intel') and not with_platform_android
  # Intel tools is supported on Android where the program name is from
  # `getprogname()` without `program_invocation_name` in glibc.
  # See `src/util/u_process.c` for more details.
  error('Intel tools require the program_invocation_name variable')
endif

if cc.has_header_symbol('math.h', 'issignaling',
                        args : '-D_GNU_SOURCE')
   pre_args += '-DHAVE_ISSIGNALING'
endif

# MinGW provides a __builtin_posix_memalign function, but not a posix_memalign.
# This means that this check will succeed, but then compilation will later
# fail. MSVC doesn't have this function at all, so only check for it on
# non-windows platforms.
if host_machine.system() != 'windows'
  if cc.has_function('posix_memalign')
    pre_args += '-DHAVE_POSIX_MEMALIGN'
  endif
endif

if cc.has_member('struct dirent', 'd_type', prefix: '''#include <sys/types.h>
   #include <dirent.h>''')
   pre_args += '-DHAVE_DIRENT_D_TYPE'
endif

# strtod locale support
if cc.links('''
    #define _GNU_SOURCE
    #include <stdlib.h>
    #include <locale.h>
    #ifdef HAVE_XLOCALE_H
    #include <xlocale.h>
    #endif
    int main() {
      locale_t loc = newlocale(LC_CTYPE_MASK, "C", NULL);
      const char *s = "1.0";
      char *end;
      double d = strtod_l(s, &end, loc);
      float f = strtof_l(s, &end, loc);
      freelocale(loc);
      return 0;
    }''',
    args : pre_args,
    name : 'strtod has locale support')
  pre_args += '-DHAVE_STRTOD_L'
endif

# Check for some linker flags
ld_args_bsymbolic = []
if cc.links('int main() { return 0; }', args : '-Wl,-Bsymbolic', name : 'Bsymbolic')
  ld_args_bsymbolic += '-Wl,-Bsymbolic'
endif
with_ld_version_script = false
if host_machine.system() != 'windows' and cc.links('int main() { return 0; }',
            args : '-Wl,--version-script=@0@'.format(
              join_paths(meson.current_source_dir(), 'build-support/conftest.map')),
            name : 'version-script')
  with_ld_version_script = true
endif
with_ld_dynamic_list = false
if cc.links('int main() { return 0; }',
            args : '-Wl,--dynamic-list=@0@'.format(
              join_paths(meson.current_source_dir(), 'build-support/conftest.dyn')),
            name : 'dynamic-list')
  with_ld_dynamic_list = true
endif

ld_args_build_id = cc.get_supported_link_arguments('-Wl,--build-id=sha1')

# check for dl support
dep_dl = null_dep
if host_machine.system() != 'windows'
  if not cc.has_function('dlopen')
    dep_dl = cc.find_library('dl', required : true)
  endif
  if cc.has_function('dladdr', dependencies : dep_dl)
    # This is required for src/util
    pre_args += '-DHAVE_DLADDR'
  endif
endif

if cc.has_function('dl_iterate_phdr')
  pre_args += '-DHAVE_DL_ITERATE_PHDR'
elif with_intel_vk or with_intel_hasvk
  error('Intel "Anvil" Vulkan driver requires the dl_iterate_phdr function')
endif

if with_any_intel and ['x86', 'x86_64'].contains(host_machine.cpu_family())
  pre_args += '-DSUPPORT_INTEL_INTEGRATED_GPUS'
endif

# Determine whether or not the rt library is needed for time functions
if host_machine.system() == 'windows' or cc.has_function('clock_gettime')
  dep_clock = null_dep
else
  dep_clock = cc.find_library('rt')
endif

# IMPORTANT: We can't upgrade Zlib beyond 1.2.5 because it would break Viewperf.
dep_zlib = dependency('zlib', version : '>= 1.2.3',
                      allow_fallback: true,
                      required : get_option('zlib'))
if dep_zlib.found()
  pre_args += '-DHAVE_ZLIB'
endif

if host_machine.system() == 'windows' or with_platform_android
  dep_display_info = null_dep
else
  dep_display_info = dependency('libdisplay-info', version : '>= 0.1.1',
                                required : get_option('display-info'))
  if dep_display_info.found()
    pre_args += '-DHAVE_LIBDISPLAY_INFO'
  endif
endif

dep_zstd = dependency('libzstd', required : get_option('zstd'))
if dep_zstd.found()
  pre_args += '-DHAVE_ZSTD'
endif

with_compression = dep_zlib.found() or dep_zstd.found()
if with_compression
  pre_args += '-DHAVE_COMPRESSION'
elif with_shader_cache
  error('Shader Cache requires compression')
endif

if host_machine.system() == 'windows'
  # For MSVC and MinGW we aren't using pthreads, and dependency('threads') will add linkage
  # to pthread for MinGW, so leave the dependency null_dep for Windows. For Windows linking to
  # kernel32 is enough for c11/threads.h and it's already linked by meson by default
  dep_thread = null_dep
else
  dep_thread = dependency('threads')
endif
if dep_thread.found()
  pre_args += '-DHAVE_PTHREAD'
  if host_machine.system() != 'netbsd' and cc.has_function(
      'pthread_setaffinity_np',
      dependencies : dep_thread,
      prefix : '#include <pthread.h>',
      args : '-D_GNU_SOURCE')
    pre_args += '-DHAVE_PTHREAD_SETAFFINITY'
  endif
endif

with_expat = get_option('expat') \
  .disable_auto_if(with_platform_windows) \
  .enable_if(with_intel_tools, error_message : 'Intel tools require expat')

if host_machine.system() == 'darwin'
  dep_expat = meson.get_compiler('c').find_library('expat', required : with_expat)
else
  dep_expat = dependency('expat', allow_fallback: true,
                         required : with_expat)
endif

# We don't require expat on Android or Windows
use_xmlconfig = get_option('xmlconfig') \
  .require(not (with_platform_android or with_platform_windows),
           error_message : 'xmlconfig not available on Android or Windows') \
  .require(dep_expat.found(),
           error_message : 'requires expat') \
  .allowed()

# Predefined macros for windows
if host_machine.system() == 'windows'
  pre_args += '-DWIN32_LEAN_AND_MEAN' # http://msdn2.microsoft.com/en-us/library/6dwk3a1z.aspx
endif
# this only exists on linux so either this is linux and it will be found, or
# it's not linux and wont
dep_m = cc.find_library('m', required : false)

if host_machine.system() == 'windows'
  dep_regex = meson.get_compiler('c').find_library('regex', required : false)
  if not dep_regex.found()
    dep_regex = declare_dependency(compile_args : ['-DNO_REGEX'])
  endif
else
  dep_regex = null_dep
endif

if with_platform_haiku
  dep_network = cc.find_library('network')
endif

dep_futex = null_dep
if host_machine.system() == 'windows'
  if (get_option('min-windows-version') < 8)
    pre_args += '-DWINDOWS_NO_FUTEX'
  else
    dep_futex = cc.find_library('synchronization', required : true)
  endif
endif

# Check for libdrm. Various drivers have different libdrm version requirements,
# but we always want to use the same version for all libdrm modules. That means
# even if driver foo requires 2.4.0 and driver bar requires 2.4.3, if foo and
# bar are both on use 2.4.3 for both of them
dep_libdrm_amdgpu = null_dep
dep_libdrm_intel = null_dep

_drm_amdgpu_ver = '2.4.133'
_drm_intel_ver = '2.4.75'
_drm_ver = '2.4.109'

_libdrm_checks = [
  ['intel', with_gallium_i915],
  ['amdgpu', (with_amd_vk and not with_platform_windows) or with_gallium_radeonsi],
]

# Loop over the enables versions and get the highest libdrm requirement for all
# active drivers.
_drm_blame = ''
foreach d : _libdrm_checks
  ver = get_variable('_drm_@0@_ver'.format(d[0]))
  if d[1] and ver.version_compare('>' + _drm_ver)
    _drm_ver = ver
    _drm_blame = d[0]
  endif
endforeach
if _drm_blame != ''
  message('libdrm @0@ needed because @1@ has the highest requirement'.format(_drm_ver, _drm_blame))
endif

allow_fallback_for_libdrm = get_option('allow-fallback-for').contains('libdrm')

with_gallium_drisw_kms = false
if system_has_kms_drm
  dep_libdrm = dependency(
    'libdrm', version : '>=' + _drm_ver,
    required : with_dri2 or with_dri or with_gbm,
    allow_fallback: allow_fallback_for_libdrm,
    default_options : {
      'auto_features' : 'disabled',
      'intel' : _libdrm_checks[0][1] ? 'enabled' : 'disabled',
      'amdgpu' : _libdrm_checks[1][1] ? 'enabled' : 'disabled',
    },
  )
else
  # We should prevent libdrm from being available when the target doesn't have it to avoid transitive
  # dependencies (such as vk-runtime) linking to it
  dep_libdrm = null_dep
endif
if host_machine.system() == 'darwin' and (with_gallium_freedreno or with_freedreno_vk)
  # No DRM on this system: freedreno's requests go to the kernel's driver through a stand-in
  # for libdrm (src/annibale-drm, put there by Darwin on annibale's tools/mk-mesa.sh; its one
  # source file is built with freedreno's drm layer, src/freedreno/drm).
  dep_libdrm = declare_dependency(
    include_directories : include_directories('src/annibale-drm'),
    link_args : ['-framework', 'IOKit', '-framework', 'CoreFoundation'],
  )
  if with_freedreno_vk and not with_gallium_freedreno
    # (Turnip alone: the Vulkan runtime finds its device through libdrm's device list)
    pre_args += '-DHAVE_LIBDRM'
  endif
elif dep_libdrm.found()
  pre_args += '-DHAVE_LIBDRM'
  if with_dri_platform == 'drm' and with_dri
    with_gallium_drisw_kms = true
  endif
endif

# Then get each libdrm module
foreach d : _libdrm_checks
  if d[1]
    set_variable(
      'dep_libdrm_' + d[0],
      dependency(
        'libdrm_' + d[0],
        version : '>=' + _drm_ver,
        allow_fallback: allow_fallback_for_libdrm,
      )
    )
  endif
endforeach

dep_libudev = dependency('libudev', required : false)
if dep_libudev.found()
  pre_args += '-DHAVE_LIBUDEV'
endif

llvm_modules = ['bitwriter', 'engine', 'mcdisassembler', 'core', 'executionengine', 'scalaropts', 'transformutils', 'instcombine']
llvm_optional_modules = ['coroutines']
if with_amd_vk or with_gallium_radeonsi
  llvm_modules += ['amdgpu', 'bitreader', 'ipo']
endif
if with_clc
  llvm_modules += ['coverage', 'target', 'linker', 'irreader', 'option', 'libdriver', 'lto']
  # all-targets is needed to support static linking LLVM build with multiple targets.
  # windowsdriver is needded with LLVM>=15, frontendhlsl with LLVM>=16, frontenddriver with LLVM>=18 and abi with LLVM>=23,
  # but we don't know what LLVM version we are using yet
  llvm_optional_modules += ['all-targets', 'windowsdriver', 'frontendhlsl', 'frontenddriver', 'abi']
endif
if draw_with_llvm
  llvm_modules += 'native'
  # lto is needded with LLVM>=15, but we don't know what LLVM verrsion we are using yet
  llvm_optional_modules += ['lto']
  if host_machine.system() == 'darwin'
    # Apple systems frequently cross-compile and build fat binaries with multiple
    # archs, so lp_build_create_jit_compiler_for_module() initializes every target
    # instead of just the native one. Link all of them, not just the native one.
    llvm_modules += 'all-targets'
  endif
endif

# MCJIT is deprecated in LLVM and will not accept new architecture ports,
# so any architecture not in the exhaustive list will have to rely on LLVM
# ORCJIT for llvmpipe functionality.
llvm_has_mcjit = host_machine.cpu_family() in ['aarch64', 'arm', 'mips', 'mips64', 'ppc', 'ppc64', 's390x', 'x86', 'x86_64']
llvm_with_orcjit = get_option('llvm-orcjit') or not llvm_has_mcjit

if llvm_with_orcjit
  llvm_modules += ['orcjit']
else
  llvm_modules += ['mcjit']
endif

if (with_amd_vk or with_gallium_radeonsi) and amd_with_llvm
  _llvm_version = '>= 18.0.0'
elif with_clc or llvm_with_orcjit
  _llvm_version = '>= 15.0.0'
else
  _llvm_version = '>= 8.0.0'
endif

_shared_llvm = get_option('shared-llvm') \
  .disable_auto_if(host_machine.system() == 'windows') \
  .allowed()

dep_llvm = dependency(
  'llvm',
  method : host_machine.system() == 'windows' ? 'auto' : 'config-tool',
  version : _llvm_version,
  modules : llvm_modules,
  optional_modules : llvm_optional_modules,
  required : with_llvm,
  static : not _shared_llvm,
  fallback : ['llvm', 'dep_llvm'],
  include_type : 'system',
)
if dep_llvm.found()
  pre_args += '-DMESA_LLVM_VERSION_STRING="@0@"'.format(dep_llvm.version())
  pre_args += '-DLLVM_IS_SHARED=@0@'.format(_shared_llvm.to_int())

  if (with_swrast_vk or with_gallium_llvmpipe) and not draw_with_llvm
    error('Lavapipe and llvmpipe require LLVM draw support.')
  endif

  if with_gallium_i915 and not draw_with_llvm
    error('i915 requires LLVM draw support for vertex shaders.')
  endif

  if host_machine.system() != 'windows'
    # LLVM can be built without rtti, turning off rtti changes the ABI of C++
    # programs, so we need to build all C++ code in mesa without rtti as well to
    # ensure that linking works. Note that Win32 compilers does handle mismatching RTTI
    # without issues, so only apply this for other compilers.
    if dep_llvm.type_name() == 'internal'
      _llvm_rtti = subproject('llvm').get_variable('has_rtti', true)
    else
      # The CMake finder will return 'ON', the llvm-config will return 'YES'
      _llvm_rtti = ['ON', 'YES'].contains(dep_llvm.get_variable(cmake : 'LLVM_ENABLE_RTTI', configtool: 'has-rtti'))
    endif
    if _rtti != _llvm_rtti
      if _llvm_rtti
        error('LLVM was built with RTTI, cannot build Mesa with RTTI disabled. Remove cpp_rtti disable switch or use LLVM built without LLVM_ENABLE_RTTI.')
      else
        error('LLVM was built without RTTI, so Mesa must also disable RTTI. Use an LLVM built with LLVM_ENABLE_RTTI or add cpp_rtti=false.')
      endif
    endif
  endif

  if cc.get_argument_syntax() == 'msvc'
    # Suppress "/DELAYLOAD:ole32.dll/shell32.dll ignored" warnings that LLVM adds
    add_project_link_arguments(
      '/ignore:4199',
      language : ['c', 'cpp'],
    )
  endif
else
  draw_with_llvm = false
endif
amd_with_llvm = amd_with_llvm and dep_llvm.found()
pre_args += '-DDRAW_LLVM_AVAILABLE=@0@'.format(draw_with_llvm.to_int())
pre_args += '-DAMD_LLVM_AVAILABLE=@0@'.format(amd_with_llvm.to_int())
pre_args += '-DGALLIVM_USE_ORCJIT=@0@'.format((dep_llvm.found() and llvm_with_orcjit).to_int())

if with_clc
  chosen_llvm_version_array = dep_llvm.version().split('.')
  chosen_llvm_version_major = chosen_llvm_version_array[0].to_int()
  chosen_llvm_version_minor = chosen_llvm_version_array[1].to_int()

  # Require an SPIRV-LLVM-Translator version compatible with the chosen LLVM
  # one.

  _llvmspirvlib_min_version = '>= 15.0.0.0'

  _llvmspirvlib_version = [
    _llvmspirvlib_min_version,
    '>= @0@.@1@'.format(chosen_llvm_version_major, chosen_llvm_version_minor),
    '< @0@.@1@'.format(chosen_llvm_version_major, chosen_llvm_version_minor + 1) ]

  # LLVMSPIRVLib is available at https://github.com/KhronosGroup/SPIRV-LLVM-Translator
  dep_llvmspirvlib = dependency('LLVMSPIRVLib', required : true, version : _llvmspirvlib_version)
else
  dep_llvmspirvlib = null_dep
endif

with_spirv_tools = get_option('spirv-tools') \
    .enable_if(with_clc, error_message : 'CLC requires SPIRV-Tools')

dep_spirv_tools = dependency(
  'SPIRV-Tools',
  required : with_spirv_tools,
  version : '>= 2024.1',
)
if dep_spirv_tools.found()
  pre_args += '-DHAVE_SPIRV_TOOLS'
endif

dep_clang = null_dep
if with_clc
  llvm_libdir = dep_llvm.get_variable(cmake : 'LLVM_LIBRARY_DIR', configtool: 'libdir')

  dep_clang = cpp.find_library('clang-cpp', dirs : llvm_libdir, required : false)

  if not dep_clang.found() or not _shared_llvm
    clang_modules = [
      'clangBasic', 'clangAST', 'clangCodeGen', 'clangLex',
      'clangDriver', 'clangFrontend', 'clangFrontendTool',
      'clangHandleCXX', 'clangHandleLLVM', 'clangSerialization',
      'clangSema', 'clangParse', 'clangEdit', 'clangAnalysis'
    ]
    if dep_llvm.version().version_compare('>= 15.0')
      clang_modules += 'clangSupport'
    endif
    if dep_llvm.version().version_compare('>= 16.0')
      clang_modules += 'clangASTMatchers'
    endif
    if dep_llvm.version().version_compare('>= 18.0')
      clang_modules += 'clangAPINotes'
    endif
    if dep_llvm.version().version_compare('>= 22.0')
      clang_modules += ['clangAnalysisLifetimeSafety', 'clangOptions']
    endif

    dep_clang = []
    foreach m : clang_modules
      dep_clang += cpp.find_library(m, dirs : llvm_libdir, required : true)
    endforeach
  endif
endif

dep_lua = dependency('lua54', 'lua5.4', 'lua-5.4',
                     'lua53', 'lua5.3', 'lua-5.3',
                     'lua', required: false,
                     allow_fallback: with_tools.contains('freedreno'),
                     disabler : true,
                     version: '>=5.3')

# Be explicit about only using this lib on Windows, to avoid picking
# up random libs with the generic name 'libversion'
dep_version = null_dep
if host_machine.system() == 'windows'
  dep_version = cpp.find_library('version')
endif

dep_elf = dependency('libelf', required : false)
if not with_platform_windows and not dep_elf.found()
  dep_elf = cc.find_library('elf', required : false)
endif
if dep_elf.found()
  pre_args += '-DUSE_LIBELF'
elif with_gallium_radeonsi and with_gfx_compute
  error('Gallium driver radeonsi requires libelf')
elif with_nouveau_vk
  error('NVK requires libelf')
endif

dep_valgrind = dependency('valgrind', required : get_option('valgrind'))
if dep_valgrind.found()
  pre_args += '-DHAVE_VALGRIND'
endif

# AddressSanitizer's leak reports need all the symbols to be present at exit to
# decode well, which runs afoul of our dlopen()/dlclose()ing of the DRI drivers.
# Set a flag so we can skip the dlclose for asan builds.
if get_option('b_sanitize').split(',').contains('address')
  asan_c_args = ['-DBUILT_WITH_ASAN=1']
else
  asan_c_args = ['-DBUILT_WITH_ASAN=0']
endif

# ThreadSanitizer can't deal with futexes, and reports races for cases we don't care about
# so add a define to work silence these issues.
if get_option('b_sanitize').contains('thread')
  pre_args += '-DTHREAD_SANITIZER=1'
  tsan_blacklist = '-fsanitize-blacklist=@0@'.format(join_paths(meson.project_source_root(), 'build-support', 'tsan-blacklist.txt'))
  if cc.has_argument(tsan_blacklist)
    pre_args += tsan_blacklist
  else
    warning('Compiler does not support "-fsanitize-blacklist", expected race conditions will not be surpressed')
  endif
else
  pre_args += '-DTHREAD_SANITIZER=0'
endif

yacc_is_bison = true
needs_flex_bison = with_any_opengl or with_freedreno_vk or with_intel_tools or with_gallium

if build_machine.system() == 'windows'
  # Prefer the winflexbison versions, they're much easier to install and have
  # better windows support.

  prog_flex = find_program('win_flex', required : false)
  if prog_flex.found()
    # windows compatibility (uses <io.h> instead of <unistd.h> and _isatty,
    # _fileno functions)
    prog_flex = [prog_flex, '--wincompat']
  else
    prog_flex = [find_program('flex', 'lex', required : needs_flex_bison, disabler : true)]
  endif
  # Force flex to use const keyword in prototypes, as relies on __cplusplus or
  # __STDC__ macro to determine whether it's safe to use const keyword
  prog_flex += '-DYY_USE_CONST='

  prog_flex_cpp = prog_flex
  # Convince win_flex to use <inttypes.h> for C++ files
  # Note that we are using a C99 version here rather than C11,
  # because using a C11 version can cause the MSVC CRT headers to define
  # static_assert to _Static_assert, which breaks other parts of the CRT
  prog_flex_cpp += '-D__STDC_VERSION__=199901'

  prog_bison = find_program('win_bison', required : false)
  if not prog_bison.found()
    prog_bison = find_program('bison', 'yacc', required : needs_flex_bison, disabler : true)
  endif
else
  prog_bison = find_program('bison', required : false)

  if not prog_bison.found()
    prog_bison = find_program('byacc', required : needs_flex_bison, disabler : true)
    yacc_is_bison = false
  endif

  # Disable deprecated keyword warnings, since we have to use them for
  # old-bison compat.  See discussion in
  # https://gitlab.freedesktop.org/mesa/mesa/merge_requests/2161
  if find_program('bison', required : false, version : '> 2.3').found()
    prog_bison = [prog_bison, '-Wno-deprecated']
  endif

  prog_flex = find_program('flex', required : needs_flex_bison, disabler : true)
  prog_flex_cpp = prog_flex
endif

prog_ln = find_program('ln', required : false)

_libunwind = get_option('libunwind') \
  .require(not with_platform_android, error_message : 'Android requires the use of the backtrace library, not libunwind')
if host_machine.system() == 'darwin'
  dep_unwind = meson.get_compiler('c').find_library('System', required : _libunwind)
else
  dep_unwind = dependency('libunwind', required : _libunwind)
endif
if dep_unwind.found()
  pre_args += '-DHAVE_LIBUNWIND'
endif

if with_osmesa
  if not with_gallium_swrast
    error('OSMesa gallium requires gallium softpipe or llvmpipe.')
  endif
  if host_machine.system() == 'windows'
    osmesa_lib_name = 'osmesa'
  else
    osmesa_lib_name = 'OSMesa'
  endif
endif

# TODO: symbol mangling

with_wayland_bind_display = with_platform_wayland and get_option('legacy-wayland').contains('bind-wayland-display')
if with_platform_wayland
  dep_wl_protocols = dependency('wayland-protocols', version : '>= 1.41', default_options: [ 'tests=false' ])
  dep_wayland_client = dependency('wayland-client', version : '>=1.18')
  dep_wayland_server = dependency('wayland-server', version : '>=1.18')
  if with_egl
    dep_wayland_egl = dependency('wayland-egl-backend', version : '>= 3')
    dep_wayland_egl_headers = dep_wayland_egl.partial_dependency(compile_args : true)
  endif
  pre_args += '-DWL_HIDE_DEPRECATED'
  if cc.has_function(
      'wl_display_dispatch_queue_timeout',
      prefix : '#include <wayland-client.h>',
      dependencies: dep_wayland_client)
    pre_args += ['-DHAVE_WL_DISPATCH_QUEUE_TIMEOUT']
  endif
  if cc.has_function(
      'wl_display_create_queue_with_name',
      prefix : '#include <wayland-client.h>',
      dependencies: dep_wayland_client)
    pre_args += ['-DHAVE_WL_CREATE_QUEUE_WITH_NAME']
  endif
  # This can be renamed just `wayland` when we require at least 1.8
  mod_wl = import('unstable-wayland')
endif

# Even if we find OpenMP, Gitlab CI fails to link with gcc/i386 and clang/anyarch.
dep_openmp = null_dep
if host_machine.cpu_family() == 'x86_64' and cc.get_id() == 'gcc'
  dep_openmp = dependency('openmp', required : false)
  if dep_openmp.found()
    pre_args += ['-DHAVE_OPENMP']
  endif
endif

dep_x11 = null_dep
dep_xext = null_dep
dep_x11_xcb = null_dep
dep_xcb = null_dep
dep_xcb_keysyms = null_dep
dep_xcb_glx = null_dep
dep_xcb_dri3 = null_dep
dep_glproto = null_dep
dep_xxf86vm = null_dep
dep_xcb_present = null_dep
dep_xcb_sync = null_dep
dep_xcb_xfixes = null_dep
dep_xshmfence = null_dep
dep_xcb_xrandr = null_dep
dep_xcb_shm = null_dep
dep_xlib_xrandr = null_dep

dep_glproto_version = '>= 1.4.14'
dep_xcb_dri3_version = '>= 1.13'
dep_xcb_glx_version = '>= 1.8.1'
dep_xcb_present_version = '>= 1.13'
dep_xlib_version = '>= 1.6' # RHEL8 has 1.6, RHEL9 has 1.7, U22.04 has 1.7
dep_xlib_xrandr_version = '>= 1.3'
dep_xshmfence_version = '>= 1.1'

with_dri3_explicit_sync = false
with_xcb_keysyms = false
if with_platform_x11
  dep_xcb = dependency('xcb')
  dep_xcb_xrandr = dependency('xcb-randr')
  if with_glx == 'xlib'
    dep_x11 = dependency('x11', version : dep_xlib_version)
    dep_xext = dependency('xext')
  elif with_glx == 'dri'
    dep_x11 = dependency('x11', version : dep_xlib_version)
    dep_xext = dependency('xext')
    dep_xcb_glx = dependency('xcb-glx', version : dep_xcb_glx_version)
    dep_xcb_shm = dependency('xcb-shm')
    if with_gallium_zink
      dep_xcb_present = dependency('xcb-present', version : dep_xcb_present_version)
    endif
  elif with_gallium_rusticl
    # needed for GL sharing extension
    dep_x11 = dependency('x11', version : dep_xlib_version)
  endif
  if (with_any_vk or with_glx == 'dri' or with_egl or with_gallium_va)
    dep_xcb = dependency('xcb')
    dep_xcb_keysyms = dependency('xcb-keysyms', required : false)
    with_xcb_keysyms = dep_xcb_keysyms.found()
    if with_xcb_keysyms
      pre_args += '-DXCB_KEYSYMS_AVAILABLE'
    endif
    dep_x11_xcb = dependency('x11-xcb')
    if with_dri_platform == 'drm' and not dep_libdrm.found()
      error('libdrm required for gallium video statetrackers when using x11')
    endif
  endif
  if with_dri_platform == 'drm' or with_dri_platform == 'pseudo-drm'
    dep_xcb_dri3 = dependency('xcb-dri3', version : dep_xcb_dri3_version)
    dep_xcb_present = dependency('xcb-present', version : dep_xcb_present_version)
    if (dep_xcb_dri3.version().version_compare('>= 1.17') and
        dep_xcb_present.version().version_compare('>= 1.17'))
      with_dri3_explicit_sync = true
    endif
    dep_xcb_shm = dependency('xcb-shm')
    dep_xcb_sync = dependency('xcb-sync')
    dep_xshmfence = dependency('xshmfence', version : dep_xshmfence_version)
    pre_args += '-DHAVE_X11_DRM'
  endif
  if with_glx == 'dri' or with_glx == 'xlib'
    dep_glproto = dependency('glproto', version : dep_glproto_version)
  endif
  if with_glx == 'dri'
    if with_dri_platform == 'drm' or with_dri_platform == 'pseudo-drm'
      if with_glx_direct
        dep_xxf86vm = dependency('xxf86vm')
      endif
    endif
  endif
  if (with_egl or
      with_dri or
      with_any_vk)
    dep_xcb_xfixes = dependency('xcb-xfixes')
  endif
  if with_any_vk
    dep_xcb_dri3 = dependency('xcb-dri3', version : dep_xcb_dri3_version)
    dep_xcb_present = dependency('xcb-present', version : dep_xcb_present_version)
    dep_xcb_shm = dependency('xcb-shm')
    dep_xshmfence = dependency('xshmfence', version : dep_xshmfence_version)
  endif
  if with_xlib_lease or with_any_vk
    dep_xcb_xrandr = dependency('xcb-randr')
  endif
  if with_xlib_lease
    dep_xlib_xrandr = dependency('xrandr', version : dep_xlib_xrandr_version)
  endif
endif

if with_dri
  pre_args += '-DHAVE_DRI'
endif
if with_dri2
  pre_args += '-DHAVE_DRI2'
endif
if with_dri3_explicit_sync
  pre_args += '-DHAVE_DRI3_EXPLICIT_SYNC'
endif
if with_gallium_drisw_kms
  pre_args += '-DHAVE_DRISW_KMS'
endif

if get_option('gallium-extra-hud')
  pre_args += '-DHAVE_GALLIUM_EXTRA_HUD=1'
endif

dep_lmsensors = cc.find_library('sensors', required : get_option('lmsensors'))
if dep_lmsensors.found()
  pre_args += '-DHAVE_LIBSENSORS=1'
endif

_shader_replacement = get_option('custom-shader-replacement')
if _shader_replacement == ''
else
  pre_args += '-DCUSTOM_SHADER_REPLACEMENT'
endif

allow_fallback_for_perfetto = get_option('allow-fallback-for').contains('perfetto')
with_perfetto = get_option('perfetto')
with_datasources = get_option('datasources')
with_any_datasource = with_datasources.length() != 0
if with_perfetto
  dep_perfetto_sdk = dependency(
      'perfetto',
      fallback: allow_fallback_for_perfetto ? ['perfetto-sdk', 'dep_perfetto_sdk'] : [],
  )
  dep_perfetto = dep_perfetto_sdk
  pre_args += '-DHAVE_PERFETTO'
endif

if get_option('android-libperfetto').enabled()
  pre_args += '-DANDROID_LIBPERFETTO'
endif

# Platforms where RenderDoc integration actually works
renderdoc_integration_supported = [
  'linux',
  'android',
].contains(host_machine.system())
pre_args += '-DHAVE_RENDERDOC_INTEGRATION=@0@'.format(renderdoc_integration_supported.to_int())

with_teflon = get_option('teflon')

with_gpuvis = get_option('gpuvis')
if with_gpuvis
  pre_args += '-DHAVE_GPUVIS'
endif

with_sysprof = get_option('sysprof')
if with_sysprof
  dep_sysprof = dependency('sysprof-capture-4', version: '>= 49.0')
  pre_args += '-DHAVE_SYSPROF'
endif

add_project_arguments(pre_args, language : ['c', 'cpp'])
add_project_arguments(c_cpp_args, language : ['c', 'cpp'])
if host_machine.system() == 'darwin'
  add_project_arguments(pre_args, language : ['objc'])
endif

add_project_arguments(c_args,   language : ['c'])
add_project_arguments(cpp_args, language : ['cpp'])

gl_priv_reqs = []

if with_glx == 'xlib'
  gl_priv_reqs += ['x11', 'xext', 'xcb']
elif with_glx == 'dri'
  gl_priv_reqs += [
    'x11', 'xext', 'xfixes', 'x11-xcb', 'xcb',
    'xcb-glx >= 1.8.1']
  if with_dri_platform == 'drm' or with_dri_platform == 'pseudo-drm'
    gl_priv_reqs += 'xcb-dri2 >= 1.8'
    if with_glx_direct
      gl_priv_reqs += 'xxf86vm'
    endif
  endif
endif
if dep_libdrm.found()
  gl_priv_reqs += 'libdrm >= 2.4.75'
endif

gl_priv_libs = []
if dep_thread.found()
  gl_priv_libs += ['-lpthread', '-pthread']
endif
if dep_m.found()
  gl_priv_libs += '-lm'
endif
if dep_dl.found()
  gl_priv_libs += '-ldl'
endif

# FIXME: autotools lists this as incomplete
gbm_priv_libs = []
if dep_dl.found()
  gbm_priv_libs += '-ldl'
endif

pkg = import('pkgconfig')

if host_machine.system() == 'windows' and cc.get_argument_syntax() == 'msvc'
  prog_dumpbin = find_program('dumpbin', required : false)
  with_symbols_check = prog_dumpbin.found() and with_tests
  if with_symbols_check
    symbols_check_args = ['--dumpbin', prog_dumpbin.full_path()]
  endif
elif host_machine.system() == 'windows' and cc.get_argument_syntax() != 'msvc'
  # mingw
  prog_gendef = find_program('gendef', required : false)
  with_symbols_check = prog_gendef.found() and with_tests
  if with_symbols_check
    symbols_check_args = ['--gendef', prog_gendef.full_path()]
  endif
else
  prog_nm = find_program('nm')
  with_symbols_check = prog_nm.found() and with_tests
  if with_symbols_check
    symbols_check_args = ['--nm', prog_nm.full_path()]
  endif
endif

# This quirk needs to be applied to sources with functions defined in assembly
# as GCC LTO drops them. See: https://bugs.freedesktop.org/show_bug.cgi?id=109391
gcc_lto_quirk = (cc.get_id() == 'gcc') ? ['-fno-lto'] : []

devenv = environment()

dir_compiler_nir = join_paths(meson.current_source_dir(), 'src/compiler/nir/')
dir_source_root = meson.project_source_root()

if host_machine.system() == 'windows'
  vulkan_icd_lib_path = import('fs').relative_to(get_option('bindir'), with_vulkan_icd_dir)
else
  vulkan_icd_lib_path = get_option('prefix') / get_option('libdir')
endif

vulkan_manifest_per_architecture = get_option('vulkan-manifest-per-architecture')

if vulkan_manifest_per_architecture
  vulkan_manifest_suffix = '@0@.json'.format(host_machine.cpu())
else
  vulkan_manifest_suffix = 'json'
endif

subdir('include')
subdir('bin')
subdir('src')

meson.add_devenv(devenv)

sphinx = find_program('sphinx-build', version : '>= 4.3',
                      required: get_option('html-docs'))
if sphinx.found()
  subdir('docs')
endif

summary(
  {
    'prefix': get_option('prefix'),
    'libdir': get_option('libdir'),
    'includedir': get_option('includedir'),
  },
  section: 'Directories'
)

summary(
  {
    'c_cpp_args': c_cpp_args,
  },
  section: 'Common C and C++ arguments'
)

summary(
  {
    'OpenGL': with_opengl,
    'ES1': with_gles1,
    'ES2': with_gles2,
    'GLVND': with_glvnd,
  },
  section: 'OpenGL', bool_yn: true
)

summary(
  {
    'Platform': with_dri_platform,
    'Driver dir': dri_drivers_path,
  },
  section: 'DRI', bool_yn: true, list_sep: ' '
)

summary(
  {
    'Enabled': with_glx != 'disabled',
    'Provider': with_glx == 'disabled' ? 'None' : with_glx
  },
  section: 'GLX', bool_yn: true, list_sep: ' '
)

egl_summary = {'Enabled': with_egl}
if with_egl
  egl_drivers = []
  if with_dri
    egl_drivers += 'builtin:egl_dri2'
  endif
  if with_dri_platform == 'drm' or with_dri_platform == 'pseudo-drm'
    egl_drivers += 'builtin:egl_dri3'
  endif
  if with_platform_windows
    egl_drivers += 'builtin:wgl'
  endif
  egl_summary += {'Drivers': egl_drivers}
  egl_summary += {'Platforms': _platforms}
  egl_summary += {'Native platform': egl_native_platform}
endif
summary(egl_summary, section: 'EGL', bool_yn: true, list_sep: ' ')

gbm_summary = {'Enabled': with_gbm}
if with_gbm
  gbm_summary += {'External libgbm': get_option('libgbm-external'), 'Backends path': gbm_backends_path}
endif
summary(gbm_summary, section: 'GBM', bool_yn: true, list_sep: ' ')

vulkan_summary = {'Drivers': _vulkan_drivers.length() != 0 ? _vulkan_drivers : false }
if with_any_vk
  vulkan_summary += {'Platforms': _platforms}
  vulkan_summary += {'ICD dir': with_vulkan_icd_dir}
  if with_any_vulkan_layers
    vulkan_summary += {'Layers': get_option('vulkan-layers')}
  endif
  vulkan_summary += {'Intel Ray tracing': with_intel_vk_rt}
endif
summary(vulkan_summary, section: 'Vulkan', bool_yn: true, list_sep: ' ')

video_summary = {'Codecs': _codecs.length() != 0 ? _codecs : false}
video_apis = []
if with_gallium_va
  video_apis += 'va'
endif
if with_gallium_mediafoundation
  video_apis += 'mediafoundation'
endif
if with_any_vk
  video_apis += 'vulkan'
endif
video_summary += {'APIs': video_apis.length() != 0 ? video_apis : false}
video_summary += {'Encoding': with_video_encode}
summary(video_summary, section: 'Video', bool_yn: true, list_sep: ' ')

llvm_summary = {'Required': with_llvm}
if dep_llvm.found()
  llvm_summary += {'Version': dep_llvm.version()}
endif
summary(llvm_summary, section: 'LLVM', bool_yn: true, list_sep: ' ')

gallium_summary = {'Enabled': with_gallium}
if with_gallium
  gallium_summary += {'Drivers': gallium_drivers}
  gallium_summary += {'Platforms': _platforms}

  gallium_frontends = ['mesa']
  if with_gallium_va
    gallium_frontends += 'va'
  endif
  if with_gallium_mediafoundation
    gallium_frontends += 'mediafoundation'
  endif
  if with_gallium_rusticl
    gallium_frontends += 'rusticl'
  endif
  gallium_summary += {'Frontends': gallium_frontends}
  gallium_summary += {'Off-screen rendering (OSMesa)': with_osmesa ? 'lib' + osmesa_lib_name : false}
  gallium_summary += {'HUD lm-sensors': dep_lmsensors.found()}
  gallium_summary += {'GFX/Compute': with_gfx_compute}
endif
summary(gallium_summary, section: 'Gallium', bool_yn: true, list_sep: ' ')

perfetto_summary = {'Enabled': with_perfetto}
if with_perfetto and with_any_datasource
  perfetto_summary += {'Data source': with_datasources}
endif
summary(perfetto_summary, section: 'Perfetto', bool_yn: true, list_sep: ' ')

teflon_summary = {'Enabled': with_teflon}
summary(teflon_summary, section: 'Teflon (TensorFlow Lite delegate)', bool_yn: true, list_sep: ' ')

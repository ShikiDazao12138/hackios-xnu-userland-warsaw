# Copyright © 2017 Rob Clark
# SPDX-License-Identifier: MIT

files_libfreedreno = files(
  'driinfo_freedreno.h',
  'freedreno_autotune.c',
  'freedreno_autotune.h',
  'freedreno_batch.c',
  'freedreno_batch.h',
  'freedreno_batch_cache.c',
  'freedreno_batch_cache.h',
  'freedreno_blitter.c',
  'freedreno_blitter.h',
  'freedreno_context.c',
  'freedreno_context.h',
  'freedreno_draw.c',
  'freedreno_draw.h',
  'freedreno_fence.c',
  'freedreno_fence.h',
  'freedreno_gmem.c',
  'freedreno_gmem.h',
  'freedreno_program.c',
  'freedreno_program.h',
  'freedreno_query.c',
  'freedreno_query.h',
  'freedreno_query_acc.c',
  'freedreno_query_acc.h',
  'freedreno_query_hw.c',
  'freedreno_query_hw.h',
  'freedreno_query_sw.c',
  'freedreno_query_sw.h',
  'freedreno_resource.c',
  'freedreno_resource.h',
  'freedreno_screen.c',
  'freedreno_screen.h',
  'freedreno_state.c',
  'freedreno_state.h',
  'freedreno_texture.c',
  'freedreno_texture.h',
  'freedreno_util.c',
  'freedreno_util.h',
  'a2xx/fd2_blend.c',
  'a2xx/fd2_blend.h',
  'a2xx/fd2_context.c',
  'a2xx/fd2_context.h',
  'a2xx/fd2_draw.c',
  'a2xx/fd2_draw.h',
  'a2xx/fd2_emit.c',
  'a2xx/fd2_emit.h',
  'a2xx/fd2_gmem.c',
  'a2xx/fd2_gmem.h',
  'a2xx/fd2_program.c',
  'a2xx/fd2_program.h',
  'a2xx/fd2_query.c',
  'a2xx/fd2_query.h',
  'a2xx/fd2_rasterizer.c',
  'a2xx/fd2_rasterizer.h',
  'a2xx/fd2_resource.c',
  'a2xx/fd2_resource.h',
  'a2xx/fd2_screen.c',
  'a2xx/fd2_screen.h',
  'a2xx/fd2_texture.c',
  'a2xx/fd2_texture.h',
  'a2xx/fd2_util.c',
  'a2xx/fd2_util.h',
  'a2xx/fd2_zsa.c',
  'a2xx/fd2_zsa.h',
  'a2xx/ir2.c',
  'a2xx/ir2.h',
  'a2xx/ir2_assemble.c',
  'a2xx/ir2_cp.c',
  'a2xx/ir2_nir.c',
  'a2xx/ir2_private.h',
  'a2xx/ir2_ra.c',
  'a3xx/fd3_blend.c',
  'a3xx/fd3_blend.h',
  'a3xx/fd3_context.c',
  'a3xx/fd3_context.h',
  'a3xx/fd3_draw.c',
  'a3xx/fd3_draw.h',
  'a3xx/fd3_emit.c',
  'a3xx/fd3_emit.h',
  'a3xx/fd3_format.c',
  'a3xx/fd3_format.h',
  'a3xx/fd3_gmem.c',
  'a3xx/fd3_gmem.h',
  'a3xx/fd3_program.c',
  'a3xx/fd3_program.h',
  'a3xx/fd3_query.c',
  'a3xx/fd3_query.h',
  'a3xx/fd3_rasterizer.c',
  'a3xx/fd3_rasterizer.h',
  'a3xx/fd3_resource.c',
  'a3xx/fd3_resource.h',
  'a3xx/fd3_screen.c',
  'a3xx/fd3_screen.h',
  'a3xx/fd3_texture.c',
  'a3xx/fd3_texture.h',
  'a3xx/fd3_zsa.c',
  'a3xx/fd3_zsa.h',
  'a4xx/fd4_blend.c',
  'a4xx/fd4_blend.h',
  'a4xx/fd4_compute.c',
  'a4xx/fd4_compute.h',
  'a4xx/fd4_context.c',
  'a4xx/fd4_context.h',
  'a4xx/fd4_draw.c',
  'a4xx/fd4_draw.h',
  'a4xx/fd4_emit.c',
  'a4xx/fd4_emit.h',
  'a4xx/fd4_format.c',
  'a4xx/fd4_format.h',
  'a4xx/fd4_gmem.c',
  'a4xx/fd4_gmem.h',
  'a4xx/fd4_image.c',
  'a4xx/fd4_image.h',
  'a4xx/fd4_program.c',
  'a4xx/fd4_program.h',
  'a4xx/fd4_query.c',
  'a4xx/fd4_query.h',
  'a4xx/fd4_rasterizer.c',
  'a4xx/fd4_rasterizer.h',
  'a4xx/fd4_resource.c',
  'a4xx/fd4_resource.h',
  'a4xx/fd4_screen.c',
  'a4xx/fd4_screen.h',
  'a4xx/fd4_texture.c',
  'a4xx/fd4_texture.h',
  'a4xx/fd4_zsa.c',
  'a4xx/fd4_zsa.h',
  'a5xx/fd5_blend.c',
  'a5xx/fd5_blend.h',
  'a5xx/fd5_blitter.c',
  'a5xx/fd5_blitter.h',
  'a5xx/fd5_compute.c',
  'a5xx/fd5_compute.h',
  'a5xx/fd5_context.c',
  'a5xx/fd5_context.h',
  'a5xx/fd5_draw.c',
  'a5xx/fd5_draw.h',
  'a5xx/fd5_emit.c',
  'a5xx/fd5_emit.h',
  'a5xx/fd5_format.c',
  'a5xx/fd5_format.h',
  'a5xx/fd5_gmem.c',
  'a5xx/fd5_gmem.h',
  'a5xx/fd5_image.c',
  'a5xx/fd5_image.h',
  'a5xx/fd5_program.c',
  'a5xx/fd5_program.h',
  'a5xx/fd5_query.c',
  'a5xx/fd5_query.h',
  'a5xx/fd5_rasterizer.c',
  'a5xx/fd5_rasterizer.h',
  'a5xx/fd5_resource.c',
  'a5xx/fd5_resource.h',
  'a5xx/fd5_screen.c',
  'a5xx/fd5_screen.h',
  'a5xx/fd5_texture.c',
  'a5xx/fd5_texture.h',
  'a5xx/fd5_zsa.c',
  'a5xx/fd5_zsa.h',
  'a6xx/fd6_barrier.cc',
  'a6xx/fd6_barrier.h',
  'a6xx/fd6_blend.cc',
  'a6xx/fd6_blend.h',
  'a6xx/fd6_blitter.cc',
  'a6xx/fd6_blitter.h',
  'a6xx/fd6_compute.cc',
  'a6xx/fd6_compute.h',
  'a6xx/fd6_const.cc',
  'a6xx/fd6_const.h',
  'a6xx/fd6_context.cc',
  'a6xx/fd6_context.h',
  'a6xx/fd6_draw.cc',
  'a6xx/fd6_draw.h',
  'a6xx/fd6_emit.cc',
  'a6xx/fd6_emit.h',
  'a6xx/fd6_gmem.cc',
  'a6xx/fd6_gmem.h',
  'a6xx/fd6_image.cc',
  'a6xx/fd6_image.h',
  'a6xx/fd6_program.cc',
  'a6xx/fd6_program.h',
  'a6xx/fd6_query.cc',
  'a6xx/fd6_query.h',
  'a6xx/fd6_rasterizer.cc',
  'a6xx/fd6_rasterizer.h',
  'a6xx/fd6_resource.cc',
  'a6xx/fd6_resource.h',
  'a6xx/fd6_screen.cc',
  'a6xx/fd6_screen.h',
  'a6xx/fd6_texture.cc',
  'a6xx/fd6_texture.h',
  'a6xx/fd6_vsc.cc',
  'a6xx/fd6_vsc.h',
  'a6xx/fd6_zsa.cc',
  'a6xx/fd6_zsa.h',
  'ir3/ir3_cache.c',
  'ir3/ir3_cache.h',
  'ir3/ir3_const.h',
  'ir3/ir3_descriptor.c',
  'ir3/ir3_descriptor.h',
  'ir3/ir3_gallium.c',
  'ir3/ir3_gallium.h',
)

freedreno_tracepoints = custom_target(
  'freedreno_tracepoints.[ch]',
  input: 'freedreno_tracepoints.py',
  output: ['freedreno_tracepoints.c', 'freedreno_tracepoints.h'],
  command: [
    prog_python, '@INPUT@',
    '-p', join_paths(dir_source_root, 'src/util/perf/'),
    '-C', '@OUTPUT0@',
    '-H', '@OUTPUT1@',
  ],
  depend_files: u_trace_py,
)

files_libfreedreno += freedreno_tracepoints

freedreno_includes = [
  inc_src, inc_include, inc_gallium, inc_gallium_aux,
  inc_freedreno, include_directories('ir3'),
]

freedreno_c_args = [no_override_init_args]
freedreno_c_args += cc.get_supported_arguments([
  '-Wno-array-bounds',
  '-Wno-packed-bitfield-compat',
])

freedreno_cpp_args = []
freedreno_cpp_args += cpp.get_supported_arguments([
  '-DFD_BO_NO_HARDPIN=1',
  '-fno-exceptions',
  '-fno-rtti',
  '-Wno-address-of-packed-member',
  '-Wno-address-of-temporary',
  '-Wno-array-bounds',
  '-Wno-c++11-narrowing',
  '-Wno-c99-designator',
  '-Wno-missing-field-initializers',
  '-Wno-narrowing',
  '-Wno-overflow',
  '-Wno-packed-bitfield-compat',
  '-Wno-reorder',
  '-Wno-reorder-init-list',
  '-Wno-sign-compare',
  '-Wno-vla-cxx-extension',
])

libfreedreno_dependencies = [
  dep_libdrm,
  idep_mesautil,
  idep_nir_headers,
  idep_libfreedreno_common,
  idep_u_tracepoints,
]

if with_perfetto
  libfreedreno_dependencies += dep_perfetto
  files_libfreedreno += 'freedreno_perfetto.cc'
endif

# The header file ends up part of the build (but just a stub)
# in either case:
files_libfreedreno += 'freedreno_perfetto.h'

libfreedreno = static_library(
  'freedreno',
  [files_libfreedreno, freedreno_xml_header_files],
  include_directories : freedreno_includes,
  c_args : [freedreno_c_args],
  cpp_args : [freedreno_cpp_args],
  gnu_symbol_visibility : 'hidden',
  dependencies : libfreedreno_dependencies,
)

driver_freedreno = declare_dependency(
  compile_args : '-DGALLIUM_FREEDRENO',
  link_with : [
    libfreedrenowinsys,
    libfreedreno,
    libfreedreno_drm,
    libfreedreno_ir2,
    libfreedreno_ir3,
    libfreedreno_layout,
    libfreedreno_perfcntrs
  ],
  dependencies : [
    idep_nir,
    idep_xmlconfig,
  ],
)

# air_run: draw with a Metal shader and read the pixels back. It lives here,
# beside ir3_compiler, because this is where libgallium exists; its source is
# with the rest of the frontend in src/compiler/air.
air_run = executable(
  'air_run',
  files('../../../compiler/air/air_run.c'),
  include_directories : [inc_include, inc_src, include_directories('../../../mesa/glapi'), inc_mesa, inc_gallium,
                         inc_gallium_aux, inc_gallium_winsys_sw, inc_gallium_winsys,
                         include_directories('../../drivers')],
  dependencies : [dep_m, idep_air, idep_mesautil, driver_softpipe, driver_freedreno,
                  dep_libdrm],
  link_with : [libgallium, libgalliumvl_stub, libws_null, libfreedrenowinsys],
  build_by_default : false,
  install : false,
)

# libannibaleair: the same path air_run takes -- a Metal shader through the AIR frontend
# into a compute state and a grid on the Adreno -- as a shared library, for the Metal
# driver in userland/src/annibalemetal.m. Its contract is src/compiler/air/air_metal.h and
# mentions nothing of Mesa; this is only where it is built, beside air_run and for the
# same reason, that libgallium exists here and not where the frontend is read. The
# dependencies are deliberately air_run's: a driver that links this gets the path the
# harness measured, not a second one assembled for it.
annibaleair_link_args = []
if host_machine.system() == 'darwin'
  # the Metal driver links against this by name, so the name has to be where
  # tools/mk-mesa.sh installs it on the device
  annibaleair_link_args += '-Wl,-install_name,/annibale/lib/libannibaleair.dylib'
endif

libannibaleair = shared_library(
  'annibaleair',
  files('../../../compiler/air/air_metal.c'),
  include_directories : [inc_include, inc_src, include_directories('../../../mesa/glapi'), inc_mesa, inc_gallium,
                         inc_gallium_aux, inc_gallium_winsys_sw, inc_gallium_winsys,
                         include_directories('../../drivers')],
  dependencies : [dep_m, idep_air, idep_mesautil, driver_softpipe, driver_freedreno,
                  dep_libdrm],
  link_with : [libgallium, libgalliumvl_stub, libws_null, libfreedrenowinsys],
  link_args : annibaleair_link_args,
  build_by_default : false,
  install : false,
)

# air_metal_test: the library driven the way the driver will drive it, on softpipe. It is
# given the frontend's include directory and nothing else, so that a call the contract
# does not provide shows up as a test that cannot be written.
air_metal_test = executable(
  'air_metal_test',
  files('../../../compiler/air/air_metal_test.c'),
  include_directories : include_directories('../../../compiler/air'),
  link_with : [libannibaleair],
  build_by_default : false,
  install : false,
)

gmemtool = executable(
  'gmemtool',
  [
    'gmemtool.c',
    freedreno_tracepoints[1],
    freedreno_xml_header_files,
  ],
  include_directories : freedreno_includes,
  dependencies : [
    idep_nir,
    idep_mesautil,
    idep_u_tracepoints,
    idep_xmlconfig,
  ],
  link_with : [
    libfreedreno,
    libfreedreno_drm,
    libfreedreno_ir2,
    libfreedreno_ir3,
    libfreedreno_layout,
    libgallium,
    libglsl_standalone,
    libfreedreno_perfcntrs,
  ],
  build_by_default : with_tools.contains('freedreno'),
  install : false,
)

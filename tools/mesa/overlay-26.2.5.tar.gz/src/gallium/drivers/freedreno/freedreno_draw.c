/*
 * Copyright © 2012 Rob Clark <robclark@freedesktop.org>
 * SPDX-License-Identifier: MIT
 *
 * Authors:
 *    Rob Clark <robclark@freedesktop.org>
 */

#include "pipe/p_state.h"
#include "util/format/u_format.h"
#include "util/u_draw.h"
#include "util/u_helpers.h"
#include "util/u_memory.h"
#include "util/u_prim.h"
#include "util/perf_draw.h"
#include "util/u_string.h"

#include "freedreno_blitter.h"
#include "freedreno_context.h"
#include "freedreno_draw.h"
#include "freedreno_fence.h"
#include "freedreno_query_acc.h"
#include "freedreno_query_hw.h"
#include "freedreno_resource.h"
#include "freedreno_state.h"
#include "freedreno_util.h"

/* How many calls arrive at the driver's entry, and how many of those return before anything is
 * emitted. The layer in front times the call and owns the difference. */
unsigned fd_perf_entry_calls, fd_perf_entry_cond, fd_perf_entry_multi;
uint64_t fd_perf_checks_sum, fd_perf_checks_seen, fd_perf_checks_worst;

static uint64_t
fd_perf_clock_us(void)
{
   return (uint64_t) (os_time_get_nano() / 1000);
}

static bool
batch_references_resource(struct fd_batch *batch, struct pipe_resource *prsc)
   assert_dt
{
   return fd_batch_references_resource(batch, fd_resource(prsc));
}

static void
resource_read(struct fd_batch *batch, struct pipe_resource *prsc) assert_dt
{
   if (!prsc)
      return;
   fd_batch_resource_read(batch, fd_resource(prsc));
}

static void
resource_written(struct fd_batch *batch, struct pipe_resource *prsc) assert_dt
{
   if (!prsc)
      return;
   fd_batch_resource_write(batch, fd_resource(prsc));
}

/*
 * HackiOS: whether a draw with the bound blend state can write colour attachment i. One that cannot
 * is not stored at the end of the batch: CoreAnimation's full-screen pass binds a second, RGBA16Float
 * attachment that its pipeline masks off (writeMask 0), and storing it was a fifth of the window
 * server's GPU time (docs/analysis/2026-11-02-120hz-after-gpu-clock.md).
 */
static bool
cbuf_written(struct fd_context *ctx, unsigned i) assert_dt
{
   const struct pipe_blend_state *blend = ctx->blend;

   return !blend || blend->rt[blend->independent_blend_enable ? i : 0].colormask != 0;
}

static void
batch_draw_tracking_for_dirty_bits(struct fd_batch *batch) assert_dt
{
   struct fd_context *ctx = batch->ctx;
   struct pipe_framebuffer_state *pfb = &batch->framebuffer;
   enum fd_dirty_3d_state dirty = ctx->dirty_resource;
   unsigned buffers = 0, restore_buffers = 0;

   if (dirty & (FD_DIRTY_FRAMEBUFFER | FD_DIRTY_ZSA)) {
      if (fd_depth_enabled(ctx)) {
         if (fd_resource(pfb->zsbuf.texture)->valid) {
            restore_buffers |= FD_BUFFER_DEPTH;
            /* storing packed d/s depth also stores stencil, so we need
             * the stencil restored too to avoid invalidating it.
             */
            if (pfb->zsbuf.texture->format == PIPE_FORMAT_Z24_UNORM_S8_UINT)
               restore_buffers |= FD_BUFFER_STENCIL;
         } else {
            batch->invalidated |= FD_BUFFER_DEPTH;
         }
         batch->gmem_reason |= FD_GMEM_DEPTH_ENABLED;
         if (fd_depth_write_enabled(ctx)) {
            buffers |= FD_BUFFER_DEPTH;
            resource_written(batch, pfb->zsbuf.texture);
         } else {
            resource_read(batch, pfb->zsbuf.texture);
         }
      }

      if (fd_stencil_enabled(ctx)) {
         if (fd_resource(pfb->zsbuf.texture)->valid) {
            restore_buffers |= FD_BUFFER_STENCIL;
            /* storing packed d/s stencil also stores depth, so we need
             * the depth restored too to avoid invalidating it.
             */
            if (pfb->zsbuf.texture->format == PIPE_FORMAT_Z24_UNORM_S8_UINT)
               restore_buffers |= FD_BUFFER_DEPTH;
         } else {
            batch->invalidated |= FD_BUFFER_STENCIL;
         }
         batch->gmem_reason |= FD_GMEM_STENCIL_ENABLED;
         buffers |= FD_BUFFER_STENCIL;
         resource_written(batch, pfb->zsbuf.texture);
      }
   }

   if (dirty & (FD_DIRTY_FRAMEBUFFER | FD_DIRTY_BLEND)) {
      for (unsigned i = 0; i < pfb->nr_cbufs; i++) {
         struct pipe_resource *surf;

         if (!pfb->cbufs[i].texture)
            continue;

         surf = pfb->cbufs[i].texture;

         if (fd_resource(surf)->valid) {
            restore_buffers |= PIPE_CLEAR_COLOR0 << i;
         } else {
            batch->invalidated |= PIPE_CLEAR_COLOR0 << i;
         }

         /* (still restored above: a framebuffer fetch may read it) */
         if (!cbuf_written(ctx, i)) {
            resource_read(batch, surf);
            continue;
         }

         buffers |= PIPE_CLEAR_COLOR0 << i;

         resource_written(batch, pfb->cbufs[i].texture);
      }
   }

   if (dirty & (FD_DIRTY_CONST | FD_DIRTY_TEX | FD_DIRTY_SSBO | FD_DIRTY_IMAGE)) {
      u_foreach_bit (s, ctx->bound_shader_stages) {
         enum fd_dirty_shader_state dirty_shader = ctx->dirty_shader_resource[s];

         /* Mark constbuf as being read: */
         if (dirty_shader & FD_DIRTY_SHADER_CONST) {
            u_foreach_bit (i, ctx->constbuf[s].enabled_mask)
               resource_read(batch, ctx->constbuf[s].cb[i].buffer);
         }

         /* Mark textures as being read */
         if (dirty_shader & FD_DIRTY_SHADER_TEX) {
            u_foreach_bit (i, ctx->tex[s].valid_textures)
               resource_read(batch, ctx->tex[s].textures[i]->texture);
         }

         /* Mark SSBOs as being read or written: */
         if (dirty_shader & FD_DIRTY_SHADER_SSBO) {
            const struct fd_shaderbuf_stateobj *so = &ctx->shaderbuf[s];

            u_foreach_bit (i, so->enabled_mask & so->writable_mask)
               resource_written(batch, so->sb[i].buffer);

            u_foreach_bit (i, so->enabled_mask & ~so->writable_mask)
               resource_read(batch, so->sb[i].buffer);
         }

         /* Mark Images as being read or written: */
         if (dirty_shader & FD_DIRTY_SHADER_IMAGE) {
            u_foreach_bit (i, ctx->shaderimg[s].enabled_mask) {
               struct pipe_image_view *img = &ctx->shaderimg[s].si[i];
               if (img->access & PIPE_IMAGE_ACCESS_WRITE)
                  resource_written(batch, img->resource);
               else
                  resource_read(batch, img->resource);
            }
         }
      }
   }

   /* Mark VBOs as being read */
   if (dirty & FD_DIRTY_VTXBUF) {
      u_foreach_bit (i, ctx->vtx.vertexbuf.enabled_mask) {
         assert(!ctx->vtx.vertexbuf.vb[i].is_user_buffer);
         resource_read(batch, ctx->vtx.vertexbuf.vb[i].buffer.resource);
      }
   }

   /* Mark streamout buffers as being written.. */
   if (dirty & FD_DIRTY_STREAMOUT) {
      for (unsigned i = 0; i < ctx->streamout.num_targets; i++) {
         struct fd_stream_output_target *target =
            fd_stream_output_target(ctx->streamout.targets[i]);

         if (target) {
            resource_written(batch, target->base.buffer);
            resource_written(batch, target->offset_buf);
         }
      }
   }

   if (dirty & FD_DIRTY_QUERY) {
      list_for_each_entry (struct fd_acc_query, aq, &ctx->acc_active_queries, node) {
         resource_written(batch, aq->prsc);
      }
   }

   /* any buffers that haven't been cleared yet, we need to restore: */
   batch->restore |= restore_buffers & (FD_BUFFER_ALL & ~batch->invalidated);
   /* and any buffers used, need to be resolved: */
   batch->resolve |= buffers;
}

static bool
needs_draw_tracking(struct fd_batch *batch, const struct pipe_draw_info *info,
                    const struct pipe_draw_indirect_info *indirect)
   assert_dt
{
   struct fd_context *ctx = batch->ctx;

   if (ctx->dirty_resource)
      return true;

   if (info->index_size && !batch_references_resource(batch, info->index.resource))
      return true;

   if (indirect) {
      if (indirect->buffer && !batch_references_resource(batch, indirect->buffer))
         return true;
      if (indirect->indirect_draw_count &&
          !batch_references_resource(batch, indirect->indirect_draw_count))
         return true;
      if (indirect->count_from_stream_output)
         return true;
   }

   return false;
}

static void
batch_draw_tracking(struct fd_batch *batch, const struct pipe_draw_info *info,
                    const struct pipe_draw_indirect_info *indirect) assert_dt
{
   struct fd_context *ctx = batch->ctx;

   if (!needs_draw_tracking(batch, info, indirect))
      goto out;

   /*
    * Figure out the buffers/features we need:
    */

   fd_screen_lock(ctx->screen);

   if (ctx->dirty_resource)
      batch_draw_tracking_for_dirty_bits(batch);

   /* Mark index buffer as being read */
   if (info->index_size)
      resource_read(batch, info->index.resource);

   /* Mark indirect draw buffer as being read */
   if (indirect) {
      resource_read(batch, indirect->buffer);
      resource_read(batch, indirect->indirect_draw_count);
      if (indirect->count_from_stream_output)
         resource_read(
            batch, fd_stream_output_target(indirect->count_from_stream_output)
                      ->offset_buf);
   }

   resource_written(batch, batch->query_buf);

   fd_screen_unlock(ctx->screen);

out:
   fd_batch_update_queries(batch);
}

static void
update_draw_stats(struct fd_context *ctx, const struct pipe_draw_info *info,
                  const struct pipe_draw_start_count_bias *draws,
                  unsigned num_draws) assert_dt
{
   ctx->stats.draw_calls++;

   if (ctx->screen->gen < 6) {
      /* Counting prims in sw doesn't work for GS and tesselation. For older
       * gens we don't have those stages and don't have the hw counters enabled,
       * so keep the count accurate for non-patch geometry.
       */
      unsigned prims = 0;
      if ((info->mode != MESA_PRIM_PATCHES) && (info->mode != MESA_PRIM_COUNT)) {
         for (unsigned i = 0; i < num_draws; i++) {
            prims += u_reduced_prims_for_vertices(info->mode, draws[i].count);
         }
      }

      ctx->stats.prims_generated += prims;

      if (ctx->streamout.num_targets > 0) {
         /* Clip the prims we're writing to the size of the SO buffers. */
         enum mesa_prim tf_prim = u_decomposed_prim(info->mode);
         unsigned verts_written = u_vertices_for_prims(tf_prim, prims);
         unsigned remaining_vert_space =
            ctx->streamout.max_tf_vtx - ctx->streamout.verts_written;
         if (verts_written > remaining_vert_space) {
            verts_written = remaining_vert_space;
            u_trim_pipe_prim(tf_prim, &remaining_vert_space);
         }
         ctx->streamout.verts_written += verts_written;

         ctx->stats.prims_emitted +=
            u_reduced_prims_for_vertices(tf_prim, verts_written);
      }
   }
}

/* A call that returns before the batch dispatch has none of the three points below in it, and one
 * the layer in front measured at half a second has to leave a trace somewhere: five such returns sit
 * before the dispatch, and the time they spend in util_draw_indirect, in the condition check or in
 * the user index upload is exactly what no window records. Same fields as the tail's line, with
 * `call` and `tail` at 0 because neither happened. */
static void
fd_draw_early(const char *branch, uint64_t began)
{
   uint64_t total = fd_perf_us() - began;

   if (total > 50000) {
      printf("fd draw early: %s prologue %llu call 0 tail 0 total %llu us\n", branch,
             (unsigned long long) total, (unsigned long long) total);
      fflush(stdout);
   }
}

static void
fd_draw_vbo(struct pipe_context *pctx, const struct pipe_draw_info *info,
            unsigned drawid_offset,
            const struct pipe_draw_indirect_info *indirect,
            const struct pipe_draw_start_count_bias *draws, unsigned num_draws) in_dt
{
   struct fd_context *ctx = fd_context(pctx);

   /* Three points across the call, because the perf window's entry and exit cover only the middle
    * one: a draw the layer in front reported as 1,374,219 us while this function's own figures were
    * in the tens of milliseconds leaves the prologue (condition check, index upload, a flush the
    * batch size forces) and the tail as the only places left. */
   static uint64_t fd_draw_call_count;

   uint64_t fd_draw_began = fd_perf_us();
   uint64_t fd_draw_called = 0, fd_draw_returned = 0;

   /* Every 1000th call, so that a round with no slow line can tell "the probe never ran" from "it
    * ran and every call was quick". */
   if (++fd_draw_call_count % 1000 == 0) {
      printf("fd draw calls %llu\n", (unsigned long long) fd_draw_call_count);
      fflush(stdout);
   }

   /* Counted, not timed: a call that returns before anything is emitted still costs the layer in
    * front, and telling those apart settles why the call site reports far more time than this
    * function does. */
   fd_perf_entry_calls++;
   if (fd_perf_on()) {
      memset(&fd_perf_current, 0, sizeof(fd_perf_current));
      fd_perf_current.entry = fd_perf_us();
   }

   /* for debugging problems with indirect draw, it is convenient
    * to be able to emulate it, to determine if game is feeding us
    * bogus data:
    */
   if (indirect && indirect->buffer && FD_DBG(NOINDR)) {
      /* num_draws is only applicable for direct draws: */
      assert(num_draws == 1);
      fd_draw_early("indirect", fd_draw_began);
      util_draw_indirect(pctx, info, drawid_offset, indirect);
      return;
   }

   /* TODO: push down the region versions into the tiles */
   if (!fd_render_condition_check(pctx)) {
      fd_draw_early("cond", fd_draw_began);
      fd_perf_entry_cond++;
      return;
   }

   /* Upload a user index buffer. */
   struct pipe_resource *indexbuf = NULL;
   unsigned index_offset = 0;
   struct pipe_draw_info new_info;
   if (info->index_size) {
      if (info->has_user_indices) {
         if (num_draws > 1) {
            fd_draw_early("multi", fd_draw_began);
            util_draw_multi(pctx, info, drawid_offset, indirect, draws, num_draws);
            return;
         }
         if (!util_upload_index_buffer(pctx, info, &draws[0], &indexbuf,
                                       &index_offset, 4))
            fd_draw_early("indexbuf", fd_draw_began);
            return;
         new_info = *info;
         new_info.index.resource = indexbuf;
         new_info.has_user_indices = false;
         info = &new_info;
      } else {
         indexbuf = info->index.resource;
      }
   }

   if ((ctx->streamout.num_targets > 0) && (num_draws > 1)) {
      fd_draw_early("streamout", fd_draw_began);
      fd_perf_entry_multi++;
      util_draw_multi(pctx, info, drawid_offset, indirect, draws, num_draws);
      return;
   }

   struct fd_batch *batch = fd_context_batch_draw(ctx);

   batch_draw_tracking(batch, info, indirect);
   if (fd_perf_on())
      fd_perf_current.track = fd_perf_us();

   while (unlikely(batch->flushed)) {
      /* The current batch was flushed in batch_draw_tracking()
       * so start anew.  We know this won't happen a second time
       * since we are dealing with a fresh batch:
       */
      fd_batch_reference(&batch, NULL);
      batch = fd_context_batch_draw(ctx);
      batch_draw_tracking(batch, info, indirect);
      assert(ctx->batch == batch);
   }

   batch->num_draws++;
   batch->subpass->num_draws++;

   fd_print_dirty_state(ctx->dirty);

   /* Marking the batch as needing flush must come after the batch
    * dependency tracking (resource_read()/resource_write()), as that
    * can trigger a flush
    */
   fd_batch_needs_flush(batch);

   struct pipe_framebuffer_state *pfb = &batch->framebuffer;
   DBG("%p: %ux%u num_draws=%u (%s/%s)", batch, pfb->width, pfb->height,
       batch->num_draws,
       util_format_short_name(pipe_surface_format(&pfb->cbufs[0])),
       util_format_short_name(pipe_surface_format(&pfb->zsbuf)));

   batch->cost += ctx->draw_cost;

   fd_draw_called = fd_perf_us();
   ctx->draw_vbos(ctx, info, drawid_offset, indirect, draws, num_draws, index_offset);
   fd_draw_returned = fd_perf_us();
   if (fd_perf_on()) {
      fd_perf_current.exit = fd_perf_us();
      fd_perf_note_driver(&fd_perf_current);
   }

   if (unlikely(ctx->stats_users > 0))
      update_draw_stats(ctx, info, draws, num_draws);

   for (unsigned i = 0; i < ctx->streamout.num_targets; i++) {
      assert(num_draws == 1);
      ctx->streamout.offsets[i] += draws[0].count;
   }

   assert(!batch->flushed);

   /* Whether a slow draw waits or computes: fd_batch_check_size submits the batch when it is full, so
    * the time it costs is waiting for a submit to be accepted, and the time after it is the driver
    * thread's own work. Two sums are enough to tell the two apart. */
   {
      static uint64_t check_sum, check_worst;

      uint64_t began = fd_perf_clock_us();
      fd_batch_check_size(batch);
      uint64_t took = fd_perf_clock_us() - began;

      check_sum += took;
      if (took > check_worst)
         check_worst = took;
      /* One line the moment a check itself is the slow part: the window's figure divides the sum by
       * its frames and keeps the worst across the run, so a single 1.37 s wait among hundreds of
       * draws cannot be read back out of it without the batch it happened in. */
      if (fd_perf_on() && took > 50000) {
         printf("fd batch check slow: %llu us (cost %u, size %u)\n", (unsigned long long) took,
                batch->cost, batch->num_draws);
         fflush(stdout);
      }
      fd_perf_checks_sum += check_sum - fd_perf_checks_seen;
      fd_perf_checks_seen = check_sum;
      if (check_worst > fd_perf_checks_worst)
         fd_perf_checks_worst = check_worst;
   }
   fd_batch_reference(&batch, NULL);

   if (info == &new_info)
      pipe_resource_reference(&indexbuf, NULL);

   {
      uint64_t ended = fd_perf_us();
      uint64_t total = ended - fd_draw_began;

      if (total > 50000) {
         printf("fd draw slow: prologue %llu call %llu tail %llu total %llu us\n",
                (unsigned long long)(fd_draw_called - fd_draw_began),
                (unsigned long long)(fd_draw_returned - fd_draw_called),
                (unsigned long long)(ended - fd_draw_returned), (unsigned long long)total);
         fflush(stdout);
      }
   }
}

/* Nothing here reads the frame's state off this thread: the driver thread writes it and the flush on
 * this thread closes it, which is also where a slow frame gets its line.
 */
struct fd_perf_frame fd_perf_client, fd_perf_driver;
struct fd_perf_draw fd_perf_current;
struct fd_perf_window fd_perf_win;
unsigned fd_perf_progs, fd_perf_variants;
unsigned fd_perf_cache_misses;
unsigned fd_perf_slow_us = FD_PERF_SLOW_US;
uint64_t fd_perf_checks_sum, fd_perf_checks_seen, fd_perf_checks_worst;

/* How many calls arrive at the driver's entry, and how many of those return before anything is
 * emitted. The layer in front times the call and owns the difference. */


/* One line per FD_PERF_WINDOW frames, from the driver thread, covering both threads' figures. The
 * frame interval is measured between two closes on the driver thread, which is the same clock the
 * kernel's tl: lines use, so it can be checked against them. */
void
fd_perf_window_add(uint64_t now, const struct fd_perf_frame *f)
{
   struct fd_perf_window *w = &fd_perf_win;

   if (f == &fd_perf_client) {
      /* the client closes once per frame too; its totals ride along in the driver's line */
      w->client += f->wait;
      if (f->wait > w->max_client)
         w->max_client = f->wait;
      return;
   }

   {
      static unsigned seen_in, seen_cond, seen_multi;

      static unsigned seen_progs, seen_variants, seen_misses;

      w->calls += fd_perf_entry_calls - seen_in;
      w->calls_cond += fd_perf_entry_cond - seen_cond;
      w->calls_multi += fd_perf_entry_multi - seen_multi;
      seen_in = fd_perf_entry_calls;
      seen_cond = fd_perf_entry_cond;
      seen_multi = fd_perf_entry_multi;
      /* Calls against variant creations is the reuse question: as many variants as calls means the
       * cache never answers twice, far fewer means it does and the cost is the lookup. */
      w->prog_calls += fd_perf_progs - seen_progs;
      w->prog_variants += fd_perf_variants - seen_variants;
      w->prog_builds += fd_perf_cache_misses - seen_misses;
      seen_progs = fd_perf_progs;
      seen_variants = fd_perf_variants;
      seen_misses = fd_perf_cache_misses;
   }
   w->frames++;
   w->draws += f->draws;
   w->driver += f->driver;
   if (f->driver > w->max_driver)
      w->max_driver = f->driver;
   w->own += f->drawn + f->emit + f->prog + f->track;
   w->track += f->track;
   w->prog += f->prog;
   w->emit += f->emit;
   w->draw += f->drawn;
   if (w->last_close) {
      uint64_t took = now - w->last_close;
      static uint64_t first_gap, sum_gap, first_now;
      static unsigned long total_flushes;

      w->interval += took;
      if (took > w->max_interval)
         w->max_interval = took;

      /* The gaps between one flush and the next have to add up to the time the process spent
       * flushing at all. If they do not, the window is not counting what it claims and every rate
       * derived from this line is wrong, which is cheap to check here and expensive to discover
       * from an analysis three rounds later. */
      if (!first_now)
         first_now = now;
      if (!first_gap)
         first_gap = now;
      sum_gap += took;
      if (++total_flushes % 1024 == 0) {
         uint64_t span = now - first_now;
         long off = span ? (long) (((sum_gap * 100) / span) - 100) : 0;

         printf("perf flush totals: %lu flushes, gaps %llu us of %llu us span, off by %ld%%\n",
                total_flushes, (unsigned long long) sum_gap, (unsigned long long) span, off);
      }
   }
   w->last_close = now;

   if (w->frames < FD_PERF_WINDOW)
      return;

   printf("perf flush %u: %llu us/flush max %llu; %llu draws; batch submit %llu max %llu us; "
          "driver %llu max %llu; "
          "own %llu (track %llu prog %llu emit %llu draw %llu); submit %llu max %llu; "
          "client %llu max %llu; sync %llu max %llu, pass %llu max %llu; calls %llu in "
          "(condition %llu, multi %llu); prog_calls %llu prog_variants %llu prog_builds %llu us\n",
          w->frames, (unsigned long long) (w->interval / w->frames),
          (unsigned long long) w->max_interval,
          (unsigned long long) (w->draws / w->frames),
          (unsigned long long) (fd_perf_checks_sum / w->frames),
          (unsigned long long) fd_perf_checks_worst,
          (unsigned long long) (w->driver / w->frames), (unsigned long long) w->max_driver,
          (unsigned long long) (w->own / w->frames),
          (unsigned long long) (w->track / w->frames), (unsigned long long) (w->prog / w->frames),
          (unsigned long long) (w->emit / w->frames), (unsigned long long) (w->draw / w->frames),
          (unsigned long long) (w->submit / w->frames), (unsigned long long) w->max_submit,
          (unsigned long long) (w->client / w->frames), (unsigned long long) w->max_client,
          (unsigned long long) (w->sync / w->frames), (unsigned long long) w->max_sync,
          (unsigned long long) (w->pass / w->frames), (unsigned long long) w->max_pass,
          (unsigned long long) (w->calls / w->frames),
          (unsigned long long) (w->calls_cond / w->frames),
          (unsigned long long) (w->calls_multi / w->frames),
          (unsigned long long) (w->prog_calls / w->frames),
          (unsigned long long) (w->prog_variants / w->frames),
          (unsigned long long) (w->prog_builds / w->frames));
   fflush(stdout);
   memset(w, 0, sizeof(*w));
   /* The window resets its counters; the time of the last close has to survive, or the first gap
    * of the next window is lost and the gaps no longer add up to the span. */
   w->last_close = now;
}

/* This file's draw entry, published so the layer in front can say which function a pipe actually
 * dispatches to; the two timings disagree and naming the target is what tells them apart. */
void *fd_perf_draw_vbo_symbol = (void *)fd_draw_vbo;

/* tc_sync_msg: waiting for the driver thread to drain what the client queued. */
void
fd_perf_window_sync(uint64_t began)
{
   uint64_t took = fd_perf_us() - began;

   fd_perf_win.sync += took;
   if (took > fd_perf_win.max_sync)
      fd_perf_win.max_sync = took;
}

/* The rest of tc_flush before the driver's own flush is entered. */
void
fd_perf_window_pass(uint64_t began)
{
   uint64_t took = fd_perf_us() - began;

   fd_perf_win.pass += took;
   if (took > fd_perf_win.max_pass)
      fd_perf_win.max_pass = took;
}

/* fd_context_flush, submit ioctl included. */
void
fd_perf_window_submit(uint64_t began)
{
   uint64_t took = fd_perf_us() - began;

   fd_perf_win.submit += took;
   if (took > fd_perf_win.max_submit)
      fd_perf_win.max_submit = took;
}

static void
fd_draw_vbo_dbg(struct pipe_context *pctx, const struct pipe_draw_info *info,
                unsigned drawid_offset,
                const struct pipe_draw_indirect_info *indirect,
                const struct pipe_draw_start_count_bias *draws, unsigned num_draws)
   in_dt
{
   fd_draw_vbo(pctx, info, drawid_offset, indirect, draws, num_draws);

   if (FD_DBG(DDRAW))
      fd_context_all_dirty(fd_context(pctx));

   if (FD_DBG(FLUSH))
      pctx->flush(pctx, NULL, 0);
}

static void
batch_clear_tracking(struct fd_batch *batch, unsigned buffers) assert_dt
{
   struct fd_context *ctx = batch->ctx;
   struct pipe_framebuffer_state *pfb = &batch->framebuffer;
   unsigned cleared_buffers;

   /* pctx->clear() is only for full-surface clears, so scissor is
    * equivalent to having GL_SCISSOR_TEST disabled:
    */
   batch->max_scissor.minx = 0;
   batch->max_scissor.miny = 0;
   batch->max_scissor.maxx = pfb->width - 1;
   batch->max_scissor.maxy = pfb->height - 1;

   /* for bookkeeping about which buffers have been cleared (and thus
    * can fully or partially skip mem2gmem) we need to ignore buffers
    * that have already had a draw, in case apps do silly things like
    * clear after draw (ie. if you only clear the color buffer, but
    * something like alpha-test causes side effects from the draw in
    * the depth buffer, etc)
    */
   cleared_buffers = buffers & (FD_BUFFER_ALL & ~batch->restore);
   batch->cleared |= buffers;
   batch->invalidated |= cleared_buffers;

   batch->resolve |= buffers;

   fd_screen_lock(ctx->screen);

   if (buffers & PIPE_CLEAR_COLOR)
      for (unsigned i = 0; i < pfb->nr_cbufs; i++)
         if (buffers & (PIPE_CLEAR_COLOR0 << i))
            resource_written(batch, pfb->cbufs[i].texture);

   if (buffers & (PIPE_CLEAR_DEPTH | PIPE_CLEAR_STENCIL)) {
      resource_written(batch, pfb->zsbuf.texture);
      batch->gmem_reason |= FD_GMEM_CLEARS_DEPTH_STENCIL;
   }

   resource_written(batch, batch->query_buf);

   list_for_each_entry (struct fd_acc_query, aq, &ctx->acc_active_queries, node)
      resource_written(batch, aq->prsc);

   fd_screen_unlock(ctx->screen);
}

static void
fd_clear(struct pipe_context *pctx, unsigned buffers,
         uint32_t color_clear_mask, uint8_t stencil_clear_mask,
         const struct pipe_scissor_state *scissor_state,
         const union pipe_color_union *color, double depth,
         unsigned stencil) in_dt
{
   struct fd_context *ctx = fd_context(pctx);

   /* TODO: push down the region versions into the tiles */
   if (!fd_render_condition_check(pctx))
      return;

   struct fd_batch *batch = fd_context_batch_draw(ctx);

   batch_clear_tracking(batch, buffers);

   while (unlikely(batch->flushed)) {
      /* The current batch was flushed in batch_clear_tracking()
       * so start anew.  We know this won't happen a second time
       * since we are dealing with a fresh batch:
       */
      fd_batch_reference(&batch, NULL);
      batch = fd_context_batch_draw(ctx);
      batch_clear_tracking(batch, buffers);
      assert(ctx->batch == batch);
   }

   /* Marking the batch as needing flush must come after the batch
    * dependency tracking (resource_read()/resource_write()), as that
    * can trigger a flush
    */
   fd_batch_needs_flush(batch);

   struct pipe_framebuffer_state *pfb = &batch->framebuffer;
   DBG("%p: %x %ux%u depth=%f, stencil=%u (%s/%s)", batch, buffers, pfb->width,
       pfb->height, depth, stencil,
       util_format_short_name(pipe_surface_format(&pfb->cbufs[0])),
       util_format_short_name(pipe_surface_format(&pfb->zsbuf)));

   /* if per-gen backend doesn't implement ctx->clear() generic
    * blitter clear:
    */
   bool fallback = true;

   if (ctx->clear) {
      fd_batch_update_queries(batch);

      if (ctx->clear(ctx, buffers, color, depth, stencil)) {
         if (FD_DBG(DCLEAR))
            fd_context_all_dirty(ctx);

         fallback = false;
      }
   }

   assert(!batch->flushed);

   if (fallback) {
      fd_blitter_clear(pctx, buffers, color, depth, stencil);
   }

   fd_batch_check_size(batch);

   fd_batch_reference(&batch, NULL);
}

static void
fd_clear_render_target(struct pipe_context *pctx, struct pipe_surface *ps,
                       const union pipe_color_union *color, unsigned x,
                       unsigned y, unsigned w, unsigned h,
                       bool render_condition_enabled) in_dt
{
   if (render_condition_enabled && !fd_render_condition_check(pctx))
      return;

   fd_blitter_clear_render_target(pctx, ps, color, x, y, w, h,
                                  render_condition_enabled);
}

static void
fd_clear_depth_stencil(struct pipe_context *pctx, struct pipe_surface *ps,
                       unsigned buffers, double depth, unsigned stencil,
                       unsigned x, unsigned y, unsigned w, unsigned h,
                       bool render_condition_enabled) in_dt
{
   if (render_condition_enabled && !fd_render_condition_check(pctx))
      return;

   fd_blitter_clear_depth_stencil(pctx, ps, buffers,
                                  depth, stencil, x, y, w, h,
                                  render_condition_enabled);
}

static void
fd_launch_grid(struct pipe_context *pctx,
               const struct pipe_grid_info *info) in_dt
{
   struct fd_context *ctx = fd_context(pctx);
   const struct fd_shaderbuf_stateobj *so =
      &ctx->shaderbuf[MESA_SHADER_COMPUTE];
   struct fd_batch *batch, *save_batch = NULL;

   if (!fd_render_condition_check(pctx))
      return;

   batch = fd_context_batch_nondraw(ctx);
   fd_batch_reference(&save_batch, ctx->batch);
   fd_batch_reference(&ctx->batch, batch);

   fd_screen_lock(ctx->screen);

   /* Mark SSBOs */
   u_foreach_bit (i, so->enabled_mask & so->writable_mask)
      resource_written(batch, so->sb[i].buffer);

   u_foreach_bit (i, so->enabled_mask & ~so->writable_mask)
      resource_read(batch, so->sb[i].buffer);

   u_foreach_bit (i, ctx->shaderimg[MESA_SHADER_COMPUTE].enabled_mask) {
      struct pipe_image_view *img = &ctx->shaderimg[MESA_SHADER_COMPUTE].si[i];
      if (img->access & PIPE_IMAGE_ACCESS_WRITE)
         resource_written(batch, img->resource);
      else
         resource_read(batch, img->resource);
   }

   /* UBO's are read */
   u_foreach_bit (i, ctx->constbuf[MESA_SHADER_COMPUTE].enabled_mask)
      resource_read(batch, ctx->constbuf[MESA_SHADER_COMPUTE].cb[i].buffer);

   /* Mark textures as being read */
   u_foreach_bit (i, ctx->tex[MESA_SHADER_COMPUTE].valid_textures)
      resource_read(batch, ctx->tex[MESA_SHADER_COMPUTE].textures[i]->texture);

   /* For global buffers, we don't really know if read or written, so assume
    * the worst:
    */
   util_dynarray_foreach (&ctx->global_bindings, struct pipe_resource *, res) {
      resource_written(batch, *res);
   }

   if (info->indirect)
      resource_read(batch, info->indirect);

   list_for_each_entry (struct fd_acc_query, aq, &ctx->acc_active_queries, node) {
      resource_written(batch, aq->prsc);
   }

   /* If the saved batch has been flushed during the resource tracking,
    * don't re-install it:
    */
   if (save_batch && save_batch->flushed)
      fd_batch_reference_locked(&save_batch, NULL);

   fd_screen_unlock(ctx->screen);

   fd_batch_update_queries(batch);

   DBG("%p: work_dim=%u, block=%ux%ux%u, grid=%ux%ux%u",
       batch, info->work_dim,
       info->block[0], info->block[1], info->block[2],
       info->grid[0], info->grid[1], info->grid[2]);

   fd_batch_needs_flush(batch);
   ctx->launch_grid(ctx, info);

   fd_batch_reference(&ctx->batch, save_batch);
   fd_batch_reference(&save_batch, NULL);
   fd_batch_reference(&batch, NULL);
}

void
fd_draw_init(struct pipe_context *pctx)
{
   if (FD_DBG(DDRAW) || FD_DBG(FLUSH)) {
      pctx->draw_vbo = fd_draw_vbo_dbg;
   } else {
      pctx->draw_vbo = fd_draw_vbo;
   }

   pctx->clear = fd_clear;
   pctx->clear_render_target = fd_clear_render_target;
   pctx->clear_depth_stencil = fd_clear_depth_stencil;

   if (has_compute(fd_screen(pctx->screen))) {
      pctx->launch_grid = fd_launch_grid;
   }
}

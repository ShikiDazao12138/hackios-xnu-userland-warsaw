/* Per-draw and per-frame timing for the K90 iOS port.
 *
 * A frame interval here is made of the client thread's draws, the kernel's submissions and the
 * panel. The driver's per-draw cost alone cannot say which of the three to look at once a frame is
 * slow, and an average over 256 draws hides the few draws that made it slow. The stamps are grouped
 * per frame, and every frame of the window is summed into one summary line, so a round always ends
 * with numbers even when the cost sits outside the stamped stages; a frame over FD_PERF_SLOW_US
 * also prints its own four segments, which is where an individual overrun becomes readable.
 *
 * The clock is mach_absolute_time over 1000, the one the kernel's "tl:" lines use, so a line here
 * lines up with tl: s, tl: Q and tl: v in the same log.
 *
 * The two sides keep separate state: the client thread writes fd_perf_client, the driver thread
 * writes fd_perf_driver, and neither reads the other's. Their lines pair up by order in the log.
 *
 * Off unless the process has FD_PERF_DRAW=1 in its environment (package.py JOB_ENV): with it off,
 * fd_perf_us() returns 0 and reads no clock. Every read is an ISB and a counter read, and the stamps
 * on every draw, bind and state segment were a fifth of backboardd's samples in
 * kernel-12377-cmd39-bo15, mostly in mach_absolute_time.
 */
#ifndef PERF_DRAW_H
#define PERF_DRAW_H

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <mach/mach_time.h>

static inline int fd_perf_on(void);

/* mach_absolute_time returns ticks, and one tick is 52.08 ns here (numer 625, denom 12), so dividing
 * by 1000 alone gives 19.2 times the microseconds. The same conversion as the shim's device_us().
 * 0 while the timing is off. */
static inline uint64_t
fd_perf_us(void)
{
   static mach_timebase_info_data_t base;

   if (!fd_perf_on())
      return 0;
   if (base.denom == 0)
      mach_timebase_info(&base);
   return mach_absolute_time() * base.numer / base.denom / 1000;
}

/* A frame whose own accumulated CPU is beyond this no longer fits a 60 Hz budget (16667 us), and is
 * worth a line of its own. */
#define FD_PERF_SLOW_US 6000

/* Frames per summary line. Printing only the slow frames leaves a round with no numbers at all when
 * the cost turns out to sit outside the stamped stages, and then the round has to run again; a
 * summary every 128 frames always says where the time went. */
#define FD_PERF_WINDOW 128

/* The draws kept for the slow-frame print: the two worst of a frame, by their own duration. */
#define FD_PERF_WORST 2

struct fd_perf_draw {
   uint64_t wait;                            /* client: inside tc_draw_vbo */
   uint64_t entry, track, prog, emit0, emit1, draw, exit;   /* driver: fd_draw_vbo and below */
};

struct fd_perf_frame {
   uint64_t first;                           /* the first draw's entry */
   uint64_t track, prog, emit, drawn, driver;   /* driver: the segments, summed over the frame */
   uint64_t wait;                            /* client: tc_draw_vbo, summed over the frame */
   uint64_t max_wait, max_driver;
   unsigned draws;
   struct fd_perf_draw worst[FD_PERF_WORST];
};

/* One summary line's worth of frames. Filled by both threads, each into its own fields. */
struct fd_perf_window {
   unsigned frames;
   uint64_t interval, max_interval;          /* between two closes on the driver thread */
   uint64_t last_close;
   uint64_t draws;
   uint64_t driver, max_driver;              /* fd_draw_vbo, per frame */
   uint64_t own, track, prog, emit, draw;    /* inside fd_draw_vbo, summed over the window */
   uint64_t submit, max_submit;              /* fd_context_flush, the ioctl included */
   uint64_t sync, max_sync;                  /* tc_sync_msg: waiting for the driver thread */
   uint64_t pass, max_pass;                  /* the rest of tc_flush before fd_context_flush */
   uint64_t calls, calls_cond, calls_multi;  /* calls reaching fd_draw_vbo and the early returns */
   uint64_t prog_calls, prog_variants;       /* get_program_state calls and cache lookups */
   uint64_t prog_builds;                     /* ir3_cache_lookup's misses: the ones it built */
   uint64_t client, max_client;              /* the client's tc_draw_vbo, summed */
};

extern struct fd_perf_frame fd_perf_client, fd_perf_driver;
extern struct fd_perf_draw fd_perf_current;   /* the driver thread's draw in flight */
extern struct fd_perf_window fd_perf_win;
extern unsigned fd_perf_progs, fd_perf_variants;   /* get_program_state calls and cache lookups */
/* ir3_cache_lookup's miss path. Lookups minus misses is how often the cache answered, which is
 * the reuse question; the number of lookups alone answers nothing. */
extern unsigned fd_perf_cache_misses;

/* The slow-frame threshold, settable with FD_PERF_SLOW_US. A value past any frame silences the
 * per-frame lines and keeps the window summary, which is what a round wants when the summary is
 * the reading and the per-frame lines would crowd it out. */
extern unsigned fd_perf_slow_us;

void fd_perf_window_add(uint64_t now, const struct fd_perf_frame *f);
void fd_perf_window_submit(uint64_t began);
void fd_perf_window_sync(uint64_t began);
void fd_perf_window_pass(uint64_t began);

static inline int
fd_perf_on(void)
{
   static int on = -1;

   if (on < 0) {
      const char *wanted = getenv("FD_PERF_DRAW");

      on = wanted && wanted[0] == '1';
      {
         const char *slow = getenv("FD_PERF_SLOW_US");

         fd_perf_slow_us = slow && atoi(slow) > 0 ? (unsigned)atoi(slow) : FD_PERF_SLOW_US;
      }
      if (on) {
         printf("perf draw: timing on, frames over %u us are printed, %d frames per summary\n",
                fd_perf_slow_us, FD_PERF_WINDOW);
         fflush(stdout);
      }
   }
   return on;
}

/* A path that returns before one of the inner stamps leaves that field zero, and subtracting it
 * would wrap to a number near 2^64 that ruins every sum it lands in. Filling it in from the stamp
 * before it costs nothing and keeps a draw that took no inner path from poisoning the frame. */
static inline void
fd_perf_keep_worst(struct fd_perf_frame *f, const struct fd_perf_draw *d)
{
   if (f->draws <= FD_PERF_WORST) {
      f->worst[f->draws - 1] = *d;
      return;
   }
   for (unsigned i = 0; i < FD_PERF_WORST; i++) {
      if (f->worst[i].exit - f->worst[i].entry < d->exit - d->entry) {
         f->worst[i] = *d;
         return;
      }
   }
}

static inline void
fd_perf_note_client(struct fd_perf_draw *d)
{
   if (!fd_perf_client.draws)
      fd_perf_client.first = d->entry;
   fd_perf_client.draws++;
   fd_perf_client.wait += d->wait;
   if (d->wait > fd_perf_client.max_wait)
      fd_perf_client.max_wait = d->wait;
}

static inline void
fd_perf_note_driver(struct fd_perf_draw *d)
{
   struct fd_perf_draw c = *d;
   uint64_t driver;

   if (!c.track) c.track = c.entry;
   if (!c.prog) c.prog = c.track;
   if (!c.emit0) c.emit0 = c.prog;
   if (!c.emit1) c.emit1 = c.emit0;
   if (!c.draw) c.draw = c.emit1;
   driver = c.exit - c.entry;

   if (!fd_perf_driver.draws)
      fd_perf_driver.first = c.entry;
   fd_perf_driver.draws++;
   fd_perf_driver.driver += driver;
   fd_perf_driver.track += c.track - c.entry;
   fd_perf_driver.prog += c.prog - c.track;
   fd_perf_driver.emit += c.emit1 - c.emit0;
   fd_perf_driver.drawn += c.draw - c.emit1;
   if (driver > fd_perf_driver.max_driver)
      fd_perf_driver.max_driver = driver;
   fd_perf_keep_worst(&fd_perf_driver, &c);
}

/* Called by whichever thread has just finished a frame's worth of draws: the last draw's entry for
 * the client, the flush that submits it for the driver. */
static inline void
fd_perf_close(struct fd_perf_frame *f)
{
   uint64_t now = fd_perf_us();

   if (!f->draws) {
      f->first = 0;
      return;
   }
   if (now - f->first >= fd_perf_slow_us) {
      if (f == &fd_perf_driver) {
         printf("perf driver %llu us: %u draws in %llu us, tracking %llu prog %llu emit %llu "
                "draw %llu us, max %llu us, program calls %u cache lookups %u\n",
                (unsigned long long) (now - f->first), f->draws, (unsigned long long) f->driver,
                (unsigned long long) f->track, (unsigned long long) f->prog,
                (unsigned long long) f->emit, (unsigned long long) f->drawn,
                (unsigned long long) f->max_driver, fd_perf_progs, fd_perf_variants);
         for (unsigned i = 0; i < FD_PERF_WORST; i++) {
            const struct fd_perf_draw *d = &f->worst[i];

            if (!d->exit)
               continue;
            printf("perf driver worst: entry %llu track %llu prog %llu emit %llu draw %llu "
                   "exit %llu, total %llu us\n",
                   (unsigned long long) d->entry, (unsigned long long) (d->track - d->entry),
                   (unsigned long long) (d->prog - d->track),
                   (unsigned long long) (d->emit1 - d->emit0),
                   (unsigned long long) (d->draw - d->emit1),
                   (unsigned long long) (d->exit - d->draw),
                   (unsigned long long) (d->exit - d->entry));
         }
      } else {
         printf("perf client %llu us: %u draws, queue wait sum %llu max %llu us\n",
                (unsigned long long) (now - f->first), f->draws,
                (unsigned long long) f->wait, (unsigned long long) f->max_wait);
      }
      fflush(stdout);
   }
   fd_perf_window_add(now, f);

   f->draws = 0;
   f->track = f->prog = f->emit = f->drawn = f->driver = 0;
   f->wait = f->max_wait = f->max_driver = 0;
   memset(f->worst, 0, sizeof(f->worst));
}

#endif /* PERF_DRAW_H */

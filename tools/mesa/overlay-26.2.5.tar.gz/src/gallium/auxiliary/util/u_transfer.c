#include "pipe/p_context.h"
#include "util/u_surface.h"
#include "util/u_inlines.h"
#include "util/u_transfer.h"
#include "util/u_memory.h"

void u_default_buffer_subdata(struct pipe_context *pipe,
                              struct pipe_resource *resource,
                              unsigned usage, unsigned offset,
                              unsigned size, const void *data)
{
   struct pipe_transfer *transfer = NULL;
   struct pipe_box box;
   uint8_t *map = NULL;

   assert(!(usage & PIPE_MAP_READ));

   /* the write flag is implicit by the nature of buffer_subdata */
   usage |= PIPE_MAP_WRITE;

   /* buffer_subdata implicitly discards the rewritten buffer range.
    * PIPE_MAP_DIRECTLY supresses that.
    */
   if (!(usage & PIPE_MAP_DIRECTLY)) {
      if (offset == 0 && size == resource->width0) {
         usage |= PIPE_MAP_DISCARD_WHOLE_RESOURCE;
      } else {
         usage |= PIPE_MAP_DISCARD_RANGE;
      }
   }

   u_box_1d(offset, size, &box);

   map = pipe->buffer_map(pipe, resource, 0, usage, &box, &transfer);
   if (!map)
      return;

   memcpy(map, data, size);
   pipe_buffer_unmap(pipe, transfer);
}

void u_default_clear_buffer(struct pipe_context *pipe,
                            struct pipe_resource *resource,
                            unsigned offset, unsigned size,
                            const void *clear_value,
                            int clear_value_size)
{
   struct pipe_transfer *transfer = NULL;
   struct pipe_box box;
   uint8_t *map = NULL;

   /* the write flag is implicit by the nature of buffer_subdata */
   unsigned usage = PIPE_MAP_WRITE;

   /* clear_buffer implicitly discards the rewritten buffer range. */
   if (offset == 0 && size == resource->width0) {
      usage |= PIPE_MAP_DISCARD_WHOLE_RESOURCE;
   } else {
      usage |= PIPE_MAP_DISCARD_RANGE;
   }

   u_box_1d(offset, size, &box);

   map = pipe->buffer_map(pipe, resource, 0, usage, &box, &transfer);
   if (!map)
      return;

   assert(clear_value_size > 0);
   for (unsigned off = 0; off < size; off += clear_value_size)
      memcpy(map + off, clear_value, MIN2(clear_value_size, size - off));
   pipe_buffer_unmap(pipe, transfer);
}

void u_default_texture_subdata(struct pipe_context *pipe,
                               struct pipe_resource *resource,
                               unsigned level,
                               unsigned usage,
                               const struct pipe_box *box,
                               const void *data,
                               unsigned stride,
                               uintptr_t layer_stride)
{
   struct pipe_transfer *transfer = NULL;
   const uint8_t *src_data = data;
   uint8_t *map = NULL;

   assert(!(usage & PIPE_MAP_READ));

   /* the write flag is implicit by the nature of texture_subdata */
   usage |= PIPE_MAP_WRITE;

   /* texture_subdata implicitly discards the rewritten buffer range */
   usage |= PIPE_MAP_DISCARD_RANGE;

   map = pipe->texture_map(pipe,
                            resource,
                            level,
                            usage,
                            box, &transfer);
   if (!map)
      return;

   /* Round air-d: the address the map call just returned, with the transfer that produced it and
    * the helper's two fields, so the three candidates can be told apart on one line.
    */
   if ((uintptr_t)map >> 48) {
      void rwa_map_guard(const void *map, const void *transfer, unsigned is_helper,
                         const void *ptr, const void *staging);
      int u_transfer_helper_handles(struct pipe_resource *prsc);
      void u_transfer_helper_parts(struct pipe_transfer *ptrans, const void **ptr,
                                   const void **staging);
      const void *ptr = NULL, *staging = NULL;
      int is_helper = u_transfer_helper_handles(resource);

      if (is_helper)
         u_transfer_helper_parts(transfer, &ptr, &staging);
      rwa_map_guard(map, transfer, (unsigned)is_helper, ptr, staging);
   }

   /* Round air-d: the source of this copy is the caller's own memory, so a value that cannot be an
    * address entered through the call rather than out of a buffer object. Printed after the map so
    * the transfer pointer on the line is the one this call created; `src_data` is unchanged since
    * it was assigned.
    */
   if ((uintptr_t)src_data >> 48) {
      void rwa_subdata_guard(const void *data, const void *transfer, unsigned level,
                             unsigned stride, unsigned w, unsigned h);

      rwa_subdata_guard(src_data, transfer, level, stride, (unsigned)box->width,
                        (unsigned)box->height);

      /* The caller's own address, so the call site is `ret - self` when both are in one image. */
      {
         void rwa_subdata_caller(const void *data, const void *ret, const void *self,
                                 const void *transfer);

         rwa_subdata_caller(src_data, (const void *)__builtin_return_address(0),
                            (const void *)&u_default_texture_subdata, transfer);
      }
   }

   /* Round air-d: the resource this copy fills, for the ring libannibaleair prints on SIGSEGV. The
    * source here is the caller's memory and belongs to no resource, so the texture is what gets
    * recorded. Row bytes are what util_copy_rect will copy, which is util_format_get_stride's answer
    * by definition: nblocks times the block size.
    */
   void rwa_copy_record(const void *res, const void *buf, const void *src, unsigned level,
                        unsigned box_y, unsigned rows, unsigned len);
   rwa_copy_record(resource, map, src_data, level, box->y, box->height,
                   util_format_get_stride(resource->format, box->width));

   util_copy_box(map,
                 resource->format,
                 transfer->stride, /* bytes */
                 transfer->layer_stride, /* bytes */
                 0, 0, 0,
                 box->width,
                 box->height,
                 box->depth,
                 src_data,
                 stride,       /* bytes */
                 layer_stride, /* bytes */
                 0, 0, 0);

   pipe_texture_unmap(pipe, transfer);
}

void u_default_transfer_flush_region(UNUSED struct pipe_context *pipe,
                                     UNUSED struct pipe_transfer *transfer,
                                     UNUSED const struct pipe_box *box)
{
   /* This is a no-op implementation, nothing to do.
    */
}

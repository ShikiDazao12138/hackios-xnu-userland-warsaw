# Copyright © 2017 Intel Corporation
# SPDX-License-Identifier: MIT

tu_entrypoints = custom_target(
  'tu_entrypoints',
  input : [vk_entrypoints_gen, vk_api_xml],
  output : ['tu_entrypoints.h', 'tu_entrypoints.cc'],
  command : [
    prog_python, '@INPUT0@', '--xml', '@INPUT1@', '--proto', '--weak',
    '--out-h', '@OUTPUT0@', '--out-c', '@OUTPUT1@', '--prefix', 'tu',
    '--include', 'adreno_common.xml.h',
    '--tmpl-prefix', 'tu', '--tmpl-param', 'chip CHIP',
    '--tmpl-variants', '<A6XX>', '<A7XX>', '<A8XX>',
    '--beta', with_vulkan_beta.to_string(),
    '--device-prefix', 'tu_rmv',
  ],
  depend_files : vk_entrypoints_gen_depend_files,
)

tu_drirc = custom_target(
  'tu_drirc',
  input  : [files('tu_drirc_gen.py'), drirc_gen, '00-turnip-defaults.conf'],
  output : ['tu_drirc.c', 'tu_drirc.h'],
  command : [
    prog_python, '@INPUT0@',
    '--import-path', join_paths(dir_source_root, 'src/util'),
    '--drirc-src', '@OUTPUT0@',
    '--drirc-hdr', '@OUTPUT1@',
    '--validate', '@INPUT2@',
  ],
)

libtu_files = files(
  'bvh/tu_bvh_defines.h',
  'layers/tu_rmv_layer.cc',
  'tu_acceleration_structure.cc',
  'tu_autotune.cc',
  'tu_buffer.cc',
  'tu_buffer_view.cc',
  'tu_clear_blit.cc',
  'tu_cmd_buffer.cc',
  'tu_cs_breadcrumbs.cc',
  'tu_cs.cc',
  'tu_device.cc',
  'tu_descriptor_set.cc',
  'tu_dynamic_rendering.cc',
  'tu_event.cc',
  'tu_formats.cc',
  'tu_image.cc',
  'tu_knl.cc',
  'tu_lrz.cc',
  'tu_nir_lower_demote_samples.cc',
  'tu_nir_lower_multiview.cc',
  'tu_nir_lower_ray_query.cc',
  'tu_pass.cc',
  'tu_pipeline.cc',
  'tu_sampler.cc',
  'tu_query_pool.cc',
  'tu_queue.cc',
  'tu_rmv.cc',
  'tu_shader.cc',
  'tu_suballoc.cc',
  'tu_subsampled_image.cc',
  'tu_tile_config.cc',
  'tu_util.cc',
)

libtu_files += custom_target(
  'float32_spv.h',
  input : float32_glsl_file,
  output : 'float32_spv.h',
  command : [
    prog_glslang, '--no-link', '-V', '-S', 'comp', '-x', '-o', '@OUTPUT@', '@INPUT@',
    glslang_quiet, glslang_depfile,
  ],
  depfile : 'float32_spv.h.d',
)

libtu_files += custom_target(
  'float64_spv.h',
  input : [glsl2spirv, float64_glsl_file],
  output : 'float64_spv.h',
  command : [
    prog_python, '@INPUT@', '@OUTPUT@',
    prog_glslang,
    '--vn', 'float64_spv_source',
    '--glsl-version', '450',
    '-Olib',
    glslang_depfile,
  ],
  depfile : 'float64_spv.h.d',
)

subdir('bvh')

libtu_includes = [
    inc_include,
    inc_src,
    inc_freedreno,
]

tu_link_with = []
tu_deps = []
tu_flags = [sse2_args]

tu_wsi = false

if with_platform_x11
  tu_deps += dep_xcb_dri3
  tu_wsi = true
endif

if with_platform_wayland
  tu_deps += dep_wayland_client
  tu_wsi = true
endif

if system_has_kms_drm and not with_platform_android
  tu_wsi = true
endif

if tu_wsi
  libtu_files += 'tu_wsi.cc'
endif

if with_xlib_lease
  tu_deps += [dep_xlib_xrandr]
endif

if freedreno_kmds.contains('kgsl')
  tu_flags += '-DTU_HAS_KGSL'
  libtu_files += files('tu_knl_kgsl.cc')
endif

if freedreno_kmds.contains('msm')
  tu_flags += '-DTU_HAS_MSM'
  libtu_files += files('tu_knl_drm_msm.cc', 'tu_knl_drm.cc')
  tu_deps += dep_libdrm
  if host_machine.system() == 'darwin'
    libtu_files += files('../../annibale-drm/annibale_drm.c')
  endif
endif

# Mach-O has no weak undefined symbols: the entry points this build leaves out are left to dyld.
tu_darwin_link_args = []
if host_machine.system() == 'darwin'
  tu_darwin_link_args += '-Wl,-undefined,dynamic_lookup'
endif

if freedreno_kmds.contains('virtio')
  tu_flags += '-DTU_HAS_VIRTIO'
  libtu_files += files('tu_knl_drm_virtio.cc', 'tu_knl_drm.cc')
  libtu_includes += [
    inc_virtio_gpu,
    inc_virtio_vdrm,
  ]
  tu_link_with += libvdrm
  tu_deps += dep_libdrm
endif

tu_build_id = get_option('tu-build-id')
if tu_build_id != ''
  tu_flags += '-DTU_BUILD_ID_OVERRIDE="' + tu_build_id + '"'
endif

tu_tracepoints = custom_target(
  'tu_tracepoints.[ch]',
  input: 'tu_tracepoints.py',
  output: ['tu_tracepoints.cc', 'tu_tracepoints.h', 'tu_tracepoints_perfetto.h'],
  command: [
    prog_python, '@INPUT@',
    '-p', join_paths(dir_source_root, 'src/util/perf/'),
    '--utrace-src', '@OUTPUT0@',
    '--utrace-hdr', '@OUTPUT1@',
    '--perfetto-hdr', '@OUTPUT2@',
  ],
  depend_files: u_trace_py,
)

if with_perfetto
  libtu_files += ['tu_perfetto.cc']
  tu_deps += dep_perfetto
  tu_deps += idep_parson
endif

tu_cpp_args = []
tu_cpp_args += cpp.get_supported_arguments([
  '-fno-exceptions',
  '-fno-rtti',
  '-Wno-address-of-temporary',
  '-Wno-array-bounds',
  '-Wno-c++11-narrowing',
  '-Wno-c99-designator',
  '-Wno-class-memaccess',
  '-Wno-missing-braces',
  '-Wno-narrowing',
  '-Wno-pointer-arith',
  '-Wno-reorder-init-list',
  '-Wno-sign-compare',
  '-Wno-switch',
  '-Wno-unused-function',
  '-Wno-vla-cxx-extension',
  '-Wno-writable-strings',
  '-Wno-write-strings',
])

if cpp.get_id() == 'gcc'
  tu_cpp_args += cpp.get_supported_arguments(['-Wno-misleading-indentation'])
endif

libvulkan_freedreno = shared_library(
  'vulkan_freedreno',
  [libtu_files, tu_drirc, tu_entrypoints, tu_tracepoints, freedreno_xml_header_files, sha1_h, u_format_pack_h, bvh_spv],
  include_directories : libtu_includes,
  link_with : [
    libfreedreno_ir3,
    libfreedreno_layout,
    libfreedreno_perfcntrs,
    tu_link_with,
  ],
  dependencies : [
    idep_libfreedreno_common,
    dep_dl,
    dep_elf,
    dep_m,
    dep_thread,
    dep_valgrind,
    idep_nir,
    tu_deps,
    idep_vulkan_util,
    idep_vulkan_runtime,
    idep_vulkan_wsi,
    idep_mesautil,
  ],
  c_args : [no_override_init_args, tu_flags, soong_compat_c_args],
  cpp_args : [tu_cpp_args, tu_flags, soong_compat_cpp_args],
  gnu_symbol_visibility : 'hidden',
  link_args : [vulkan_icd_link_args, ld_args_bsymbolic, ld_args_gc_sections, ld_args_build_id, tu_darwin_link_args],
  link_depends : vulkan_icd_link_depends,
  install : true,
)

if with_symbols_check
  test(
    'tu symbols check',
    symbols_check,
    args : [
      '--lib', libvulkan_freedreno,
      '--symbols-file', vulkan_icd_symbols,
      symbols_check_args,
    ],
    suite : ['freedreno'],
  )
endif

icd_file_name = libname_prefix + 'vulkan_freedreno.' + libname_suffix

freedreno_icd = custom_target(
  'freedreno_icd',
  input : [vk_icd_gen, vk_api_xml],
  output : 'freedreno_icd.' + vulkan_manifest_suffix,
  command : [
    prog_python, '@INPUT0@',
    '--api-version', '1.4', '--xml', '@INPUT1@',
    '--sizeof-pointer', sizeof_pointer,
    '--icd-lib-path', vulkan_icd_lib_path,
    '--icd-filename', icd_file_name,
    '--out', '@OUTPUT@',
  ],
  build_by_default : true,
  install_dir : with_vulkan_icd_dir,
  install_tag : 'runtime',
  install : true,
)

_dev_icdname = 'freedreno_devenv_icd.@0@.json'.format(host_machine.cpu())
_dev_icd = custom_target(
  'freedreno_devenv_icd',
  input : [vk_icd_gen, vk_api_xml],
  output : _dev_icdname,
  command : [
    prog_python, '@INPUT0@',
    '--api-version', '1.4', '--xml', '@INPUT1@',
    '--sizeof-pointer', sizeof_pointer,
    '--icd-lib-path', meson.current_build_dir(),
    '--icd-filename', icd_file_name,
    '--out', '@OUTPUT@',
  ],
  build_by_default : true,
)

devenv.append('VK_DRIVER_FILES', _dev_icd.full_path())
